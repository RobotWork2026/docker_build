// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__BUILDER_HPP_
#define AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__BUILDER_HPP_

#include "amap_nav_msgs/msg/detail/waypoint_gcj02__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace amap_nav_msgs
{

namespace msg
{

namespace builder
{

class Init_WaypointGCJ02_label
{
public:
  explicit Init_WaypointGCJ02_label(::amap_nav_msgs::msg::WaypointGCJ02 & msg)
  : msg_(msg)
  {}
  ::amap_nav_msgs::msg::WaypointGCJ02 label(::amap_nav_msgs::msg::WaypointGCJ02::_label_type arg)
  {
    msg_.label = std::move(arg);
    return std::move(msg_);
  }

private:
  ::amap_nav_msgs::msg::WaypointGCJ02 msg_;
};

class Init_WaypointGCJ02_altitude
{
public:
  explicit Init_WaypointGCJ02_altitude(::amap_nav_msgs::msg::WaypointGCJ02 & msg)
  : msg_(msg)
  {}
  Init_WaypointGCJ02_label altitude(::amap_nav_msgs::msg::WaypointGCJ02::_altitude_type arg)
  {
    msg_.altitude = std::move(arg);
    return Init_WaypointGCJ02_label(msg_);
  }

private:
  ::amap_nav_msgs::msg::WaypointGCJ02 msg_;
};

class Init_WaypointGCJ02_latitude
{
public:
  explicit Init_WaypointGCJ02_latitude(::amap_nav_msgs::msg::WaypointGCJ02 & msg)
  : msg_(msg)
  {}
  Init_WaypointGCJ02_altitude latitude(::amap_nav_msgs::msg::WaypointGCJ02::_latitude_type arg)
  {
    msg_.latitude = std::move(arg);
    return Init_WaypointGCJ02_altitude(msg_);
  }

private:
  ::amap_nav_msgs::msg::WaypointGCJ02 msg_;
};

class Init_WaypointGCJ02_longitude
{
public:
  Init_WaypointGCJ02_longitude()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_WaypointGCJ02_latitude longitude(::amap_nav_msgs::msg::WaypointGCJ02::_longitude_type arg)
  {
    msg_.longitude = std::move(arg);
    return Init_WaypointGCJ02_latitude(msg_);
  }

private:
  ::amap_nav_msgs::msg::WaypointGCJ02 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::amap_nav_msgs::msg::WaypointGCJ02>()
{
  return amap_nav_msgs::msg::builder::Init_WaypointGCJ02_longitude();
}

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__BUILDER_HPP_
