// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__rosidl_typesupport_introspection_c.h"
#include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__functions.h"
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__struct.h"


// Include directives for member types
// Member `label`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  amap_nav_msgs__msg__WaypointGCJ02__init(message_memory);
}

void WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_fini_function(void * message_memory)
{
  amap_nav_msgs__msg__WaypointGCJ02__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_message_member_array[4] = {
  {
    "longitude",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__msg__WaypointGCJ02, longitude),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "latitude",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__msg__WaypointGCJ02, latitude),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "altitude",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__msg__WaypointGCJ02, altitude),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "label",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__msg__WaypointGCJ02, label),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_message_members = {
  "amap_nav_msgs__msg",  // message namespace
  "WaypointGCJ02",  // message name
  4,  // number of fields
  sizeof(amap_nav_msgs__msg__WaypointGCJ02),
  WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_message_member_array,  // message members
  WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_init_function,  // function to initialize message memory (memory has to be allocated)
  WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_message_type_support_handle = {
  0,
  &WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, msg, WaypointGCJ02)() {
  if (!WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_message_type_support_handle.typesupport_identifier) {
    WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &WaypointGCJ02__rosidl_typesupport_introspection_c__WaypointGCJ02_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
