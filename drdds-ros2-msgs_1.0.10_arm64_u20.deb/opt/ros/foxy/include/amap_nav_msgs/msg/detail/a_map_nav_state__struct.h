// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from amap_nav_msgs:msg/AMapNavState.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_H_
#define AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'takeover_action'
// Member 'destination_text'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/AMapNavState in the package amap_nav_msgs.
typedef struct amap_nav_msgs__msg__AMapNavState
{
  std_msgs__msg__Header header;
  double longitude;
  double latitude;
  double yaw_deg;
  double target_heading;
  double distance_to_destination_m;
  bool position_valid;
  bool navigation_active;
  bool pending_plan;
  bool arrival_announced;
  bool route_available;
  bool need_takeover;
  rosidl_runtime_c__String takeover_action;
  rosidl_runtime_c__String destination_text;
} amap_nav_msgs__msg__AMapNavState;

// Struct for a sequence of amap_nav_msgs__msg__AMapNavState.
typedef struct amap_nav_msgs__msg__AMapNavState__Sequence
{
  amap_nav_msgs__msg__AMapNavState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__msg__AMapNavState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_H_
