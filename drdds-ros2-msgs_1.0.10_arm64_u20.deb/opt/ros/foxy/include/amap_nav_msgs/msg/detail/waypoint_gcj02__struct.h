// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__STRUCT_H_
#define AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'label'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/WaypointGCJ02 in the package amap_nav_msgs.
typedef struct amap_nav_msgs__msg__WaypointGCJ02
{
  double longitude;
  double latitude;
  double altitude;
  rosidl_runtime_c__String label;
} amap_nav_msgs__msg__WaypointGCJ02;

// Struct for a sequence of amap_nav_msgs__msg__WaypointGCJ02.
typedef struct amap_nav_msgs__msg__WaypointGCJ02__Sequence
{
  amap_nav_msgs__msg__WaypointGCJ02 * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__msg__WaypointGCJ02__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__STRUCT_H_
