// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from amap_nav_msgs:msg/AMapNavState.idl
// generated code does not contain a copyright notice
#include "amap_nav_msgs/msg/detail/a_map_nav_state__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `takeover_action`
// Member `destination_text`
#include "rosidl_runtime_c/string_functions.h"

bool
amap_nav_msgs__msg__AMapNavState__init(amap_nav_msgs__msg__AMapNavState * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    amap_nav_msgs__msg__AMapNavState__fini(msg);
    return false;
  }
  // longitude
  // latitude
  // yaw_deg
  // target_heading
  // distance_to_destination_m
  // position_valid
  // navigation_active
  // pending_plan
  // arrival_announced
  // route_available
  // need_takeover
  // takeover_action
  if (!rosidl_runtime_c__String__init(&msg->takeover_action)) {
    amap_nav_msgs__msg__AMapNavState__fini(msg);
    return false;
  }
  // destination_text
  if (!rosidl_runtime_c__String__init(&msg->destination_text)) {
    amap_nav_msgs__msg__AMapNavState__fini(msg);
    return false;
  }
  return true;
}

void
amap_nav_msgs__msg__AMapNavState__fini(amap_nav_msgs__msg__AMapNavState * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // longitude
  // latitude
  // yaw_deg
  // target_heading
  // distance_to_destination_m
  // position_valid
  // navigation_active
  // pending_plan
  // arrival_announced
  // route_available
  // need_takeover
  // takeover_action
  rosidl_runtime_c__String__fini(&msg->takeover_action);
  // destination_text
  rosidl_runtime_c__String__fini(&msg->destination_text);
}

bool
amap_nav_msgs__msg__AMapNavState__are_equal(const amap_nav_msgs__msg__AMapNavState * lhs, const amap_nav_msgs__msg__AMapNavState * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // longitude
  if (lhs->longitude != rhs->longitude) {
    return false;
  }
  // latitude
  if (lhs->latitude != rhs->latitude) {
    return false;
  }
  // yaw_deg
  if (lhs->yaw_deg != rhs->yaw_deg) {
    return false;
  }
  // target_heading
  if (lhs->target_heading != rhs->target_heading) {
    return false;
  }
  // distance_to_destination_m
  if (lhs->distance_to_destination_m != rhs->distance_to_destination_m) {
    return false;
  }
  // position_valid
  if (lhs->position_valid != rhs->position_valid) {
    return false;
  }
  // navigation_active
  if (lhs->navigation_active != rhs->navigation_active) {
    return false;
  }
  // pending_plan
  if (lhs->pending_plan != rhs->pending_plan) {
    return false;
  }
  // arrival_announced
  if (lhs->arrival_announced != rhs->arrival_announced) {
    return false;
  }
  // route_available
  if (lhs->route_available != rhs->route_available) {
    return false;
  }
  // need_takeover
  if (lhs->need_takeover != rhs->need_takeover) {
    return false;
  }
  // takeover_action
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->takeover_action), &(rhs->takeover_action)))
  {
    return false;
  }
  // destination_text
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->destination_text), &(rhs->destination_text)))
  {
    return false;
  }
  return true;
}

bool
amap_nav_msgs__msg__AMapNavState__copy(
  const amap_nav_msgs__msg__AMapNavState * input,
  amap_nav_msgs__msg__AMapNavState * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // longitude
  output->longitude = input->longitude;
  // latitude
  output->latitude = input->latitude;
  // yaw_deg
  output->yaw_deg = input->yaw_deg;
  // target_heading
  output->target_heading = input->target_heading;
  // distance_to_destination_m
  output->distance_to_destination_m = input->distance_to_destination_m;
  // position_valid
  output->position_valid = input->position_valid;
  // navigation_active
  output->navigation_active = input->navigation_active;
  // pending_plan
  output->pending_plan = input->pending_plan;
  // arrival_announced
  output->arrival_announced = input->arrival_announced;
  // route_available
  output->route_available = input->route_available;
  // need_takeover
  output->need_takeover = input->need_takeover;
  // takeover_action
  if (!rosidl_runtime_c__String__copy(
      &(input->takeover_action), &(output->takeover_action)))
  {
    return false;
  }
  // destination_text
  if (!rosidl_runtime_c__String__copy(
      &(input->destination_text), &(output->destination_text)))
  {
    return false;
  }
  return true;
}

amap_nav_msgs__msg__AMapNavState *
amap_nav_msgs__msg__AMapNavState__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__msg__AMapNavState * msg = (amap_nav_msgs__msg__AMapNavState *)allocator.allocate(sizeof(amap_nav_msgs__msg__AMapNavState), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(amap_nav_msgs__msg__AMapNavState));
  bool success = amap_nav_msgs__msg__AMapNavState__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
amap_nav_msgs__msg__AMapNavState__destroy(amap_nav_msgs__msg__AMapNavState * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    amap_nav_msgs__msg__AMapNavState__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
amap_nav_msgs__msg__AMapNavState__Sequence__init(amap_nav_msgs__msg__AMapNavState__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__msg__AMapNavState * data = NULL;

  if (size) {
    data = (amap_nav_msgs__msg__AMapNavState *)allocator.zero_allocate(size, sizeof(amap_nav_msgs__msg__AMapNavState), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = amap_nav_msgs__msg__AMapNavState__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        amap_nav_msgs__msg__AMapNavState__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
amap_nav_msgs__msg__AMapNavState__Sequence__fini(amap_nav_msgs__msg__AMapNavState__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      amap_nav_msgs__msg__AMapNavState__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

amap_nav_msgs__msg__AMapNavState__Sequence *
amap_nav_msgs__msg__AMapNavState__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__msg__AMapNavState__Sequence * array = (amap_nav_msgs__msg__AMapNavState__Sequence *)allocator.allocate(sizeof(amap_nav_msgs__msg__AMapNavState__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = amap_nav_msgs__msg__AMapNavState__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
amap_nav_msgs__msg__AMapNavState__Sequence__destroy(amap_nav_msgs__msg__AMapNavState__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    amap_nav_msgs__msg__AMapNavState__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
amap_nav_msgs__msg__AMapNavState__Sequence__are_equal(const amap_nav_msgs__msg__AMapNavState__Sequence * lhs, const amap_nav_msgs__msg__AMapNavState__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!amap_nav_msgs__msg__AMapNavState__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
amap_nav_msgs__msg__AMapNavState__Sequence__copy(
  const amap_nav_msgs__msg__AMapNavState__Sequence * input,
  amap_nav_msgs__msg__AMapNavState__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(amap_nav_msgs__msg__AMapNavState);
    amap_nav_msgs__msg__AMapNavState * data =
      (amap_nav_msgs__msg__AMapNavState *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!amap_nav_msgs__msg__AMapNavState__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          amap_nav_msgs__msg__AMapNavState__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!amap_nav_msgs__msg__AMapNavState__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
