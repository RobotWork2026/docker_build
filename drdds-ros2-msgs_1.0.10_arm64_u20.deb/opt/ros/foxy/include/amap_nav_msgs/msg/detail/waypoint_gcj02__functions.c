// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `label`
#include "rosidl_runtime_c/string_functions.h"

bool
amap_nav_msgs__msg__WaypointGCJ02__init(amap_nav_msgs__msg__WaypointGCJ02 * msg)
{
  if (!msg) {
    return false;
  }
  // longitude
  // latitude
  // altitude
  // label
  if (!rosidl_runtime_c__String__init(&msg->label)) {
    amap_nav_msgs__msg__WaypointGCJ02__fini(msg);
    return false;
  }
  return true;
}

void
amap_nav_msgs__msg__WaypointGCJ02__fini(amap_nav_msgs__msg__WaypointGCJ02 * msg)
{
  if (!msg) {
    return;
  }
  // longitude
  // latitude
  // altitude
  // label
  rosidl_runtime_c__String__fini(&msg->label);
}

bool
amap_nav_msgs__msg__WaypointGCJ02__are_equal(const amap_nav_msgs__msg__WaypointGCJ02 * lhs, const amap_nav_msgs__msg__WaypointGCJ02 * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // longitude
  if (lhs->longitude != rhs->longitude) {
    return false;
  }
  // latitude
  if (lhs->latitude != rhs->latitude) {
    return false;
  }
  // altitude
  if (lhs->altitude != rhs->altitude) {
    return false;
  }
  // label
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->label), &(rhs->label)))
  {
    return false;
  }
  return true;
}

bool
amap_nav_msgs__msg__WaypointGCJ02__copy(
  const amap_nav_msgs__msg__WaypointGCJ02 * input,
  amap_nav_msgs__msg__WaypointGCJ02 * output)
{
  if (!input || !output) {
    return false;
  }
  // longitude
  output->longitude = input->longitude;
  // latitude
  output->latitude = input->latitude;
  // altitude
  output->altitude = input->altitude;
  // label
  if (!rosidl_runtime_c__String__copy(
      &(input->label), &(output->label)))
  {
    return false;
  }
  return true;
}

amap_nav_msgs__msg__WaypointGCJ02 *
amap_nav_msgs__msg__WaypointGCJ02__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__msg__WaypointGCJ02 * msg = (amap_nav_msgs__msg__WaypointGCJ02 *)allocator.allocate(sizeof(amap_nav_msgs__msg__WaypointGCJ02), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(amap_nav_msgs__msg__WaypointGCJ02));
  bool success = amap_nav_msgs__msg__WaypointGCJ02__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
amap_nav_msgs__msg__WaypointGCJ02__destroy(amap_nav_msgs__msg__WaypointGCJ02 * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    amap_nav_msgs__msg__WaypointGCJ02__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
amap_nav_msgs__msg__WaypointGCJ02__Sequence__init(amap_nav_msgs__msg__WaypointGCJ02__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__msg__WaypointGCJ02 * data = NULL;

  if (size) {
    data = (amap_nav_msgs__msg__WaypointGCJ02 *)allocator.zero_allocate(size, sizeof(amap_nav_msgs__msg__WaypointGCJ02), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = amap_nav_msgs__msg__WaypointGCJ02__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        amap_nav_msgs__msg__WaypointGCJ02__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
amap_nav_msgs__msg__WaypointGCJ02__Sequence__fini(amap_nav_msgs__msg__WaypointGCJ02__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      amap_nav_msgs__msg__WaypointGCJ02__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

amap_nav_msgs__msg__WaypointGCJ02__Sequence *
amap_nav_msgs__msg__WaypointGCJ02__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__msg__WaypointGCJ02__Sequence * array = (amap_nav_msgs__msg__WaypointGCJ02__Sequence *)allocator.allocate(sizeof(amap_nav_msgs__msg__WaypointGCJ02__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = amap_nav_msgs__msg__WaypointGCJ02__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
amap_nav_msgs__msg__WaypointGCJ02__Sequence__destroy(amap_nav_msgs__msg__WaypointGCJ02__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    amap_nav_msgs__msg__WaypointGCJ02__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
amap_nav_msgs__msg__WaypointGCJ02__Sequence__are_equal(const amap_nav_msgs__msg__WaypointGCJ02__Sequence * lhs, const amap_nav_msgs__msg__WaypointGCJ02__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!amap_nav_msgs__msg__WaypointGCJ02__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
amap_nav_msgs__msg__WaypointGCJ02__Sequence__copy(
  const amap_nav_msgs__msg__WaypointGCJ02__Sequence * input,
  amap_nav_msgs__msg__WaypointGCJ02__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(amap_nav_msgs__msg__WaypointGCJ02);
    amap_nav_msgs__msg__WaypointGCJ02 * data =
      (amap_nav_msgs__msg__WaypointGCJ02 *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!amap_nav_msgs__msg__WaypointGCJ02__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          amap_nav_msgs__msg__WaypointGCJ02__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!amap_nav_msgs__msg__WaypointGCJ02__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
