// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__STRUCT_HPP_
#define AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__amap_nav_msgs__msg__WaypointGCJ02 __attribute__((deprecated))
#else
# define DEPRECATED__amap_nav_msgs__msg__WaypointGCJ02 __declspec(deprecated)
#endif

namespace amap_nav_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct WaypointGCJ02_
{
  using Type = WaypointGCJ02_<ContainerAllocator>;

  explicit WaypointGCJ02_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->longitude = 0.0;
      this->latitude = 0.0;
      this->altitude = 0.0;
      this->label = "";
    }
  }

  explicit WaypointGCJ02_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : label(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->longitude = 0.0;
      this->latitude = 0.0;
      this->altitude = 0.0;
      this->label = "";
    }
  }

  // field types and members
  using _longitude_type =
    double;
  _longitude_type longitude;
  using _latitude_type =
    double;
  _latitude_type latitude;
  using _altitude_type =
    double;
  _altitude_type altitude;
  using _label_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _label_type label;

  // setters for named parameter idiom
  Type & set__longitude(
    const double & _arg)
  {
    this->longitude = _arg;
    return *this;
  }
  Type & set__latitude(
    const double & _arg)
  {
    this->latitude = _arg;
    return *this;
  }
  Type & set__altitude(
    const double & _arg)
  {
    this->altitude = _arg;
    return *this;
  }
  Type & set__label(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->label = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator> *;
  using ConstRawPtr =
    const amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__amap_nav_msgs__msg__WaypointGCJ02
    std::shared_ptr<amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__amap_nav_msgs__msg__WaypointGCJ02
    std::shared_ptr<amap_nav_msgs::msg::WaypointGCJ02_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const WaypointGCJ02_ & other) const
  {
    if (this->longitude != other.longitude) {
      return false;
    }
    if (this->latitude != other.latitude) {
      return false;
    }
    if (this->altitude != other.altitude) {
      return false;
    }
    if (this->label != other.label) {
      return false;
    }
    return true;
  }
  bool operator!=(const WaypointGCJ02_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct WaypointGCJ02_

// alias to use template instance with default allocator
using WaypointGCJ02 =
  amap_nav_msgs::msg::WaypointGCJ02_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__STRUCT_HPP_
