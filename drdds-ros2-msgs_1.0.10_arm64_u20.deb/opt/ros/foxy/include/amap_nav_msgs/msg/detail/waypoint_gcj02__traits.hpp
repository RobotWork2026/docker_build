// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__TRAITS_HPP_
#define AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__TRAITS_HPP_

#include "amap_nav_msgs/msg/detail/waypoint_gcj02__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<amap_nav_msgs::msg::WaypointGCJ02>()
{
  return "amap_nav_msgs::msg::WaypointGCJ02";
}

template<>
inline const char * name<amap_nav_msgs::msg::WaypointGCJ02>()
{
  return "amap_nav_msgs/msg/WaypointGCJ02";
}

template<>
struct has_fixed_size<amap_nav_msgs::msg::WaypointGCJ02>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::msg::WaypointGCJ02>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::msg::WaypointGCJ02>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__TRAITS_HPP_
