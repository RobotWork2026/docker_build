// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice
#ifndef AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "amap_nav_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_amap_nav_msgs
size_t get_serialized_size_amap_nav_msgs__msg__WaypointGCJ02(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_amap_nav_msgs
size_t max_serialized_size_amap_nav_msgs__msg__WaypointGCJ02(
  bool & full_bounded,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_amap_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, amap_nav_msgs, msg, WaypointGCJ02)();

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
