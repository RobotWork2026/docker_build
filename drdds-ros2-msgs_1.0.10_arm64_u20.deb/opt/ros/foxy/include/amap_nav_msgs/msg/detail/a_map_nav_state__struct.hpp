// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from amap_nav_msgs:msg/AMapNavState.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_HPP_
#define AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__amap_nav_msgs__msg__AMapNavState __attribute__((deprecated))
#else
# define DEPRECATED__amap_nav_msgs__msg__AMapNavState __declspec(deprecated)
#endif

namespace amap_nav_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AMapNavState_
{
  using Type = AMapNavState_<ContainerAllocator>;

  explicit AMapNavState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->longitude = 0.0;
      this->latitude = 0.0;
      this->yaw_deg = 0.0;
      this->target_heading = 0.0;
      this->distance_to_destination_m = 0.0;
      this->position_valid = false;
      this->navigation_active = false;
      this->pending_plan = false;
      this->arrival_announced = false;
      this->route_available = false;
      this->need_takeover = false;
      this->takeover_action = "";
      this->destination_text = "";
    }
  }

  explicit AMapNavState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    takeover_action(_alloc),
    destination_text(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->longitude = 0.0;
      this->latitude = 0.0;
      this->yaw_deg = 0.0;
      this->target_heading = 0.0;
      this->distance_to_destination_m = 0.0;
      this->position_valid = false;
      this->navigation_active = false;
      this->pending_plan = false;
      this->arrival_announced = false;
      this->route_available = false;
      this->need_takeover = false;
      this->takeover_action = "";
      this->destination_text = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _longitude_type =
    double;
  _longitude_type longitude;
  using _latitude_type =
    double;
  _latitude_type latitude;
  using _yaw_deg_type =
    double;
  _yaw_deg_type yaw_deg;
  using _target_heading_type =
    double;
  _target_heading_type target_heading;
  using _distance_to_destination_m_type =
    double;
  _distance_to_destination_m_type distance_to_destination_m;
  using _position_valid_type =
    bool;
  _position_valid_type position_valid;
  using _navigation_active_type =
    bool;
  _navigation_active_type navigation_active;
  using _pending_plan_type =
    bool;
  _pending_plan_type pending_plan;
  using _arrival_announced_type =
    bool;
  _arrival_announced_type arrival_announced;
  using _route_available_type =
    bool;
  _route_available_type route_available;
  using _need_takeover_type =
    bool;
  _need_takeover_type need_takeover;
  using _takeover_action_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _takeover_action_type takeover_action;
  using _destination_text_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _destination_text_type destination_text;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__longitude(
    const double & _arg)
  {
    this->longitude = _arg;
    return *this;
  }
  Type & set__latitude(
    const double & _arg)
  {
    this->latitude = _arg;
    return *this;
  }
  Type & set__yaw_deg(
    const double & _arg)
  {
    this->yaw_deg = _arg;
    return *this;
  }
  Type & set__target_heading(
    const double & _arg)
  {
    this->target_heading = _arg;
    return *this;
  }
  Type & set__distance_to_destination_m(
    const double & _arg)
  {
    this->distance_to_destination_m = _arg;
    return *this;
  }
  Type & set__position_valid(
    const bool & _arg)
  {
    this->position_valid = _arg;
    return *this;
  }
  Type & set__navigation_active(
    const bool & _arg)
  {
    this->navigation_active = _arg;
    return *this;
  }
  Type & set__pending_plan(
    const bool & _arg)
  {
    this->pending_plan = _arg;
    return *this;
  }
  Type & set__arrival_announced(
    const bool & _arg)
  {
    this->arrival_announced = _arg;
    return *this;
  }
  Type & set__route_available(
    const bool & _arg)
  {
    this->route_available = _arg;
    return *this;
  }
  Type & set__need_takeover(
    const bool & _arg)
  {
    this->need_takeover = _arg;
    return *this;
  }
  Type & set__takeover_action(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->takeover_action = _arg;
    return *this;
  }
  Type & set__destination_text(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->destination_text = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    amap_nav_msgs::msg::AMapNavState_<ContainerAllocator> *;
  using ConstRawPtr =
    const amap_nav_msgs::msg::AMapNavState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<amap_nav_msgs::msg::AMapNavState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<amap_nav_msgs::msg::AMapNavState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::msg::AMapNavState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::msg::AMapNavState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::msg::AMapNavState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::msg::AMapNavState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<amap_nav_msgs::msg::AMapNavState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<amap_nav_msgs::msg::AMapNavState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__amap_nav_msgs__msg__AMapNavState
    std::shared_ptr<amap_nav_msgs::msg::AMapNavState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__amap_nav_msgs__msg__AMapNavState
    std::shared_ptr<amap_nav_msgs::msg::AMapNavState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AMapNavState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->longitude != other.longitude) {
      return false;
    }
    if (this->latitude != other.latitude) {
      return false;
    }
    if (this->yaw_deg != other.yaw_deg) {
      return false;
    }
    if (this->target_heading != other.target_heading) {
      return false;
    }
    if (this->distance_to_destination_m != other.distance_to_destination_m) {
      return false;
    }
    if (this->position_valid != other.position_valid) {
      return false;
    }
    if (this->navigation_active != other.navigation_active) {
      return false;
    }
    if (this->pending_plan != other.pending_plan) {
      return false;
    }
    if (this->arrival_announced != other.arrival_announced) {
      return false;
    }
    if (this->route_available != other.route_available) {
      return false;
    }
    if (this->need_takeover != other.need_takeover) {
      return false;
    }
    if (this->takeover_action != other.takeover_action) {
      return false;
    }
    if (this->destination_text != other.destination_text) {
      return false;
    }
    return true;
  }
  bool operator!=(const AMapNavState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AMapNavState_

// alias to use template instance with default allocator
using AMapNavState =
  amap_nav_msgs::msg::AMapNavState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_HPP_
