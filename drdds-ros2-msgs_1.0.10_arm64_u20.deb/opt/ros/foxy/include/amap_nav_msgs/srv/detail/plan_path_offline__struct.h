// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from amap_nav_msgs:srv/PlanPathOffline.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__STRUCT_H_
#define AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'path_id'
#include "rosidl_runtime_c/string.h"
// Member 'goal_point'
#include "geometry_msgs/msg/detail/point__struct.h"

// Struct defined in srv/PlanPathOffline in the package amap_nav_msgs.
typedef struct amap_nav_msgs__srv__PlanPathOffline_Request
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String path_id;
  geometry_msgs__msg__Point goal_point;
} amap_nav_msgs__srv__PlanPathOffline_Request;

// Struct for a sequence of amap_nav_msgs__srv__PlanPathOffline_Request.
typedef struct amap_nav_msgs__srv__PlanPathOffline_Request__Sequence
{
  amap_nav_msgs__srv__PlanPathOffline_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__srv__PlanPathOffline_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'planned_path'
// already included above
// #include "geometry_msgs/msg/detail/point__struct.h"

// Struct defined in srv/PlanPathOffline in the package amap_nav_msgs.
typedef struct amap_nav_msgs__srv__PlanPathOffline_Response
{
  geometry_msgs__msg__Point__Sequence planned_path;
} amap_nav_msgs__srv__PlanPathOffline_Response;

// Struct for a sequence of amap_nav_msgs__srv__PlanPathOffline_Response.
typedef struct amap_nav_msgs__srv__PlanPathOffline_Response__Sequence
{
  amap_nav_msgs__srv__PlanPathOffline_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__srv__PlanPathOffline_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__STRUCT_H_
