// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from amap_nav_msgs:srv/StartOnlineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__STRUCT_H_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'amap_payload_json'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/StartOnlineNavigation in the package amap_nav_msgs.
typedef struct amap_nav_msgs__srv__StartOnlineNavigation_Request
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String amap_payload_json;
} amap_nav_msgs__srv__StartOnlineNavigation_Request;

// Struct for a sequence of amap_nav_msgs__srv__StartOnlineNavigation_Request.
typedef struct amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence
{
  amap_nav_msgs__srv__StartOnlineNavigation_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence;


// Constants defined in the message

// Struct defined in srv/StartOnlineNavigation in the package amap_nav_msgs.
typedef struct amap_nav_msgs__srv__StartOnlineNavigation_Response
{
  bool accepted;
} amap_nav_msgs__srv__StartOnlineNavigation_Response;

// Struct for a sequence of amap_nav_msgs__srv__StartOnlineNavigation_Response.
typedef struct amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence
{
  amap_nav_msgs__srv__StartOnlineNavigation_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__STRUCT_H_
