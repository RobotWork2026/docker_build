// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from amap_nav_msgs:srv/StartOnlineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__STRUCT_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__amap_nav_msgs__srv__StartOnlineNavigation_Request __attribute__((deprecated))
#else
# define DEPRECATED__amap_nav_msgs__srv__StartOnlineNavigation_Request __declspec(deprecated)
#endif

namespace amap_nav_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct StartOnlineNavigation_Request_
{
  using Type = StartOnlineNavigation_Request_<ContainerAllocator>;

  explicit StartOnlineNavigation_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->amap_payload_json = "";
    }
  }

  explicit StartOnlineNavigation_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    amap_payload_json(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->amap_payload_json = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _amap_payload_json_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _amap_payload_json_type amap_payload_json;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__amap_payload_json(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->amap_payload_json = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__amap_nav_msgs__srv__StartOnlineNavigation_Request
    std::shared_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__amap_nav_msgs__srv__StartOnlineNavigation_Request
    std::shared_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const StartOnlineNavigation_Request_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->amap_payload_json != other.amap_payload_json) {
      return false;
    }
    return true;
  }
  bool operator!=(const StartOnlineNavigation_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct StartOnlineNavigation_Request_

// alias to use template instance with default allocator
using StartOnlineNavigation_Request =
  amap_nav_msgs::srv::StartOnlineNavigation_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace amap_nav_msgs


#ifndef _WIN32
# define DEPRECATED__amap_nav_msgs__srv__StartOnlineNavigation_Response __attribute__((deprecated))
#else
# define DEPRECATED__amap_nav_msgs__srv__StartOnlineNavigation_Response __declspec(deprecated)
#endif

namespace amap_nav_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct StartOnlineNavigation_Response_
{
  using Type = StartOnlineNavigation_Response_<ContainerAllocator>;

  explicit StartOnlineNavigation_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->accepted = false;
    }
  }

  explicit StartOnlineNavigation_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->accepted = false;
    }
  }

  // field types and members
  using _accepted_type =
    bool;
  _accepted_type accepted;

  // setters for named parameter idiom
  Type & set__accepted(
    const bool & _arg)
  {
    this->accepted = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__amap_nav_msgs__srv__StartOnlineNavigation_Response
    std::shared_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__amap_nav_msgs__srv__StartOnlineNavigation_Response
    std::shared_ptr<amap_nav_msgs::srv::StartOnlineNavigation_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const StartOnlineNavigation_Response_ & other) const
  {
    if (this->accepted != other.accepted) {
      return false;
    }
    return true;
  }
  bool operator!=(const StartOnlineNavigation_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct StartOnlineNavigation_Response_

// alias to use template instance with default allocator
using StartOnlineNavigation_Response =
  amap_nav_msgs::srv::StartOnlineNavigation_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace amap_nav_msgs

namespace amap_nav_msgs
{

namespace srv
{

struct StartOnlineNavigation
{
  using Request = amap_nav_msgs::srv::StartOnlineNavigation_Request;
  using Response = amap_nav_msgs::srv::StartOnlineNavigation_Response;
};

}  // namespace srv

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__STRUCT_HPP_
