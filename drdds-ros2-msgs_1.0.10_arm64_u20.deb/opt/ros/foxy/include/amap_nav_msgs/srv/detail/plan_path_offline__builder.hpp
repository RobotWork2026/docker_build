// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from amap_nav_msgs:srv/PlanPathOffline.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__BUILDER_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__BUILDER_HPP_

#include "amap_nav_msgs/srv/detail/plan_path_offline__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace amap_nav_msgs
{

namespace srv
{

namespace builder
{

class Init_PlanPathOffline_Request_goal_point
{
public:
  explicit Init_PlanPathOffline_Request_goal_point(::amap_nav_msgs::srv::PlanPathOffline_Request & msg)
  : msg_(msg)
  {}
  ::amap_nav_msgs::srv::PlanPathOffline_Request goal_point(::amap_nav_msgs::srv::PlanPathOffline_Request::_goal_point_type arg)
  {
    msg_.goal_point = std::move(arg);
    return std::move(msg_);
  }

private:
  ::amap_nav_msgs::srv::PlanPathOffline_Request msg_;
};

class Init_PlanPathOffline_Request_path_id
{
public:
  explicit Init_PlanPathOffline_Request_path_id(::amap_nav_msgs::srv::PlanPathOffline_Request & msg)
  : msg_(msg)
  {}
  Init_PlanPathOffline_Request_goal_point path_id(::amap_nav_msgs::srv::PlanPathOffline_Request::_path_id_type arg)
  {
    msg_.path_id = std::move(arg);
    return Init_PlanPathOffline_Request_goal_point(msg_);
  }

private:
  ::amap_nav_msgs::srv::PlanPathOffline_Request msg_;
};

class Init_PlanPathOffline_Request_header
{
public:
  Init_PlanPathOffline_Request_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PlanPathOffline_Request_path_id header(::amap_nav_msgs::srv::PlanPathOffline_Request::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_PlanPathOffline_Request_path_id(msg_);
  }

private:
  ::amap_nav_msgs::srv::PlanPathOffline_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::amap_nav_msgs::srv::PlanPathOffline_Request>()
{
  return amap_nav_msgs::srv::builder::Init_PlanPathOffline_Request_header();
}

}  // namespace amap_nav_msgs


namespace amap_nav_msgs
{

namespace srv
{

namespace builder
{

class Init_PlanPathOffline_Response_planned_path
{
public:
  Init_PlanPathOffline_Response_planned_path()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::amap_nav_msgs::srv::PlanPathOffline_Response planned_path(::amap_nav_msgs::srv::PlanPathOffline_Response::_planned_path_type arg)
  {
    msg_.planned_path = std::move(arg);
    return std::move(msg_);
  }

private:
  ::amap_nav_msgs::srv::PlanPathOffline_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::amap_nav_msgs::srv::PlanPathOffline_Response>()
{
  return amap_nav_msgs::srv::builder::Init_PlanPathOffline_Response_planned_path();
}

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__BUILDER_HPP_
