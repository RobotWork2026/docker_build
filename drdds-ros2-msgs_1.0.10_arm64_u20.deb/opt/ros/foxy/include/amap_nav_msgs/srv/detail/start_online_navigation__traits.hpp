// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from amap_nav_msgs:srv/StartOnlineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__TRAITS_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__TRAITS_HPP_

#include "amap_nav_msgs/srv/detail/start_online_navigation__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOnlineNavigation_Request>()
{
  return "amap_nav_msgs::srv::StartOnlineNavigation_Request";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOnlineNavigation_Request>()
{
  return "amap_nav_msgs/srv/StartOnlineNavigation_Request";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::srv::StartOnlineNavigation_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOnlineNavigation_Response>()
{
  return "amap_nav_msgs::srv::StartOnlineNavigation_Response";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOnlineNavigation_Response>()
{
  return "amap_nav_msgs/srv/StartOnlineNavigation_Response";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<amap_nav_msgs::srv::StartOnlineNavigation_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOnlineNavigation>()
{
  return "amap_nav_msgs::srv::StartOnlineNavigation";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOnlineNavigation>()
{
  return "amap_nav_msgs/srv/StartOnlineNavigation";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation>
  : std::integral_constant<
    bool,
    has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation_Request>::value &&
    has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation_Response>::value
  >
{
};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation>
  : std::integral_constant<
    bool,
    has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation_Request>::value &&
    has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation_Response>::value
  >
{
};

template<>
struct is_service<amap_nav_msgs::srv::StartOnlineNavigation>
  : std::true_type
{
};

template<>
struct is_service_request<amap_nav_msgs::srv::StartOnlineNavigation_Request>
  : std::true_type
{
};

template<>
struct is_service_response<amap_nav_msgs::srv::StartOnlineNavigation_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__TRAITS_HPP_
