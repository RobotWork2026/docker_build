// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from amap_nav_msgs:srv/StartOnlineNavigation.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "amap_nav_msgs/srv/detail/start_online_navigation__rosidl_typesupport_introspection_c.h"
#include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "amap_nav_msgs/srv/detail/start_online_navigation__functions.h"
#include "amap_nav_msgs/srv/detail/start_online_navigation__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `amap_payload_json`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  amap_nav_msgs__srv__StartOnlineNavigation_Request__init(message_memory);
}

void StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_fini_function(void * message_memory)
{
  amap_nav_msgs__srv__StartOnlineNavigation_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_member_array[2] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__StartOnlineNavigation_Request, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "amap_payload_json",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__StartOnlineNavigation_Request, amap_payload_json),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_members = {
  "amap_nav_msgs__srv",  // message namespace
  "StartOnlineNavigation_Request",  // message name
  2,  // number of fields
  sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Request),
  StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_member_array,  // message members
  StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_type_support_handle = {
  0,
  &StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOnlineNavigation_Request)() {
  StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_type_support_handle.typesupport_identifier) {
    StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &StartOnlineNavigation_Request__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "amap_nav_msgs/srv/detail/start_online_navigation__rosidl_typesupport_introspection_c.h"
// already included above
// #include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "amap_nav_msgs/srv/detail/start_online_navigation__functions.h"
// already included above
// #include "amap_nav_msgs/srv/detail/start_online_navigation__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  amap_nav_msgs__srv__StartOnlineNavigation_Response__init(message_memory);
}

void StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_fini_function(void * message_memory)
{
  amap_nav_msgs__srv__StartOnlineNavigation_Response__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_member_array[1] = {
  {
    "accepted",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__StartOnlineNavigation_Response, accepted),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_members = {
  "amap_nav_msgs__srv",  // message namespace
  "StartOnlineNavigation_Response",  // message name
  1,  // number of fields
  sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Response),
  StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_member_array,  // message members
  StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_type_support_handle = {
  0,
  &StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOnlineNavigation_Response)() {
  if (!StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_type_support_handle.typesupport_identifier) {
    StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &StartOnlineNavigation_Response__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "amap_nav_msgs/srv/detail/start_online_navigation__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_service_members = {
  "amap_nav_msgs__srv",  // service namespace
  "StartOnlineNavigation",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_Request_message_type_support_handle,
  NULL  // response message
  // amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_Response_message_type_support_handle
};

static rosidl_service_type_support_t amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_service_type_support_handle = {
  0,
  &amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOnlineNavigation_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOnlineNavigation_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOnlineNavigation)() {
  if (!amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_service_type_support_handle.typesupport_identifier) {
    amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOnlineNavigation_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOnlineNavigation_Response)()->data;
  }

  return &amap_nav_msgs__srv__detail__start_online_navigation__rosidl_typesupport_introspection_c__StartOnlineNavigation_service_type_support_handle;
}
