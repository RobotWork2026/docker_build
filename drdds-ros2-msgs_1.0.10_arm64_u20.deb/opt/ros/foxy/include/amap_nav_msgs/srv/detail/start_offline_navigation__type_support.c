// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from amap_nav_msgs:srv/StartOfflineNavigation.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "amap_nav_msgs/srv/detail/start_offline_navigation__rosidl_typesupport_introspection_c.h"
#include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "amap_nav_msgs/srv/detail/start_offline_navigation__functions.h"
#include "amap_nav_msgs/srv/detail/start_offline_navigation__struct.h"


// Include directives for member types
// Member `destination`
#include "rosidl_runtime_c/string_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  amap_nav_msgs__srv__StartOfflineNavigation_Request__init(message_memory);
}

void StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_fini_function(void * message_memory)
{
  amap_nav_msgs__srv__StartOfflineNavigation_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_member_array[1] = {
  {
    "destination",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__StartOfflineNavigation_Request, destination),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_members = {
  "amap_nav_msgs__srv",  // message namespace
  "StartOfflineNavigation_Request",  // message name
  1,  // number of fields
  sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Request),
  StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_member_array,  // message members
  StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_type_support_handle = {
  0,
  &StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOfflineNavigation_Request)() {
  if (!StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_type_support_handle.typesupport_identifier) {
    StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &StartOfflineNavigation_Request__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "amap_nav_msgs/srv/detail/start_offline_navigation__rosidl_typesupport_introspection_c.h"
// already included above
// #include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "amap_nav_msgs/srv/detail/start_offline_navigation__functions.h"
// already included above
// #include "amap_nav_msgs/srv/detail/start_offline_navigation__struct.h"


// Include directives for member types
// Member `planned_path`
#include "geometry_msgs/msg/point.h"
// Member `planned_path`
#include "geometry_msgs/msg/detail/point__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  amap_nav_msgs__srv__StartOfflineNavigation_Response__init(message_memory);
}

void StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_fini_function(void * message_memory)
{
  amap_nav_msgs__srv__StartOfflineNavigation_Response__fini(message_memory);
}

size_t StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__size_function__Point__planned_path(
  const void * untyped_member)
{
  const geometry_msgs__msg__Point__Sequence * member =
    (const geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return member->size;
}

const void * StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__get_const_function__Point__planned_path(
  const void * untyped_member, size_t index)
{
  const geometry_msgs__msg__Point__Sequence * member =
    (const geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return &member->data[index];
}

void * StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__get_function__Point__planned_path(
  void * untyped_member, size_t index)
{
  geometry_msgs__msg__Point__Sequence * member =
    (geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return &member->data[index];
}

bool StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__resize_function__Point__planned_path(
  void * untyped_member, size_t size)
{
  geometry_msgs__msg__Point__Sequence * member =
    (geometry_msgs__msg__Point__Sequence *)(untyped_member);
  geometry_msgs__msg__Point__Sequence__fini(member);
  return geometry_msgs__msg__Point__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_member_array[2] = {
  {
    "accepted",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__StartOfflineNavigation_Response, accepted),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "planned_path",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__StartOfflineNavigation_Response, planned_path),  // bytes offset in struct
    NULL,  // default value
    StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__size_function__Point__planned_path,  // size() function pointer
    StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__get_const_function__Point__planned_path,  // get_const(index) function pointer
    StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__get_function__Point__planned_path,  // get(index) function pointer
    StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__resize_function__Point__planned_path  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_members = {
  "amap_nav_msgs__srv",  // message namespace
  "StartOfflineNavigation_Response",  // message name
  2,  // number of fields
  sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Response),
  StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_member_array,  // message members
  StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_type_support_handle = {
  0,
  &StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOfflineNavigation_Response)() {
  StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Point)();
  if (!StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_type_support_handle.typesupport_identifier) {
    StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &StartOfflineNavigation_Response__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "amap_nav_msgs/srv/detail/start_offline_navigation__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_service_members = {
  "amap_nav_msgs__srv",  // service namespace
  "StartOfflineNavigation",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_Request_message_type_support_handle,
  NULL  // response message
  // amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_Response_message_type_support_handle
};

static rosidl_service_type_support_t amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_service_type_support_handle = {
  0,
  &amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOfflineNavigation_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOfflineNavigation_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOfflineNavigation)() {
  if (!amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_service_type_support_handle.typesupport_identifier) {
    amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOfflineNavigation_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, StartOfflineNavigation_Response)()->data;
  }

  return &amap_nav_msgs__srv__detail__start_offline_navigation__rosidl_typesupport_introspection_c__StartOfflineNavigation_service_type_support_handle;
}
