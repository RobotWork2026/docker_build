// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from amap_nav_msgs:srv/StartOfflineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__STRUCT_H_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'destination'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/StartOfflineNavigation in the package amap_nav_msgs.
typedef struct amap_nav_msgs__srv__StartOfflineNavigation_Request
{
  rosidl_runtime_c__String destination;
} amap_nav_msgs__srv__StartOfflineNavigation_Request;

// Struct for a sequence of amap_nav_msgs__srv__StartOfflineNavigation_Request.
typedef struct amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence
{
  amap_nav_msgs__srv__StartOfflineNavigation_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'planned_path'
#include "geometry_msgs/msg/detail/point__struct.h"

// Struct defined in srv/StartOfflineNavigation in the package amap_nav_msgs.
typedef struct amap_nav_msgs__srv__StartOfflineNavigation_Response
{
  bool accepted;
  geometry_msgs__msg__Point__Sequence planned_path;
} amap_nav_msgs__srv__StartOfflineNavigation_Response;

// Struct for a sequence of amap_nav_msgs__srv__StartOfflineNavigation_Response.
typedef struct amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence
{
  amap_nav_msgs__srv__StartOfflineNavigation_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__STRUCT_H_
