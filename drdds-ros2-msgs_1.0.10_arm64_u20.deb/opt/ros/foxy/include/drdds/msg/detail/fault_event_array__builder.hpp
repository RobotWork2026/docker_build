// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/FaultEventArray.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__BUILDER_HPP_

#include "drdds/msg/detail/fault_event_array__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_FaultEventArray_active_faults
{
public:
  explicit Init_FaultEventArray_active_faults(::drdds::msg::FaultEventArray & msg)
  : msg_(msg)
  {}
  ::drdds::msg::FaultEventArray active_faults(::drdds::msg::FaultEventArray::_active_faults_type arg)
  {
    msg_.active_faults = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::FaultEventArray msg_;
};

class Init_FaultEventArray_timestamp
{
public:
  Init_FaultEventArray_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FaultEventArray_active_faults timestamp(::drdds::msg::FaultEventArray::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_FaultEventArray_active_faults(msg_);
  }

private:
  ::drdds::msg::FaultEventArray msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::FaultEventArray>()
{
  return drdds::msg::builder::Init_FaultEventArray_timestamp();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__BUILDER_HPP_
