// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/CpuDataValue.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/cpu_data_value__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `cpu_temperature`
// Member `cpu_frequency`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
drdds__msg__CpuDataValue__init(drdds__msg__CpuDataValue * msg)
{
  if (!msg) {
    return false;
  }
  // cpu_temperature
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->cpu_temperature, 0)) {
    drdds__msg__CpuDataValue__fini(msg);
    return false;
  }
  // cpu_frequency
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->cpu_frequency, 0)) {
    drdds__msg__CpuDataValue__fini(msg);
    return false;
  }
  return true;
}

void
drdds__msg__CpuDataValue__fini(drdds__msg__CpuDataValue * msg)
{
  if (!msg) {
    return;
  }
  // cpu_temperature
  rosidl_runtime_c__uint32__Sequence__fini(&msg->cpu_temperature);
  // cpu_frequency
  rosidl_runtime_c__uint32__Sequence__fini(&msg->cpu_frequency);
}

bool
drdds__msg__CpuDataValue__are_equal(const drdds__msg__CpuDataValue * lhs, const drdds__msg__CpuDataValue * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // cpu_temperature
  if (!rosidl_runtime_c__uint32__Sequence__are_equal(
      &(lhs->cpu_temperature), &(rhs->cpu_temperature)))
  {
    return false;
  }
  // cpu_frequency
  if (!rosidl_runtime_c__uint32__Sequence__are_equal(
      &(lhs->cpu_frequency), &(rhs->cpu_frequency)))
  {
    return false;
  }
  return true;
}

bool
drdds__msg__CpuDataValue__copy(
  const drdds__msg__CpuDataValue * input,
  drdds__msg__CpuDataValue * output)
{
  if (!input || !output) {
    return false;
  }
  // cpu_temperature
  if (!rosidl_runtime_c__uint32__Sequence__copy(
      &(input->cpu_temperature), &(output->cpu_temperature)))
  {
    return false;
  }
  // cpu_frequency
  if (!rosidl_runtime_c__uint32__Sequence__copy(
      &(input->cpu_frequency), &(output->cpu_frequency)))
  {
    return false;
  }
  return true;
}

drdds__msg__CpuDataValue *
drdds__msg__CpuDataValue__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__CpuDataValue * msg = (drdds__msg__CpuDataValue *)allocator.allocate(sizeof(drdds__msg__CpuDataValue), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__CpuDataValue));
  bool success = drdds__msg__CpuDataValue__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__CpuDataValue__destroy(drdds__msg__CpuDataValue * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__CpuDataValue__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__CpuDataValue__Sequence__init(drdds__msg__CpuDataValue__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__CpuDataValue * data = NULL;

  if (size) {
    data = (drdds__msg__CpuDataValue *)allocator.zero_allocate(size, sizeof(drdds__msg__CpuDataValue), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__CpuDataValue__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__CpuDataValue__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__CpuDataValue__Sequence__fini(drdds__msg__CpuDataValue__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__CpuDataValue__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__CpuDataValue__Sequence *
drdds__msg__CpuDataValue__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__CpuDataValue__Sequence * array = (drdds__msg__CpuDataValue__Sequence *)allocator.allocate(sizeof(drdds__msg__CpuDataValue__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__CpuDataValue__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__CpuDataValue__Sequence__destroy(drdds__msg__CpuDataValue__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__CpuDataValue__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__CpuDataValue__Sequence__are_equal(const drdds__msg__CpuDataValue__Sequence * lhs, const drdds__msg__CpuDataValue__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__CpuDataValue__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__CpuDataValue__Sequence__copy(
  const drdds__msg__CpuDataValue__Sequence * input,
  drdds__msg__CpuDataValue__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__CpuDataValue);
    drdds__msg__CpuDataValue * data =
      (drdds__msg__CpuDataValue *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__CpuDataValue__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          drdds__msg__CpuDataValue__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__CpuDataValue__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
