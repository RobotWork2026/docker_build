// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from drdds:msg/AiryLidarStatus.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "drdds/msg/detail/airy_lidar_status__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace drdds
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void AiryLidarStatus_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) drdds::msg::AiryLidarStatus(_init);
}

void AiryLidarStatus_fini_function(void * message_memory)
{
  auto typed_message = static_cast<drdds::msg::AiryLidarStatus *>(message_memory);
  typed_message->~AiryLidarStatus();
}

size_t size_function__AiryLidarStatus__data(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<drdds::msg::AiryLidarValue> *>(untyped_member);
  return member->size();
}

const void * get_const_function__AiryLidarStatus__data(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<drdds::msg::AiryLidarValue> *>(untyped_member);
  return &member[index];
}

void * get_function__AiryLidarStatus__data(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<drdds::msg::AiryLidarValue> *>(untyped_member);
  return &member[index];
}

void resize_function__AiryLidarStatus__data(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<drdds::msg::AiryLidarValue> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember AiryLidarStatus_message_member_array[2] = {
  {
    "header",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<drdds::msg::MetaType>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::AiryLidarStatus, header),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "data",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<drdds::msg::AiryLidarValue>(),  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::AiryLidarStatus, data),  // bytes offset in struct
    nullptr,  // default value
    size_function__AiryLidarStatus__data,  // size() function pointer
    get_const_function__AiryLidarStatus__data,  // get_const(index) function pointer
    get_function__AiryLidarStatus__data,  // get(index) function pointer
    resize_function__AiryLidarStatus__data  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers AiryLidarStatus_message_members = {
  "drdds::msg",  // message namespace
  "AiryLidarStatus",  // message name
  2,  // number of fields
  sizeof(drdds::msg::AiryLidarStatus),
  AiryLidarStatus_message_member_array,  // message members
  AiryLidarStatus_init_function,  // function to initialize message memory (memory has to be allocated)
  AiryLidarStatus_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t AiryLidarStatus_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &AiryLidarStatus_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace drdds


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<drdds::msg::AiryLidarStatus>()
{
  return &::drdds::msg::rosidl_typesupport_introspection_cpp::AiryLidarStatus_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, drdds, msg, AiryLidarStatus)() {
  return &::drdds::msg::rosidl_typesupport_introspection_cpp::AiryLidarStatus_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
