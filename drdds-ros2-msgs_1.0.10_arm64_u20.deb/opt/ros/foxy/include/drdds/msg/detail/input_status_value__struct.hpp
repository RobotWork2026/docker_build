// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/InputStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__drdds__msg__InputStatusValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__InputStatusValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct InputStatusValue_
{
  using Type = InputStatusValue_<ContainerAllocator>;

  explicit InputStatusValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->lidar = 0;
      this->imu = 0;
      this->leg_odom = 0;
      this->rtk = 0;
      this->tag = 0;
      this->reflective_strip = 0;
    }
  }

  explicit InputStatusValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->lidar = 0;
      this->imu = 0;
      this->leg_odom = 0;
      this->rtk = 0;
      this->tag = 0;
      this->reflective_strip = 0;
    }
  }

  // field types and members
  using _lidar_type =
    uint8_t;
  _lidar_type lidar;
  using _imu_type =
    uint8_t;
  _imu_type imu;
  using _leg_odom_type =
    uint8_t;
  _leg_odom_type leg_odom;
  using _rtk_type =
    uint8_t;
  _rtk_type rtk;
  using _tag_type =
    uint8_t;
  _tag_type tag;
  using _reflective_strip_type =
    uint8_t;
  _reflective_strip_type reflective_strip;

  // setters for named parameter idiom
  Type & set__lidar(
    const uint8_t & _arg)
  {
    this->lidar = _arg;
    return *this;
  }
  Type & set__imu(
    const uint8_t & _arg)
  {
    this->imu = _arg;
    return *this;
  }
  Type & set__leg_odom(
    const uint8_t & _arg)
  {
    this->leg_odom = _arg;
    return *this;
  }
  Type & set__rtk(
    const uint8_t & _arg)
  {
    this->rtk = _arg;
    return *this;
  }
  Type & set__tag(
    const uint8_t & _arg)
  {
    this->tag = _arg;
    return *this;
  }
  Type & set__reflective_strip(
    const uint8_t & _arg)
  {
    this->reflective_strip = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::InputStatusValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::InputStatusValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::InputStatusValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::InputStatusValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::InputStatusValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::InputStatusValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::InputStatusValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::InputStatusValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::InputStatusValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::InputStatusValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__InputStatusValue
    std::shared_ptr<drdds::msg::InputStatusValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__InputStatusValue
    std::shared_ptr<drdds::msg::InputStatusValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const InputStatusValue_ & other) const
  {
    if (this->lidar != other.lidar) {
      return false;
    }
    if (this->imu != other.imu) {
      return false;
    }
    if (this->leg_odom != other.leg_odom) {
      return false;
    }
    if (this->rtk != other.rtk) {
      return false;
    }
    if (this->tag != other.tag) {
      return false;
    }
    if (this->reflective_strip != other.reflective_strip) {
      return false;
    }
    return true;
  }
  bool operator!=(const InputStatusValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct InputStatusValue_

// alias to use template instance with default allocator
using InputStatusValue =
  drdds::msg::InputStatusValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__STRUCT_HPP_
