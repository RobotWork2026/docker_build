// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__BUILDER_HPP_

#include "drdds/msg/detail/battery_data_value__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_BatteryDataValue_battery_serialnum
{
public:
  explicit Init_BatteryDataValue_battery_serialnum(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::BatteryDataValue battery_serialnum(::drdds::msg::BatteryDataValue::_battery_serialnum_type arg)
  {
    msg_.battery_serialnum = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_battery_temperature
{
public:
  explicit Init_BatteryDataValue_battery_temperature(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_battery_serialnum battery_temperature(::drdds::msg::BatteryDataValue::_battery_temperature_type arg)
  {
    msg_.battery_temperature = std::move(arg);
    return Init_BatteryDataValue_battery_serialnum(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_battery_ntc
{
public:
  explicit Init_BatteryDataValue_battery_ntc(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_battery_temperature battery_ntc(::drdds::msg::BatteryDataValue::_battery_ntc_type arg)
  {
    msg_.battery_ntc = std::move(arg);
    return Init_BatteryDataValue_battery_temperature(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_battery_quantity
{
public:
  explicit Init_BatteryDataValue_battery_quantity(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_battery_ntc battery_quantity(::drdds::msg::BatteryDataValue::_battery_quantity_type arg)
  {
    msg_.battery_quantity = std::move(arg);
    return Init_BatteryDataValue_battery_ntc(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_mos_state
{
public:
  explicit Init_BatteryDataValue_mos_state(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_battery_quantity mos_state(::drdds::msg::BatteryDataValue::_mos_state_type arg)
  {
    msg_.mos_state = std::move(arg);
    return Init_BatteryDataValue_battery_quantity(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_battery_level
{
public:
  explicit Init_BatteryDataValue_battery_level(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_mos_state battery_level(::drdds::msg::BatteryDataValue::_battery_level_type arg)
  {
    msg_.battery_level = std::move(arg);
    return Init_BatteryDataValue_mos_state(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_software_version
{
public:
  explicit Init_BatteryDataValue_software_version(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_battery_level software_version(::drdds::msg::BatteryDataValue::_software_version_type arg)
  {
    msg_.software_version = std::move(arg);
    return Init_BatteryDataValue_battery_level(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_protected_state
{
public:
  explicit Init_BatteryDataValue_protected_state(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_software_version protected_state(::drdds::msg::BatteryDataValue::_protected_state_type arg)
  {
    msg_.protected_state = std::move(arg);
    return Init_BatteryDataValue_software_version(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_balanced_high
{
public:
  explicit Init_BatteryDataValue_balanced_high(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_protected_state balanced_high(::drdds::msg::BatteryDataValue::_balanced_high_type arg)
  {
    msg_.balanced_high = std::move(arg);
    return Init_BatteryDataValue_protected_state(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_balanced_low
{
public:
  explicit Init_BatteryDataValue_balanced_low(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_balanced_high balanced_low(::drdds::msg::BatteryDataValue::_balanced_low_type arg)
  {
    msg_.balanced_low = std::move(arg);
    return Init_BatteryDataValue_balanced_high(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_production_date
{
public:
  explicit Init_BatteryDataValue_production_date(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_balanced_low production_date(::drdds::msg::BatteryDataValue::_production_date_type arg)
  {
    msg_.production_date = std::move(arg);
    return Init_BatteryDataValue_balanced_low(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_cycles
{
public:
  explicit Init_BatteryDataValue_cycles(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_production_date cycles(::drdds::msg::BatteryDataValue::_cycles_type arg)
  {
    msg_.cycles = std::move(arg);
    return Init_BatteryDataValue_production_date(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_nominal_capacity
{
public:
  explicit Init_BatteryDataValue_nominal_capacity(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_cycles nominal_capacity(::drdds::msg::BatteryDataValue::_nominal_capacity_type arg)
  {
    msg_.nominal_capacity = std::move(arg);
    return Init_BatteryDataValue_cycles(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_remaining_capacity
{
public:
  explicit Init_BatteryDataValue_remaining_capacity(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_nominal_capacity remaining_capacity(::drdds::msg::BatteryDataValue::_remaining_capacity_type arg)
  {
    msg_.remaining_capacity = std::move(arg);
    return Init_BatteryDataValue_nominal_capacity(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_current
{
public:
  explicit Init_BatteryDataValue_current(::drdds::msg::BatteryDataValue & msg)
  : msg_(msg)
  {}
  Init_BatteryDataValue_remaining_capacity current(::drdds::msg::BatteryDataValue::_current_type arg)
  {
    msg_.current = std::move(arg);
    return Init_BatteryDataValue_remaining_capacity(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

class Init_BatteryDataValue_voltage
{
public:
  Init_BatteryDataValue_voltage()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BatteryDataValue_current voltage(::drdds::msg::BatteryDataValue::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_BatteryDataValue_current(msg_);
  }

private:
  ::drdds::msg::BatteryDataValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::BatteryDataValue>()
{
  return drdds::msg::builder::Init_BatteryDataValue_voltage();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__BUILDER_HPP_
