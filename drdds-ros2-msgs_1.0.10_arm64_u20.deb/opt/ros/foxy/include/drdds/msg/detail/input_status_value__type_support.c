// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/InputStatusValue.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/input_status_value__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/input_status_value__functions.h"
#include "drdds/msg/detail/input_status_value__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__InputStatusValue__init(message_memory);
}

void InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_fini_function(void * message_memory)
{
  drdds__msg__InputStatusValue__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_message_member_array[6] = {
  {
    "lidar",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__InputStatusValue, lidar),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "imu",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__InputStatusValue, imu),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "leg_odom",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__InputStatusValue, leg_odom),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "rtk",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__InputStatusValue, rtk),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "tag",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__InputStatusValue, tag),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "reflective_strip",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__InputStatusValue, reflective_strip),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_message_members = {
  "drdds__msg",  // message namespace
  "InputStatusValue",  // message name
  6,  // number of fields
  sizeof(drdds__msg__InputStatusValue),
  InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_message_member_array,  // message members
  InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_init_function,  // function to initialize message memory (memory has to be allocated)
  InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_message_type_support_handle = {
  0,
  &InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, InputStatusValue)() {
  if (!InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_message_type_support_handle.typesupport_identifier) {
    InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &InputStatusValue__rosidl_typesupport_introspection_c__InputStatusValue_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
