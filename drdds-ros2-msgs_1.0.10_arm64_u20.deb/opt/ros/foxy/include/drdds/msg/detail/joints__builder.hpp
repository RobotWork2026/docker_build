// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/Joints.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINTS__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__JOINTS__BUILDER_HPP_

#include "drdds/msg/detail/joints__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_Joints_data
{
public:
  explicit Init_Joints_data(::drdds::msg::Joints & msg)
  : msg_(msg)
  {}
  ::drdds::msg::Joints data(::drdds::msg::Joints::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::Joints msg_;
};

class Init_Joints_header
{
public:
  Init_Joints_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Joints_data header(::drdds::msg::Joints::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Joints_data(msg_);
  }

private:
  ::drdds::msg::Joints msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::Joints>()
{
  return drdds::msg::builder::Init_Joints_header();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__JOINTS__BUILDER_HPP_
