// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/GridID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRID_ID__STRUCT_H_
#define DRDDS__MSG__DETAIL__GRID_ID__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/GridID in the package drdds.
typedef struct drdds__msg__GridID
{
  int32_t id;
  rosidl_runtime_c__String name;
} drdds__msg__GridID;

// Struct for a sequence of drdds__msg__GridID.
typedef struct drdds__msg__GridID__Sequence
{
  drdds__msg__GridID * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__GridID__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__GRID_ID__STRUCT_H_
