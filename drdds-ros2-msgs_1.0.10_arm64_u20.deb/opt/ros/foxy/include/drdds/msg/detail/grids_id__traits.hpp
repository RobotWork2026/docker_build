// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/GridsID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRIDS_ID__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__GRIDS_ID__TRAITS_HPP_

#include "drdds/msg/detail/grids_id__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::GridsID>()
{
  return "drdds::msg::GridsID";
}

template<>
inline const char * name<drdds::msg::GridsID>()
{
  return "drdds/msg/GridsID";
}

template<>
struct has_fixed_size<drdds::msg::GridsID>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::GridsID>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::GridsID>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__GRIDS_ID__TRAITS_HPP_
