// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/AiryLidarStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__BUILDER_HPP_

#include "drdds/msg/detail/airy_lidar_status__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_AiryLidarStatus_data
{
public:
  explicit Init_AiryLidarStatus_data(::drdds::msg::AiryLidarStatus & msg)
  : msg_(msg)
  {}
  ::drdds::msg::AiryLidarStatus data(::drdds::msg::AiryLidarStatus::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::AiryLidarStatus msg_;
};

class Init_AiryLidarStatus_header
{
public:
  Init_AiryLidarStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AiryLidarStatus_data header(::drdds::msg::AiryLidarStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_AiryLidarStatus_data(msg_);
  }

private:
  ::drdds::msg::AiryLidarStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::AiryLidarStatus>()
{
  return drdds::msg::builder::Init_AiryLidarStatus_header();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__BUILDER_HPP_
