// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/CPUStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_STATUS__STRUCT_H_
#define DRDDS__MSG__DETAIL__CPU_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'soc_id'
// Member 'gov_policy'
#include "rosidl_runtime_c/string.h"
// Member 'temps'
// Member 'util'
// Member 'cur_freq_khz'
// Member 'hw_max_freq_khz'
// Member 'hw_min_freq_khz'
#include "rosidl_runtime_c/primitives_sequence.h"

// Struct defined in msg/CPUStatus in the package drdds.
typedef struct drdds__msg__CPUStatus
{
  builtin_interfaces__msg__Time timestamp;
  rosidl_runtime_c__String soc_id;
  int32_t package_temp;
  rosidl_runtime_c__int32__Sequence temps;
  uint16_t avg_util;
  rosidl_runtime_c__uint16__Sequence util;
  rosidl_runtime_c__uint32__Sequence cur_freq_khz;
  rosidl_runtime_c__uint32__Sequence hw_max_freq_khz;
  rosidl_runtime_c__uint32__Sequence hw_min_freq_khz;
  rosidl_runtime_c__String__Sequence gov_policy;
} drdds__msg__CPUStatus;

// Struct for a sequence of drdds__msg__CPUStatus.
typedef struct drdds__msg__CPUStatus__Sequence
{
  drdds__msg__CPUStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__CPUStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__CPU_STATUS__STRUCT_H_
