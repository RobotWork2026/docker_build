// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/Gait.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GAIT__STRUCT_H_
#define DRDDS__MSG__DETAIL__GAIT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__struct.h"
// Member 'data'
#include "drdds/msg/detail/gait_value__struct.h"

// Struct defined in msg/Gait in the package drdds.
typedef struct drdds__msg__Gait
{
  drdds__msg__MetaType header;
  drdds__msg__GaitValue data;
} drdds__msg__Gait;

// Struct for a sequence of drdds__msg__Gait.
typedef struct drdds__msg__Gait__Sequence
{
  drdds__msg__Gait * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__Gait__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__GAIT__STRUCT_H_
