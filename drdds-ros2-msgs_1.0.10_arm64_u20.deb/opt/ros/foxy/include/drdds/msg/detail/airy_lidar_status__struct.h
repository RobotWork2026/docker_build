// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/AiryLidarStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__STRUCT_H_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__struct.h"
// Member 'data'
#include "drdds/msg/detail/airy_lidar_value__struct.h"

// Struct defined in msg/AiryLidarStatus in the package drdds.
typedef struct drdds__msg__AiryLidarStatus
{
  drdds__msg__MetaType header;
  drdds__msg__AiryLidarValue__Sequence data;
} drdds__msg__AiryLidarStatus;

// Struct for a sequence of drdds__msg__AiryLidarStatus.
typedef struct drdds__msg__AiryLidarStatus__Sequence
{
  drdds__msg__AiryLidarStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__AiryLidarStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__STRUCT_H_
