// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/JointData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_DATA__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__JOINT_DATA__BUILDER_HPP_

#include "drdds/msg/detail/joint_data__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_JointData_driver_temp
{
public:
  explicit Init_JointData_driver_temp(::drdds::msg::JointData & msg)
  : msg_(msg)
  {}
  ::drdds::msg::JointData driver_temp(::drdds::msg::JointData::_driver_temp_type arg)
  {
    msg_.driver_temp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::JointData msg_;
};

class Init_JointData_motion_temp
{
public:
  explicit Init_JointData_motion_temp(::drdds::msg::JointData & msg)
  : msg_(msg)
  {}
  Init_JointData_driver_temp motion_temp(::drdds::msg::JointData::_motion_temp_type arg)
  {
    msg_.motion_temp = std::move(arg);
    return Init_JointData_driver_temp(msg_);
  }

private:
  ::drdds::msg::JointData msg_;
};

class Init_JointData_velocity
{
public:
  explicit Init_JointData_velocity(::drdds::msg::JointData & msg)
  : msg_(msg)
  {}
  Init_JointData_motion_temp velocity(::drdds::msg::JointData::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_JointData_motion_temp(msg_);
  }

private:
  ::drdds::msg::JointData msg_;
};

class Init_JointData_torque
{
public:
  explicit Init_JointData_torque(::drdds::msg::JointData & msg)
  : msg_(msg)
  {}
  Init_JointData_velocity torque(::drdds::msg::JointData::_torque_type arg)
  {
    msg_.torque = std::move(arg);
    return Init_JointData_velocity(msg_);
  }

private:
  ::drdds::msg::JointData msg_;
};

class Init_JointData_position
{
public:
  explicit Init_JointData_position(::drdds::msg::JointData & msg)
  : msg_(msg)
  {}
  Init_JointData_torque position(::drdds::msg::JointData::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_JointData_torque(msg_);
  }

private:
  ::drdds::msg::JointData msg_;
};

class Init_JointData_status_word
{
public:
  explicit Init_JointData_status_word(::drdds::msg::JointData & msg)
  : msg_(msg)
  {}
  Init_JointData_position status_word(::drdds::msg::JointData::_status_word_type arg)
  {
    msg_.status_word = std::move(arg);
    return Init_JointData_position(msg_);
  }

private:
  ::drdds::msg::JointData msg_;
};

class Init_JointData_data_id
{
public:
  explicit Init_JointData_data_id(::drdds::msg::JointData & msg)
  : msg_(msg)
  {}
  Init_JointData_status_word data_id(::drdds::msg::JointData::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_JointData_status_word(msg_);
  }

private:
  ::drdds::msg::JointData msg_;
};

class Init_JointData_name
{
public:
  Init_JointData_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_JointData_data_id name(::drdds::msg::JointData::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_JointData_data_id(msg_);
  }

private:
  ::drdds::msg::JointData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::JointData>()
{
  return drdds::msg::builder::Init_JointData_name();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__JOINT_DATA__BUILDER_HPP_
