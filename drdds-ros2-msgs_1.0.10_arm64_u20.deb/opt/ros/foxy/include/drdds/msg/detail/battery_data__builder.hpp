// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/BatteryData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__BATTERY_DATA__BUILDER_HPP_

#include "drdds/msg/detail/battery_data__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_BatteryData_data
{
public:
  explicit Init_BatteryData_data(::drdds::msg::BatteryData & msg)
  : msg_(msg)
  {}
  ::drdds::msg::BatteryData data(::drdds::msg::BatteryData::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::BatteryData msg_;
};

class Init_BatteryData_header
{
public:
  Init_BatteryData_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BatteryData_data header(::drdds::msg::BatteryData::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_BatteryData_data(msg_);
  }

private:
  ::drdds::msg::BatteryData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::BatteryData>()
{
  return drdds::msg::builder::Init_BatteryData_header();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA__BUILDER_HPP_
