// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/ImuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__IMU_DATA_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__IMU_DATA_VALUE__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__drdds__msg__ImuDataValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__ImuDataValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ImuDataValue_
{
  using Type = ImuDataValue_<ContainerAllocator>;

  explicit ImuDataValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->roll = 0.0f;
      this->pitch = 0.0f;
      this->yaw = 0.0f;
      this->omega_x = 0.0f;
      this->omega_y = 0.0f;
      this->omega_z = 0.0f;
      this->acc_x = 0.0f;
      this->acc_y = 0.0f;
      this->acc_z = 0.0f;
    }
  }

  explicit ImuDataValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->roll = 0.0f;
      this->pitch = 0.0f;
      this->yaw = 0.0f;
      this->omega_x = 0.0f;
      this->omega_y = 0.0f;
      this->omega_z = 0.0f;
      this->acc_x = 0.0f;
      this->acc_y = 0.0f;
      this->acc_z = 0.0f;
    }
  }

  // field types and members
  using _roll_type =
    float;
  _roll_type roll;
  using _pitch_type =
    float;
  _pitch_type pitch;
  using _yaw_type =
    float;
  _yaw_type yaw;
  using _omega_x_type =
    float;
  _omega_x_type omega_x;
  using _omega_y_type =
    float;
  _omega_y_type omega_y;
  using _omega_z_type =
    float;
  _omega_z_type omega_z;
  using _acc_x_type =
    float;
  _acc_x_type acc_x;
  using _acc_y_type =
    float;
  _acc_y_type acc_y;
  using _acc_z_type =
    float;
  _acc_z_type acc_z;

  // setters for named parameter idiom
  Type & set__roll(
    const float & _arg)
  {
    this->roll = _arg;
    return *this;
  }
  Type & set__pitch(
    const float & _arg)
  {
    this->pitch = _arg;
    return *this;
  }
  Type & set__yaw(
    const float & _arg)
  {
    this->yaw = _arg;
    return *this;
  }
  Type & set__omega_x(
    const float & _arg)
  {
    this->omega_x = _arg;
    return *this;
  }
  Type & set__omega_y(
    const float & _arg)
  {
    this->omega_y = _arg;
    return *this;
  }
  Type & set__omega_z(
    const float & _arg)
  {
    this->omega_z = _arg;
    return *this;
  }
  Type & set__acc_x(
    const float & _arg)
  {
    this->acc_x = _arg;
    return *this;
  }
  Type & set__acc_y(
    const float & _arg)
  {
    this->acc_y = _arg;
    return *this;
  }
  Type & set__acc_z(
    const float & _arg)
  {
    this->acc_z = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::ImuDataValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::ImuDataValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::ImuDataValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::ImuDataValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::ImuDataValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::ImuDataValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::ImuDataValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::ImuDataValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::ImuDataValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::ImuDataValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__ImuDataValue
    std::shared_ptr<drdds::msg::ImuDataValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__ImuDataValue
    std::shared_ptr<drdds::msg::ImuDataValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ImuDataValue_ & other) const
  {
    if (this->roll != other.roll) {
      return false;
    }
    if (this->pitch != other.pitch) {
      return false;
    }
    if (this->yaw != other.yaw) {
      return false;
    }
    if (this->omega_x != other.omega_x) {
      return false;
    }
    if (this->omega_y != other.omega_y) {
      return false;
    }
    if (this->omega_z != other.omega_z) {
      return false;
    }
    if (this->acc_x != other.acc_x) {
      return false;
    }
    if (this->acc_y != other.acc_y) {
      return false;
    }
    if (this->acc_z != other.acc_z) {
      return false;
    }
    return true;
  }
  bool operator!=(const ImuDataValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ImuDataValue_

// alias to use template instance with default allocator
using ImuDataValue =
  drdds::msg::ImuDataValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__IMU_DATA_VALUE__STRUCT_HPP_
