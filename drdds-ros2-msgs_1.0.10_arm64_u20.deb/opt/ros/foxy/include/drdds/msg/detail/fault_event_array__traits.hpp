// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/FaultEventArray.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__TRAITS_HPP_

#include "drdds/msg/detail/fault_event_array__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::FaultEventArray>()
{
  return "drdds::msg::FaultEventArray";
}

template<>
inline const char * name<drdds::msg::FaultEventArray>()
{
  return "drdds/msg/FaultEventArray";
}

template<>
struct has_fixed_size<drdds::msg::FaultEventArray>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::FaultEventArray>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::FaultEventArray>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__TRAITS_HPP_
