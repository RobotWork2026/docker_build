// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/GridsID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRIDS_ID__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__GRIDS_ID__BUILDER_HPP_

#include "drdds/msg/detail/grids_id__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_GridsID_grids
{
public:
  explicit Init_GridsID_grids(::drdds::msg::GridsID & msg)
  : msg_(msg)
  {}
  ::drdds::msg::GridsID grids(::drdds::msg::GridsID::_grids_type arg)
  {
    msg_.grids = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::GridsID msg_;
};

class Init_GridsID_path
{
public:
  Init_GridsID_path()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GridsID_grids path(::drdds::msg::GridsID::_path_type arg)
  {
    msg_.path = std::move(arg);
    return Init_GridsID_grids(msg_);
  }

private:
  ::drdds::msg::GridsID msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::GridsID>()
{
  return drdds::msg::builder::Init_GridsID_path();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__GRIDS_ID__BUILDER_HPP_
