// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/GridsID.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/grids_id__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/grids_id__functions.h"
#include "drdds/msg/detail/grids_id__struct.h"


// Include directives for member types
// Member `path`
#include "rosidl_runtime_c/string_functions.h"
// Member `grids`
#include "drdds/msg/grid_id.h"
// Member `grids`
#include "drdds/msg/detail/grid_id__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void GridsID__rosidl_typesupport_introspection_c__GridsID_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__GridsID__init(message_memory);
}

void GridsID__rosidl_typesupport_introspection_c__GridsID_fini_function(void * message_memory)
{
  drdds__msg__GridsID__fini(message_memory);
}

size_t GridsID__rosidl_typesupport_introspection_c__size_function__GridID__grids(
  const void * untyped_member)
{
  const drdds__msg__GridID__Sequence * member =
    (const drdds__msg__GridID__Sequence *)(untyped_member);
  return member->size;
}

const void * GridsID__rosidl_typesupport_introspection_c__get_const_function__GridID__grids(
  const void * untyped_member, size_t index)
{
  const drdds__msg__GridID__Sequence * member =
    (const drdds__msg__GridID__Sequence *)(untyped_member);
  return &member->data[index];
}

void * GridsID__rosidl_typesupport_introspection_c__get_function__GridID__grids(
  void * untyped_member, size_t index)
{
  drdds__msg__GridID__Sequence * member =
    (drdds__msg__GridID__Sequence *)(untyped_member);
  return &member->data[index];
}

bool GridsID__rosidl_typesupport_introspection_c__resize_function__GridID__grids(
  void * untyped_member, size_t size)
{
  drdds__msg__GridID__Sequence * member =
    (drdds__msg__GridID__Sequence *)(untyped_member);
  drdds__msg__GridID__Sequence__fini(member);
  return drdds__msg__GridID__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember GridsID__rosidl_typesupport_introspection_c__GridsID_message_member_array[2] = {
  {
    "path",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__GridsID, path),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "grids",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__GridsID, grids),  // bytes offset in struct
    NULL,  // default value
    GridsID__rosidl_typesupport_introspection_c__size_function__GridID__grids,  // size() function pointer
    GridsID__rosidl_typesupport_introspection_c__get_const_function__GridID__grids,  // get_const(index) function pointer
    GridsID__rosidl_typesupport_introspection_c__get_function__GridID__grids,  // get(index) function pointer
    GridsID__rosidl_typesupport_introspection_c__resize_function__GridID__grids  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers GridsID__rosidl_typesupport_introspection_c__GridsID_message_members = {
  "drdds__msg",  // message namespace
  "GridsID",  // message name
  2,  // number of fields
  sizeof(drdds__msg__GridsID),
  GridsID__rosidl_typesupport_introspection_c__GridsID_message_member_array,  // message members
  GridsID__rosidl_typesupport_introspection_c__GridsID_init_function,  // function to initialize message memory (memory has to be allocated)
  GridsID__rosidl_typesupport_introspection_c__GridsID_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t GridsID__rosidl_typesupport_introspection_c__GridsID_message_type_support_handle = {
  0,
  &GridsID__rosidl_typesupport_introspection_c__GridsID_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, GridsID)() {
  GridsID__rosidl_typesupport_introspection_c__GridsID_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, GridID)();
  if (!GridsID__rosidl_typesupport_introspection_c__GridsID_message_type_support_handle.typesupport_identifier) {
    GridsID__rosidl_typesupport_introspection_c__GridsID_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &GridsID__rosidl_typesupport_introspection_c__GridsID_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
