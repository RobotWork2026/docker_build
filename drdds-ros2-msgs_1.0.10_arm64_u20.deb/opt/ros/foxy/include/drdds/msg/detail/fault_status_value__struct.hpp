// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/FaultStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__drdds__msg__FaultStatusValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__FaultStatusValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct FaultStatusValue_
{
  using Type = FaultStatusValue_<ContainerAllocator>;

  explicit FaultStatusValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->imu_error = false;
      this->wifi_error = false;
      this->driver_heat_warn = 0ul;
      this->driver_heat_error = 0ul;
      this->motor_heat_warn = 0ul;
      this->motor_heat_error = 0ul;
      this->battery_low_warn = 0ul;
      this->battery_low_error = 0ul;
      this->battery_voltage_warn = 0ul;
      this->battery_voltage_error = 0ul;
      this->battery_heat_warn = 0ul;
      this->battery_heat_error = 0ul;
      this->cpu_heat_warn = 0ul;
      this->cpu_freq_warn = 0ul;
    }
  }

  explicit FaultStatusValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->imu_error = false;
      this->wifi_error = false;
      this->driver_heat_warn = 0ul;
      this->driver_heat_error = 0ul;
      this->motor_heat_warn = 0ul;
      this->motor_heat_error = 0ul;
      this->battery_low_warn = 0ul;
      this->battery_low_error = 0ul;
      this->battery_voltage_warn = 0ul;
      this->battery_voltage_error = 0ul;
      this->battery_heat_warn = 0ul;
      this->battery_heat_error = 0ul;
      this->cpu_heat_warn = 0ul;
      this->cpu_freq_warn = 0ul;
    }
  }

  // field types and members
  using _imu_error_type =
    bool;
  _imu_error_type imu_error;
  using _wifi_error_type =
    bool;
  _wifi_error_type wifi_error;
  using _driver_heat_warn_type =
    uint32_t;
  _driver_heat_warn_type driver_heat_warn;
  using _driver_heat_error_type =
    uint32_t;
  _driver_heat_error_type driver_heat_error;
  using _motor_heat_warn_type =
    uint32_t;
  _motor_heat_warn_type motor_heat_warn;
  using _motor_heat_error_type =
    uint32_t;
  _motor_heat_error_type motor_heat_error;
  using _battery_low_warn_type =
    uint32_t;
  _battery_low_warn_type battery_low_warn;
  using _battery_low_error_type =
    uint32_t;
  _battery_low_error_type battery_low_error;
  using _battery_voltage_warn_type =
    uint32_t;
  _battery_voltage_warn_type battery_voltage_warn;
  using _battery_voltage_error_type =
    uint32_t;
  _battery_voltage_error_type battery_voltage_error;
  using _battery_heat_warn_type =
    uint32_t;
  _battery_heat_warn_type battery_heat_warn;
  using _battery_heat_error_type =
    uint32_t;
  _battery_heat_error_type battery_heat_error;
  using _cpu_heat_warn_type =
    uint32_t;
  _cpu_heat_warn_type cpu_heat_warn;
  using _cpu_freq_warn_type =
    uint32_t;
  _cpu_freq_warn_type cpu_freq_warn;

  // setters for named parameter idiom
  Type & set__imu_error(
    const bool & _arg)
  {
    this->imu_error = _arg;
    return *this;
  }
  Type & set__wifi_error(
    const bool & _arg)
  {
    this->wifi_error = _arg;
    return *this;
  }
  Type & set__driver_heat_warn(
    const uint32_t & _arg)
  {
    this->driver_heat_warn = _arg;
    return *this;
  }
  Type & set__driver_heat_error(
    const uint32_t & _arg)
  {
    this->driver_heat_error = _arg;
    return *this;
  }
  Type & set__motor_heat_warn(
    const uint32_t & _arg)
  {
    this->motor_heat_warn = _arg;
    return *this;
  }
  Type & set__motor_heat_error(
    const uint32_t & _arg)
  {
    this->motor_heat_error = _arg;
    return *this;
  }
  Type & set__battery_low_warn(
    const uint32_t & _arg)
  {
    this->battery_low_warn = _arg;
    return *this;
  }
  Type & set__battery_low_error(
    const uint32_t & _arg)
  {
    this->battery_low_error = _arg;
    return *this;
  }
  Type & set__battery_voltage_warn(
    const uint32_t & _arg)
  {
    this->battery_voltage_warn = _arg;
    return *this;
  }
  Type & set__battery_voltage_error(
    const uint32_t & _arg)
  {
    this->battery_voltage_error = _arg;
    return *this;
  }
  Type & set__battery_heat_warn(
    const uint32_t & _arg)
  {
    this->battery_heat_warn = _arg;
    return *this;
  }
  Type & set__battery_heat_error(
    const uint32_t & _arg)
  {
    this->battery_heat_error = _arg;
    return *this;
  }
  Type & set__cpu_heat_warn(
    const uint32_t & _arg)
  {
    this->cpu_heat_warn = _arg;
    return *this;
  }
  Type & set__cpu_freq_warn(
    const uint32_t & _arg)
  {
    this->cpu_freq_warn = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::FaultStatusValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::FaultStatusValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::FaultStatusValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::FaultStatusValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::FaultStatusValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::FaultStatusValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::FaultStatusValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::FaultStatusValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::FaultStatusValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::FaultStatusValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__FaultStatusValue
    std::shared_ptr<drdds::msg::FaultStatusValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__FaultStatusValue
    std::shared_ptr<drdds::msg::FaultStatusValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FaultStatusValue_ & other) const
  {
    if (this->imu_error != other.imu_error) {
      return false;
    }
    if (this->wifi_error != other.wifi_error) {
      return false;
    }
    if (this->driver_heat_warn != other.driver_heat_warn) {
      return false;
    }
    if (this->driver_heat_error != other.driver_heat_error) {
      return false;
    }
    if (this->motor_heat_warn != other.motor_heat_warn) {
      return false;
    }
    if (this->motor_heat_error != other.motor_heat_error) {
      return false;
    }
    if (this->battery_low_warn != other.battery_low_warn) {
      return false;
    }
    if (this->battery_low_error != other.battery_low_error) {
      return false;
    }
    if (this->battery_voltage_warn != other.battery_voltage_warn) {
      return false;
    }
    if (this->battery_voltage_error != other.battery_voltage_error) {
      return false;
    }
    if (this->battery_heat_warn != other.battery_heat_warn) {
      return false;
    }
    if (this->battery_heat_error != other.battery_heat_error) {
      return false;
    }
    if (this->cpu_heat_warn != other.cpu_heat_warn) {
      return false;
    }
    if (this->cpu_freq_warn != other.cpu_freq_warn) {
      return false;
    }
    return true;
  }
  bool operator!=(const FaultStatusValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FaultStatusValue_

// alias to use template instance with default allocator
using FaultStatusValue =
  drdds::msg::FaultStatusValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__STRUCT_HPP_
