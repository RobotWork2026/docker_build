// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/JointValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__JOINT_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/primitives_sequence.h"

// Struct defined in msg/JointValue in the package drdds.
typedef struct drdds__msg__JointValue
{
  rosidl_runtime_c__uint8__Sequence name;
  uint16_t data_id;
  uint16_t status_word;
  float position;
  float torque;
  float velocity;
  float motion_temp;
  float driver_temp;
} drdds__msg__JointValue;

// Struct for a sequence of drdds__msg__JointValue.
typedef struct drdds__msg__JointValue__Sequence
{
  drdds__msg__JointValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__JointValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__JOINT_VALUE__STRUCT_H_
