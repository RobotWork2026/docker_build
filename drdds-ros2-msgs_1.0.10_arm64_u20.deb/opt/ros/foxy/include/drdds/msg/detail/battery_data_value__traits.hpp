// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__TRAITS_HPP_

#include "drdds/msg/detail/battery_data_value__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::BatteryDataValue>()
{
  return "drdds::msg::BatteryDataValue";
}

template<>
inline const char * name<drdds::msg::BatteryDataValue>()
{
  return "drdds/msg/BatteryDataValue";
}

template<>
struct has_fixed_size<drdds::msg::BatteryDataValue>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::BatteryDataValue>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::BatteryDataValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__TRAITS_HPP_
