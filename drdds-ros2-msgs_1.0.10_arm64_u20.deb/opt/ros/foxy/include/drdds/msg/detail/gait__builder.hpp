// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/Gait.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GAIT__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__GAIT__BUILDER_HPP_

#include "drdds/msg/detail/gait__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_Gait_data
{
public:
  explicit Init_Gait_data(::drdds::msg::Gait & msg)
  : msg_(msg)
  {}
  ::drdds::msg::Gait data(::drdds::msg::Gait::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::Gait msg_;
};

class Init_Gait_header
{
public:
  Init_Gait_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Gait_data header(::drdds::msg::Gait::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Gait_data(msg_);
  }

private:
  ::drdds::msg::Gait msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::Gait>()
{
  return drdds::msg::builder::Init_Gait_header();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__GAIT__BUILDER_HPP_
