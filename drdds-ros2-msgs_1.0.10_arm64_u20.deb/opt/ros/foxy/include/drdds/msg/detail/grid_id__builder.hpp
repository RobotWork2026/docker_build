// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/GridID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRID_ID__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__GRID_ID__BUILDER_HPP_

#include "drdds/msg/detail/grid_id__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_GridID_name
{
public:
  explicit Init_GridID_name(::drdds::msg::GridID & msg)
  : msg_(msg)
  {}
  ::drdds::msg::GridID name(::drdds::msg::GridID::_name_type arg)
  {
    msg_.name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::GridID msg_;
};

class Init_GridID_id
{
public:
  Init_GridID_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GridID_name id(::drdds::msg::GridID::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_GridID_name(msg_);
  }

private:
  ::drdds::msg::GridID msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::GridID>()
{
  return drdds::msg::builder::Init_GridID_id();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__GRID_ID__BUILDER_HPP_
