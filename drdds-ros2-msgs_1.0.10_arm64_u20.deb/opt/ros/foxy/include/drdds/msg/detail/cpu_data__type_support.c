// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/CpuData.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/cpu_data__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/cpu_data__functions.h"
#include "drdds/msg/detail/cpu_data__struct.h"


// Include directives for member types
// Member `header`
#include "drdds/msg/meta_type.h"
// Member `header`
#include "drdds/msg/detail/meta_type__rosidl_typesupport_introspection_c.h"
// Member `data`
#include "drdds/msg/cpu_data_value.h"
// Member `data`
#include "drdds/msg/detail/cpu_data_value__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void CpuData__rosidl_typesupport_introspection_c__CpuData_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__CpuData__init(message_memory);
}

void CpuData__rosidl_typesupport_introspection_c__CpuData_fini_function(void * message_memory)
{
  drdds__msg__CpuData__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember CpuData__rosidl_typesupport_introspection_c__CpuData_message_member_array[2] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CpuData, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CpuData, data),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers CpuData__rosidl_typesupport_introspection_c__CpuData_message_members = {
  "drdds__msg",  // message namespace
  "CpuData",  // message name
  2,  // number of fields
  sizeof(drdds__msg__CpuData),
  CpuData__rosidl_typesupport_introspection_c__CpuData_message_member_array,  // message members
  CpuData__rosidl_typesupport_introspection_c__CpuData_init_function,  // function to initialize message memory (memory has to be allocated)
  CpuData__rosidl_typesupport_introspection_c__CpuData_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t CpuData__rosidl_typesupport_introspection_c__CpuData_message_type_support_handle = {
  0,
  &CpuData__rosidl_typesupport_introspection_c__CpuData_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, CpuData)() {
  CpuData__rosidl_typesupport_introspection_c__CpuData_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, MetaType)();
  CpuData__rosidl_typesupport_introspection_c__CpuData_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, CpuDataValue)();
  if (!CpuData__rosidl_typesupport_introspection_c__CpuData_message_type_support_handle.typesupport_identifier) {
    CpuData__rosidl_typesupport_introspection_c__CpuData_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &CpuData__rosidl_typesupport_introspection_c__CpuData_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
