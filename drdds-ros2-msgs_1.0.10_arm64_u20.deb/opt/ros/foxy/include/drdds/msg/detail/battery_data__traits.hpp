// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/BatteryData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__BATTERY_DATA__TRAITS_HPP_

#include "drdds/msg/detail/battery_data__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::BatteryData>()
{
  return "drdds::msg::BatteryData";
}

template<>
inline const char * name<drdds::msg::BatteryData>()
{
  return "drdds/msg/BatteryData";
}

template<>
struct has_fixed_size<drdds::msg::BatteryData>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::BatteryData>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::BatteryData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA__TRAITS_HPP_
