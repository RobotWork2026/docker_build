// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/JointValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__JOINT_VALUE__TRAITS_HPP_

#include "drdds/msg/detail/joint_value__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::JointValue>()
{
  return "drdds::msg::JointValue";
}

template<>
inline const char * name<drdds::msg::JointValue>()
{
  return "drdds/msg/JointValue";
}

template<>
struct has_fixed_size<drdds::msg::JointValue>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::JointValue>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::JointValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__JOINT_VALUE__TRAITS_HPP_
