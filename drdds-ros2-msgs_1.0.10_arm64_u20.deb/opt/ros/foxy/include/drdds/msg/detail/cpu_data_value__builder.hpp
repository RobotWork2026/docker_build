// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/CpuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__CPU_DATA_VALUE__BUILDER_HPP_

#include "drdds/msg/detail/cpu_data_value__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_CpuDataValue_cpu_frequency
{
public:
  explicit Init_CpuDataValue_cpu_frequency(::drdds::msg::CpuDataValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::CpuDataValue cpu_frequency(::drdds::msg::CpuDataValue::_cpu_frequency_type arg)
  {
    msg_.cpu_frequency = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::CpuDataValue msg_;
};

class Init_CpuDataValue_cpu_temperature
{
public:
  Init_CpuDataValue_cpu_temperature()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CpuDataValue_cpu_frequency cpu_temperature(::drdds::msg::CpuDataValue::_cpu_temperature_type arg)
  {
    msg_.cpu_temperature = std::move(arg);
    return Init_CpuDataValue_cpu_frequency(msg_);
  }

private:
  ::drdds::msg::CpuDataValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::CpuDataValue>()
{
  return drdds::msg::builder::Init_CpuDataValue_cpu_temperature();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__CPU_DATA_VALUE__BUILDER_HPP_
