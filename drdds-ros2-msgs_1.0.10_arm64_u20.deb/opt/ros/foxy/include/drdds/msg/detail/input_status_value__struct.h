// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/InputStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/InputStatusValue in the package drdds.
typedef struct drdds__msg__InputStatusValue
{
  uint8_t lidar;
  uint8_t imu;
  uint8_t leg_odom;
  uint8_t rtk;
  uint8_t tag;
  uint8_t reflective_strip;
} drdds__msg__InputStatusValue;

// Struct for a sequence of drdds__msg__InputStatusValue.
typedef struct drdds__msg__InputStatusValue__Sequence
{
  drdds__msg__InputStatusValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__InputStatusValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__STRUCT_H_
