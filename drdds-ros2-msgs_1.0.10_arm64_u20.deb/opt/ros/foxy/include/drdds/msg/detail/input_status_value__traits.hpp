// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/InputStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__TRAITS_HPP_

#include "drdds/msg/detail/input_status_value__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::InputStatusValue>()
{
  return "drdds::msg::InputStatusValue";
}

template<>
inline const char * name<drdds::msg::InputStatusValue>()
{
  return "drdds/msg/InputStatusValue";
}

template<>
struct has_fixed_size<drdds::msg::InputStatusValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::InputStatusValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::InputStatusValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__TRAITS_HPP_
