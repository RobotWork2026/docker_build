// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/CpuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__CPU_DATA_VALUE__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__drdds__msg__CpuDataValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__CpuDataValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CpuDataValue_
{
  using Type = CpuDataValue_<ContainerAllocator>;

  explicit CpuDataValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
  }

  explicit CpuDataValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
    (void)_alloc;
  }

  // field types and members
  using _cpu_temperature_type =
    std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other>;
  _cpu_temperature_type cpu_temperature;
  using _cpu_frequency_type =
    std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other>;
  _cpu_frequency_type cpu_frequency;

  // setters for named parameter idiom
  Type & set__cpu_temperature(
    const std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other> & _arg)
  {
    this->cpu_temperature = _arg;
    return *this;
  }
  Type & set__cpu_frequency(
    const std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other> & _arg)
  {
    this->cpu_frequency = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::CpuDataValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::CpuDataValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::CpuDataValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::CpuDataValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::CpuDataValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::CpuDataValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::CpuDataValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::CpuDataValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::CpuDataValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::CpuDataValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__CpuDataValue
    std::shared_ptr<drdds::msg::CpuDataValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__CpuDataValue
    std::shared_ptr<drdds::msg::CpuDataValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CpuDataValue_ & other) const
  {
    if (this->cpu_temperature != other.cpu_temperature) {
      return false;
    }
    if (this->cpu_frequency != other.cpu_frequency) {
      return false;
    }
    return true;
  }
  bool operator!=(const CpuDataValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CpuDataValue_

// alias to use template instance with default allocator
using CpuDataValue =
  drdds::msg::CpuDataValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__CPU_DATA_VALUE__STRUCT_HPP_
