// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/Heartbeat.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__HEARTBEAT__STRUCT_H_
#define DRDDS__MSG__DETAIL__HEARTBEAT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'source'
// Member 'details'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/Heartbeat in the package drdds.
typedef struct drdds__msg__Heartbeat
{
  builtin_interfaces__msg__Time timestamp;
  rosidl_runtime_c__String source;
  uint8_t status;
  rosidl_runtime_c__String details;
} drdds__msg__Heartbeat;

// Struct for a sequence of drdds__msg__Heartbeat.
typedef struct drdds__msg__Heartbeat__Sequence
{
  drdds__msg__Heartbeat * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__Heartbeat__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__HEARTBEAT__STRUCT_H_
