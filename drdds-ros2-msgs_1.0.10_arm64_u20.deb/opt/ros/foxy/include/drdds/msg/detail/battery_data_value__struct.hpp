// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__drdds__msg__BatteryDataValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__BatteryDataValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BatteryDataValue_
{
  using Type = BatteryDataValue_<ContainerAllocator>;

  explicit BatteryDataValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->voltage = 0;
      this->current = 0;
      this->remaining_capacity = 0;
      this->nominal_capacity = 0;
      this->cycles = 0;
      this->production_date = 0;
      this->balanced_low = 0;
      this->balanced_high = 0;
      this->protected_state = 0;
      this->software_version = 0;
      this->battery_level = 0;
      this->mos_state = 0;
      this->battery_quantity = 0;
      this->battery_ntc = 0;
      std::fill<typename std::array<uint8_t, 32>::iterator, uint8_t>(this->battery_serialnum.begin(), this->battery_serialnum.end(), 0);
    }
  }

  explicit BatteryDataValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : battery_serialnum(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->voltage = 0;
      this->current = 0;
      this->remaining_capacity = 0;
      this->nominal_capacity = 0;
      this->cycles = 0;
      this->production_date = 0;
      this->balanced_low = 0;
      this->balanced_high = 0;
      this->protected_state = 0;
      this->software_version = 0;
      this->battery_level = 0;
      this->mos_state = 0;
      this->battery_quantity = 0;
      this->battery_ntc = 0;
      std::fill<typename std::array<uint8_t, 32>::iterator, uint8_t>(this->battery_serialnum.begin(), this->battery_serialnum.end(), 0);
    }
  }

  // field types and members
  using _voltage_type =
    uint16_t;
  _voltage_type voltage;
  using _current_type =
    int16_t;
  _current_type current;
  using _remaining_capacity_type =
    uint16_t;
  _remaining_capacity_type remaining_capacity;
  using _nominal_capacity_type =
    uint16_t;
  _nominal_capacity_type nominal_capacity;
  using _cycles_type =
    uint16_t;
  _cycles_type cycles;
  using _production_date_type =
    uint16_t;
  _production_date_type production_date;
  using _balanced_low_type =
    uint16_t;
  _balanced_low_type balanced_low;
  using _balanced_high_type =
    uint16_t;
  _balanced_high_type balanced_high;
  using _protected_state_type =
    uint16_t;
  _protected_state_type protected_state;
  using _software_version_type =
    uint8_t;
  _software_version_type software_version;
  using _battery_level_type =
    uint8_t;
  _battery_level_type battery_level;
  using _mos_state_type =
    uint8_t;
  _mos_state_type mos_state;
  using _battery_quantity_type =
    uint8_t;
  _battery_quantity_type battery_quantity;
  using _battery_ntc_type =
    uint8_t;
  _battery_ntc_type battery_ntc;
  using _battery_temperature_type =
    std::vector<float, typename ContainerAllocator::template rebind<float>::other>;
  _battery_temperature_type battery_temperature;
  using _battery_serialnum_type =
    std::array<uint8_t, 32>;
  _battery_serialnum_type battery_serialnum;

  // setters for named parameter idiom
  Type & set__voltage(
    const uint16_t & _arg)
  {
    this->voltage = _arg;
    return *this;
  }
  Type & set__current(
    const int16_t & _arg)
  {
    this->current = _arg;
    return *this;
  }
  Type & set__remaining_capacity(
    const uint16_t & _arg)
  {
    this->remaining_capacity = _arg;
    return *this;
  }
  Type & set__nominal_capacity(
    const uint16_t & _arg)
  {
    this->nominal_capacity = _arg;
    return *this;
  }
  Type & set__cycles(
    const uint16_t & _arg)
  {
    this->cycles = _arg;
    return *this;
  }
  Type & set__production_date(
    const uint16_t & _arg)
  {
    this->production_date = _arg;
    return *this;
  }
  Type & set__balanced_low(
    const uint16_t & _arg)
  {
    this->balanced_low = _arg;
    return *this;
  }
  Type & set__balanced_high(
    const uint16_t & _arg)
  {
    this->balanced_high = _arg;
    return *this;
  }
  Type & set__protected_state(
    const uint16_t & _arg)
  {
    this->protected_state = _arg;
    return *this;
  }
  Type & set__software_version(
    const uint8_t & _arg)
  {
    this->software_version = _arg;
    return *this;
  }
  Type & set__battery_level(
    const uint8_t & _arg)
  {
    this->battery_level = _arg;
    return *this;
  }
  Type & set__mos_state(
    const uint8_t & _arg)
  {
    this->mos_state = _arg;
    return *this;
  }
  Type & set__battery_quantity(
    const uint8_t & _arg)
  {
    this->battery_quantity = _arg;
    return *this;
  }
  Type & set__battery_ntc(
    const uint8_t & _arg)
  {
    this->battery_ntc = _arg;
    return *this;
  }
  Type & set__battery_temperature(
    const std::vector<float, typename ContainerAllocator::template rebind<float>::other> & _arg)
  {
    this->battery_temperature = _arg;
    return *this;
  }
  Type & set__battery_serialnum(
    const std::array<uint8_t, 32> & _arg)
  {
    this->battery_serialnum = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::BatteryDataValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::BatteryDataValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::BatteryDataValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::BatteryDataValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::BatteryDataValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::BatteryDataValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::BatteryDataValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::BatteryDataValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::BatteryDataValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::BatteryDataValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__BatteryDataValue
    std::shared_ptr<drdds::msg::BatteryDataValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__BatteryDataValue
    std::shared_ptr<drdds::msg::BatteryDataValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BatteryDataValue_ & other) const
  {
    if (this->voltage != other.voltage) {
      return false;
    }
    if (this->current != other.current) {
      return false;
    }
    if (this->remaining_capacity != other.remaining_capacity) {
      return false;
    }
    if (this->nominal_capacity != other.nominal_capacity) {
      return false;
    }
    if (this->cycles != other.cycles) {
      return false;
    }
    if (this->production_date != other.production_date) {
      return false;
    }
    if (this->balanced_low != other.balanced_low) {
      return false;
    }
    if (this->balanced_high != other.balanced_high) {
      return false;
    }
    if (this->protected_state != other.protected_state) {
      return false;
    }
    if (this->software_version != other.software_version) {
      return false;
    }
    if (this->battery_level != other.battery_level) {
      return false;
    }
    if (this->mos_state != other.mos_state) {
      return false;
    }
    if (this->battery_quantity != other.battery_quantity) {
      return false;
    }
    if (this->battery_ntc != other.battery_ntc) {
      return false;
    }
    if (this->battery_temperature != other.battery_temperature) {
      return false;
    }
    if (this->battery_serialnum != other.battery_serialnum) {
      return false;
    }
    return true;
  }
  bool operator!=(const BatteryDataValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BatteryDataValue_

// alias to use template instance with default allocator
using BatteryDataValue =
  drdds::msg::BatteryDataValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_HPP_
