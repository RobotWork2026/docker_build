// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/CpuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__CPU_DATA_VALUE__TRAITS_HPP_

#include "drdds/msg/detail/cpu_data_value__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::CpuDataValue>()
{
  return "drdds::msg::CpuDataValue";
}

template<>
inline const char * name<drdds::msg::CpuDataValue>()
{
  return "drdds/msg/CpuDataValue";
}

template<>
struct has_fixed_size<drdds::msg::CpuDataValue>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::CpuDataValue>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::CpuDataValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__CPU_DATA_VALUE__TRAITS_HPP_
