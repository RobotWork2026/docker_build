// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/FaultEvent.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__FAULT_EVENT__BUILDER_HPP_

#include "drdds/msg/detail/fault_event__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_FaultEvent_details
{
public:
  explicit Init_FaultEvent_details(::drdds::msg::FaultEvent & msg)
  : msg_(msg)
  {}
  ::drdds::msg::FaultEvent details(::drdds::msg::FaultEvent::_details_type arg)
  {
    msg_.details = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

class Init_FaultEvent_source
{
public:
  explicit Init_FaultEvent_source(::drdds::msg::FaultEvent & msg)
  : msg_(msg)
  {}
  Init_FaultEvent_details source(::drdds::msg::FaultEvent::_source_type arg)
  {
    msg_.source = std::move(arg);
    return Init_FaultEvent_details(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

class Init_FaultEvent_grouped
{
public:
  explicit Init_FaultEvent_grouped(::drdds::msg::FaultEvent & msg)
  : msg_(msg)
  {}
  Init_FaultEvent_source grouped(::drdds::msg::FaultEvent::_grouped_type arg)
  {
    msg_.grouped = std::move(arg);
    return Init_FaultEvent_source(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

class Init_FaultEvent_resources
{
public:
  explicit Init_FaultEvent_resources(::drdds::msg::FaultEvent & msg)
  : msg_(msg)
  {}
  Init_FaultEvent_grouped resources(::drdds::msg::FaultEvent::_resources_type arg)
  {
    msg_.resources = std::move(arg);
    return Init_FaultEvent_grouped(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

class Init_FaultEvent_severities
{
public:
  explicit Init_FaultEvent_severities(::drdds::msg::FaultEvent & msg)
  : msg_(msg)
  {}
  Init_FaultEvent_resources severities(::drdds::msg::FaultEvent::_severities_type arg)
  {
    msg_.severities = std::move(arg);
    return Init_FaultEvent_resources(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

class Init_FaultEvent_type
{
public:
  explicit Init_FaultEvent_type(::drdds::msg::FaultEvent & msg)
  : msg_(msg)
  {}
  Init_FaultEvent_severities type(::drdds::msg::FaultEvent::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_FaultEvent_severities(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

class Init_FaultEvent_code
{
public:
  explicit Init_FaultEvent_code(::drdds::msg::FaultEvent & msg)
  : msg_(msg)
  {}
  Init_FaultEvent_type code(::drdds::msg::FaultEvent::_code_type arg)
  {
    msg_.code = std::move(arg);
    return Init_FaultEvent_type(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

class Init_FaultEvent_name
{
public:
  explicit Init_FaultEvent_name(::drdds::msg::FaultEvent & msg)
  : msg_(msg)
  {}
  Init_FaultEvent_code name(::drdds::msg::FaultEvent::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_FaultEvent_code(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

class Init_FaultEvent_timestamp
{
public:
  Init_FaultEvent_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FaultEvent_name timestamp(::drdds::msg::FaultEvent::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_FaultEvent_name(msg_);
  }

private:
  ::drdds::msg::FaultEvent msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::FaultEvent>()
{
  return drdds::msg::builder::Init_FaultEvent_timestamp();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT__BUILDER_HPP_
