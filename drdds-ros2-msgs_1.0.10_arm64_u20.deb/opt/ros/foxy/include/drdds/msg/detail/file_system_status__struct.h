// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/FileSystemStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_H_
#define DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'soc_id'
// Member 'mount_point'
// Member 'device_path'
// Member 'fs_type'
#include "rosidl_runtime_c/string.h"

// Struct defined in msg/FileSystemStatus in the package drdds.
typedef struct drdds__msg__FileSystemStatus
{
  builtin_interfaces__msg__Time timestamp;
  rosidl_runtime_c__String soc_id;
  rosidl_runtime_c__String mount_point;
  rosidl_runtime_c__String device_path;
  rosidl_runtime_c__String fs_type;
  uint64_t total_bytes;
  uint64_t used_bytes;
  uint64_t available_bytes;
  uint64_t used_inodes;
  uint64_t free_inodes;
  bool is_readonly;
} drdds__msg__FileSystemStatus;

// Struct for a sequence of drdds__msg__FileSystemStatus.
typedef struct drdds__msg__FileSystemStatus__Sequence
{
  drdds__msg__FileSystemStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__FileSystemStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_H_
