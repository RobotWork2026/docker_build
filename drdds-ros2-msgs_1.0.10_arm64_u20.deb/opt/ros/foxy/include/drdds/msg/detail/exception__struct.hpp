// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/Exception.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXCEPTION__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__EXCEPTION__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__drdds__msg__Exception __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__Exception __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Exception_
{
  using Type = Exception_<ContainerAllocator>;

  explicit Exception_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->source = "";
      this->description = "";
      this->is_abnormal = false;
    }
  }

  explicit Exception_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_alloc, _init),
    source(_alloc),
    description(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->source = "";
      this->description = "";
      this->is_abnormal = false;
    }
  }

  // field types and members
  using _stamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _stamp_type stamp;
  using _source_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _source_type source;
  using _description_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _description_type description;
  using _is_abnormal_type =
    bool;
  _is_abnormal_type is_abnormal;

  // setters for named parameter idiom
  Type & set__stamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->stamp = _arg;
    return *this;
  }
  Type & set__source(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->source = _arg;
    return *this;
  }
  Type & set__description(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->description = _arg;
    return *this;
  }
  Type & set__is_abnormal(
    const bool & _arg)
  {
    this->is_abnormal = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::Exception_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::Exception_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::Exception_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::Exception_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::Exception_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::Exception_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::Exception_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::Exception_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::Exception_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::Exception_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__Exception
    std::shared_ptr<drdds::msg::Exception_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__Exception
    std::shared_ptr<drdds::msg::Exception_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Exception_ & other) const
  {
    if (this->stamp != other.stamp) {
      return false;
    }
    if (this->source != other.source) {
      return false;
    }
    if (this->description != other.description) {
      return false;
    }
    if (this->is_abnormal != other.is_abnormal) {
      return false;
    }
    return true;
  }
  bool operator!=(const Exception_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Exception_

// alias to use template instance with default allocator
using Exception =
  drdds::msg::Exception_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__EXCEPTION__STRUCT_HPP_
