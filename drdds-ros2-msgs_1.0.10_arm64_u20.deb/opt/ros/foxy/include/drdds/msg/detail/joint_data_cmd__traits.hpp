// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/JointDataCmd.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_DATA_CMD__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__JOINT_DATA_CMD__TRAITS_HPP_

#include "drdds/msg/detail/joint_data_cmd__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::JointDataCmd>()
{
  return "drdds::msg::JointDataCmd";
}

template<>
inline const char * name<drdds::msg::JointDataCmd>()
{
  return "drdds/msg/JointDataCmd";
}

template<>
struct has_fixed_size<drdds::msg::JointDataCmd>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::JointDataCmd>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::JointDataCmd>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__JOINT_DATA_CMD__TRAITS_HPP_
