// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from drdds:msg/CPUStatus.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "drdds/msg/detail/cpu_status__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace drdds
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void CPUStatus_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) drdds::msg::CPUStatus(_init);
}

void CPUStatus_fini_function(void * message_memory)
{
  auto typed_message = static_cast<drdds::msg::CPUStatus *>(message_memory);
  typed_message->~CPUStatus();
}

size_t size_function__CPUStatus__temps(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<int32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__CPUStatus__temps(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<int32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__CPUStatus__temps(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<int32_t> *>(untyped_member);
  return &member[index];
}

void resize_function__CPUStatus__temps(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<int32_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__CPUStatus__util(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint16_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__CPUStatus__util(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint16_t> *>(untyped_member);
  return &member[index];
}

void * get_function__CPUStatus__util(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint16_t> *>(untyped_member);
  return &member[index];
}

void resize_function__CPUStatus__util(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint16_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__CPUStatus__cur_freq_khz(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__CPUStatus__cur_freq_khz(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__CPUStatus__cur_freq_khz(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void resize_function__CPUStatus__cur_freq_khz(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__CPUStatus__hw_max_freq_khz(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__CPUStatus__hw_max_freq_khz(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__CPUStatus__hw_max_freq_khz(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void resize_function__CPUStatus__hw_max_freq_khz(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__CPUStatus__hw_min_freq_khz(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__CPUStatus__hw_min_freq_khz(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__CPUStatus__hw_min_freq_khz(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void resize_function__CPUStatus__hw_min_freq_khz(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__CPUStatus__gov_policy(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return member->size();
}

const void * get_const_function__CPUStatus__gov_policy(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void * get_function__CPUStatus__gov_policy(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<std::string> *>(untyped_member);
  return &member[index];
}

void resize_function__CPUStatus__gov_policy(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<std::string> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember CPUStatus_message_member_array[10] = {
  {
    "timestamp",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<builtin_interfaces::msg::Time>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, timestamp),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "soc_id",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, soc_id),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "package_temp",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, package_temp),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "temps",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, temps),  // bytes offset in struct
    nullptr,  // default value
    size_function__CPUStatus__temps,  // size() function pointer
    get_const_function__CPUStatus__temps,  // get_const(index) function pointer
    get_function__CPUStatus__temps,  // get(index) function pointer
    resize_function__CPUStatus__temps  // resize(index) function pointer
  },
  {
    "avg_util",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, avg_util),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "util",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, util),  // bytes offset in struct
    nullptr,  // default value
    size_function__CPUStatus__util,  // size() function pointer
    get_const_function__CPUStatus__util,  // get_const(index) function pointer
    get_function__CPUStatus__util,  // get(index) function pointer
    resize_function__CPUStatus__util  // resize(index) function pointer
  },
  {
    "cur_freq_khz",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, cur_freq_khz),  // bytes offset in struct
    nullptr,  // default value
    size_function__CPUStatus__cur_freq_khz,  // size() function pointer
    get_const_function__CPUStatus__cur_freq_khz,  // get_const(index) function pointer
    get_function__CPUStatus__cur_freq_khz,  // get(index) function pointer
    resize_function__CPUStatus__cur_freq_khz  // resize(index) function pointer
  },
  {
    "hw_max_freq_khz",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, hw_max_freq_khz),  // bytes offset in struct
    nullptr,  // default value
    size_function__CPUStatus__hw_max_freq_khz,  // size() function pointer
    get_const_function__CPUStatus__hw_max_freq_khz,  // get_const(index) function pointer
    get_function__CPUStatus__hw_max_freq_khz,  // get(index) function pointer
    resize_function__CPUStatus__hw_max_freq_khz  // resize(index) function pointer
  },
  {
    "hw_min_freq_khz",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, hw_min_freq_khz),  // bytes offset in struct
    nullptr,  // default value
    size_function__CPUStatus__hw_min_freq_khz,  // size() function pointer
    get_const_function__CPUStatus__hw_min_freq_khz,  // get_const(index) function pointer
    get_function__CPUStatus__hw_min_freq_khz,  // get(index) function pointer
    resize_function__CPUStatus__hw_min_freq_khz  // resize(index) function pointer
  },
  {
    "gov_policy",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CPUStatus, gov_policy),  // bytes offset in struct
    nullptr,  // default value
    size_function__CPUStatus__gov_policy,  // size() function pointer
    get_const_function__CPUStatus__gov_policy,  // get_const(index) function pointer
    get_function__CPUStatus__gov_policy,  // get(index) function pointer
    resize_function__CPUStatus__gov_policy  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers CPUStatus_message_members = {
  "drdds::msg",  // message namespace
  "CPUStatus",  // message name
  10,  // number of fields
  sizeof(drdds::msg::CPUStatus),
  CPUStatus_message_member_array,  // message members
  CPUStatus_init_function,  // function to initialize message memory (memory has to be allocated)
  CPUStatus_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t CPUStatus_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &CPUStatus_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace drdds


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<drdds::msg::CPUStatus>()
{
  return &::drdds::msg::rosidl_typesupport_introspection_cpp::CPUStatus_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, drdds, msg, CPUStatus)() {
  return &::drdds::msg::rosidl_typesupport_introspection_cpp::CPUStatus_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
