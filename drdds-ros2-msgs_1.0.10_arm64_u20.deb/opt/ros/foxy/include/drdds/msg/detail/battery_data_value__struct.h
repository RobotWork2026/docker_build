// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'battery_temperature'
#include "rosidl_runtime_c/primitives_sequence.h"

// Struct defined in msg/BatteryDataValue in the package drdds.
typedef struct drdds__msg__BatteryDataValue
{
  uint16_t voltage;
  int16_t current;
  uint16_t remaining_capacity;
  uint16_t nominal_capacity;
  uint16_t cycles;
  uint16_t production_date;
  uint16_t balanced_low;
  uint16_t balanced_high;
  uint16_t protected_state;
  uint8_t software_version;
  uint8_t battery_level;
  uint8_t mos_state;
  uint8_t battery_quantity;
  uint8_t battery_ntc;
  rosidl_runtime_c__float__Sequence battery_temperature;
  uint8_t battery_serialnum[32];
} drdds__msg__BatteryDataValue;

// Struct for a sequence of drdds__msg__BatteryDataValue.
typedef struct drdds__msg__BatteryDataValue__Sequence
{
  drdds__msg__BatteryDataValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__BatteryDataValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_H_
