// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/GaitValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GAIT_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__GAIT_VALUE__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__drdds__msg__GaitValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__GaitValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GaitValue_
{
  using Type = GaitValue_<ContainerAllocator>;

  explicit GaitValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->gait = 0ul;
    }
  }

  explicit GaitValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->gait = 0ul;
    }
  }

  // field types and members
  using _gait_type =
    uint32_t;
  _gait_type gait;

  // setters for named parameter idiom
  Type & set__gait(
    const uint32_t & _arg)
  {
    this->gait = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::GaitValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::GaitValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::GaitValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::GaitValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::GaitValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::GaitValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::GaitValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::GaitValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::GaitValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::GaitValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__GaitValue
    std::shared_ptr<drdds::msg::GaitValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__GaitValue
    std::shared_ptr<drdds::msg::GaitValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GaitValue_ & other) const
  {
    if (this->gait != other.gait) {
      return false;
    }
    return true;
  }
  bool operator!=(const GaitValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GaitValue_

// alias to use template instance with default allocator
using GaitValue =
  drdds::msg::GaitValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__GAIT_VALUE__STRUCT_HPP_
