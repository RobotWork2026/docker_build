// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/FaultEvent.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_H_
#define DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'TYPE_START'.
enum
{
  drdds__msg__FaultEvent__TYPE_START = 1
};

/// Constant 'TYPE_STOP'.
enum
{
  drdds__msg__FaultEvent__TYPE_STOP = 2
};

/// Constant 'TYPE_PULSE'.
enum
{
  drdds__msg__FaultEvent__TYPE_PULSE = 3
};

/// Constant 'SEVERITY_DEBUG'.
enum
{
  drdds__msg__FaultEvent__SEVERITY_DEBUG = 1
};

/// Constant 'SEVERITY_INFO'.
enum
{
  drdds__msg__FaultEvent__SEVERITY_INFO = 2
};

/// Constant 'SEVERITY_WARN'.
enum
{
  drdds__msg__FaultEvent__SEVERITY_WARN = 3
};

/// Constant 'SEVERITY_ERROR'.
enum
{
  drdds__msg__FaultEvent__SEVERITY_ERROR = 4
};

/// Constant 'SEVERITY_FATAL'.
enum
{
  drdds__msg__FaultEvent__SEVERITY_FATAL = 5
};

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'name'
// Member 'resources'
// Member 'source'
// Member 'details'
#include "rosidl_runtime_c/string.h"
// Member 'severities'
#include "rosidl_runtime_c/primitives_sequence.h"

// Struct defined in msg/FaultEvent in the package drdds.
typedef struct drdds__msg__FaultEvent
{
  builtin_interfaces__msg__Time timestamp;
  rosidl_runtime_c__String name;
  uint32_t code;
  uint8_t type;
  rosidl_runtime_c__uint8__Sequence severities;
  rosidl_runtime_c__String__Sequence resources;
  bool grouped;
  rosidl_runtime_c__String__Sequence source;
  rosidl_runtime_c__String details;
} drdds__msg__FaultEvent;

// Struct for a sequence of drdds__msg__FaultEvent.
typedef struct drdds__msg__FaultEvent__Sequence
{
  drdds__msg__FaultEvent * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__FaultEvent__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_H_
