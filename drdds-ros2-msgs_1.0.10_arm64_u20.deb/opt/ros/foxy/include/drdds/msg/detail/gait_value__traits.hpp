// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/GaitValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GAIT_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__GAIT_VALUE__TRAITS_HPP_

#include "drdds/msg/detail/gait_value__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::GaitValue>()
{
  return "drdds::msg::GaitValue";
}

template<>
inline const char * name<drdds::msg::GaitValue>()
{
  return "drdds/msg/GaitValue";
}

template<>
struct has_fixed_size<drdds::msg::GaitValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::GaitValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::GaitValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__GAIT_VALUE__TRAITS_HPP_
