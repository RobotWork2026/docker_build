// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/CPUStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_STATUS__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__CPU_STATUS__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__drdds__msg__CPUStatus __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__CPUStatus __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CPUStatus_
{
  using Type = CPUStatus_<ContainerAllocator>;

  explicit CPUStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->soc_id = "";
      this->package_temp = 0l;
      this->avg_util = 0;
    }
  }

  explicit CPUStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init),
    soc_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->soc_id = "";
      this->package_temp = 0l;
      this->avg_util = 0;
    }
  }

  // field types and members
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;
  using _soc_id_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _soc_id_type soc_id;
  using _package_temp_type =
    int32_t;
  _package_temp_type package_temp;
  using _temps_type =
    std::vector<int32_t, typename ContainerAllocator::template rebind<int32_t>::other>;
  _temps_type temps;
  using _avg_util_type =
    uint16_t;
  _avg_util_type avg_util;
  using _util_type =
    std::vector<uint16_t, typename ContainerAllocator::template rebind<uint16_t>::other>;
  _util_type util;
  using _cur_freq_khz_type =
    std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other>;
  _cur_freq_khz_type cur_freq_khz;
  using _hw_max_freq_khz_type =
    std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other>;
  _hw_max_freq_khz_type hw_max_freq_khz;
  using _hw_min_freq_khz_type =
    std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other>;
  _hw_min_freq_khz_type hw_min_freq_khz;
  using _gov_policy_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>, typename ContainerAllocator::template rebind<std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>>::other>;
  _gov_policy_type gov_policy;

  // setters for named parameter idiom
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__soc_id(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->soc_id = _arg;
    return *this;
  }
  Type & set__package_temp(
    const int32_t & _arg)
  {
    this->package_temp = _arg;
    return *this;
  }
  Type & set__temps(
    const std::vector<int32_t, typename ContainerAllocator::template rebind<int32_t>::other> & _arg)
  {
    this->temps = _arg;
    return *this;
  }
  Type & set__avg_util(
    const uint16_t & _arg)
  {
    this->avg_util = _arg;
    return *this;
  }
  Type & set__util(
    const std::vector<uint16_t, typename ContainerAllocator::template rebind<uint16_t>::other> & _arg)
  {
    this->util = _arg;
    return *this;
  }
  Type & set__cur_freq_khz(
    const std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other> & _arg)
  {
    this->cur_freq_khz = _arg;
    return *this;
  }
  Type & set__hw_max_freq_khz(
    const std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other> & _arg)
  {
    this->hw_max_freq_khz = _arg;
    return *this;
  }
  Type & set__hw_min_freq_khz(
    const std::vector<uint32_t, typename ContainerAllocator::template rebind<uint32_t>::other> & _arg)
  {
    this->hw_min_freq_khz = _arg;
    return *this;
  }
  Type & set__gov_policy(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>, typename ContainerAllocator::template rebind<std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>>::other> & _arg)
  {
    this->gov_policy = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::CPUStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::CPUStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::CPUStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::CPUStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::CPUStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::CPUStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::CPUStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::CPUStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::CPUStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::CPUStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__CPUStatus
    std::shared_ptr<drdds::msg::CPUStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__CPUStatus
    std::shared_ptr<drdds::msg::CPUStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CPUStatus_ & other) const
  {
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->soc_id != other.soc_id) {
      return false;
    }
    if (this->package_temp != other.package_temp) {
      return false;
    }
    if (this->temps != other.temps) {
      return false;
    }
    if (this->avg_util != other.avg_util) {
      return false;
    }
    if (this->util != other.util) {
      return false;
    }
    if (this->cur_freq_khz != other.cur_freq_khz) {
      return false;
    }
    if (this->hw_max_freq_khz != other.hw_max_freq_khz) {
      return false;
    }
    if (this->hw_min_freq_khz != other.hw_min_freq_khz) {
      return false;
    }
    if (this->gov_policy != other.gov_policy) {
      return false;
    }
    return true;
  }
  bool operator!=(const CPUStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CPUStatus_

// alias to use template instance with default allocator
using CPUStatus =
  drdds::msg::CPUStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__CPU_STATUS__STRUCT_HPP_
