// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/FaultEvent.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__FAULT_EVENT__TRAITS_HPP_

#include "drdds/msg/detail/fault_event__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::FaultEvent>()
{
  return "drdds::msg::FaultEvent";
}

template<>
inline const char * name<drdds::msg::FaultEvent>()
{
  return "drdds/msg/FaultEvent";
}

template<>
struct has_fixed_size<drdds::msg::FaultEvent>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::FaultEvent>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::FaultEvent>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT__TRAITS_HPP_
