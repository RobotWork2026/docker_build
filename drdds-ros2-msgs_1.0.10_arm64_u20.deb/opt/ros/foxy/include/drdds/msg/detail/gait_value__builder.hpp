// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/GaitValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GAIT_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__GAIT_VALUE__BUILDER_HPP_

#include "drdds/msg/detail/gait_value__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_GaitValue_gait
{
public:
  Init_GaitValue_gait()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::drdds::msg::GaitValue gait(::drdds::msg::GaitValue::_gait_type arg)
  {
    msg_.gait = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::GaitValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::GaitValue>()
{
  return drdds::msg::builder::Init_GaitValue_gait();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__GAIT_VALUE__BUILDER_HPP_
