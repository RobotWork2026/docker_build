// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/ImuData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__IMU_DATA__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__IMU_DATA__TRAITS_HPP_

#include "drdds/msg/detail/imu_data__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__traits.hpp"
// Member 'data'
#include "drdds/msg/detail/imu_data_value__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::ImuData>()
{
  return "drdds::msg::ImuData";
}

template<>
inline const char * name<drdds::msg::ImuData>()
{
  return "drdds/msg/ImuData";
}

template<>
struct has_fixed_size<drdds::msg::ImuData>
  : std::integral_constant<bool, has_fixed_size<drdds::msg::ImuDataValue>::value && has_fixed_size<drdds::msg::MetaType>::value> {};

template<>
struct has_bounded_size<drdds::msg::ImuData>
  : std::integral_constant<bool, has_bounded_size<drdds::msg::ImuDataValue>::value && has_bounded_size<drdds::msg::MetaType>::value> {};

template<>
struct is_message<drdds::msg::ImuData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__IMU_DATA__TRAITS_HPP_
