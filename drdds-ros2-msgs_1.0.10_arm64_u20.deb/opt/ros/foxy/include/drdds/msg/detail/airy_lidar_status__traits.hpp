// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/AiryLidarStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__TRAITS_HPP_

#include "drdds/msg/detail/airy_lidar_status__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::AiryLidarStatus>()
{
  return "drdds::msg::AiryLidarStatus";
}

template<>
inline const char * name<drdds::msg::AiryLidarStatus>()
{
  return "drdds/msg/AiryLidarStatus";
}

template<>
struct has_fixed_size<drdds::msg::AiryLidarStatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::AiryLidarStatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::AiryLidarStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__TRAITS_HPP_
