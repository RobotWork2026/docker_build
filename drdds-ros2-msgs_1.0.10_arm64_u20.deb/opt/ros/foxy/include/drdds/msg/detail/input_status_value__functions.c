// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/InputStatusValue.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/input_status_value__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
drdds__msg__InputStatusValue__init(drdds__msg__InputStatusValue * msg)
{
  if (!msg) {
    return false;
  }
  // lidar
  // imu
  // leg_odom
  // rtk
  // tag
  // reflective_strip
  return true;
}

void
drdds__msg__InputStatusValue__fini(drdds__msg__InputStatusValue * msg)
{
  if (!msg) {
    return;
  }
  // lidar
  // imu
  // leg_odom
  // rtk
  // tag
  // reflective_strip
}

bool
drdds__msg__InputStatusValue__are_equal(const drdds__msg__InputStatusValue * lhs, const drdds__msg__InputStatusValue * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // lidar
  if (lhs->lidar != rhs->lidar) {
    return false;
  }
  // imu
  if (lhs->imu != rhs->imu) {
    return false;
  }
  // leg_odom
  if (lhs->leg_odom != rhs->leg_odom) {
    return false;
  }
  // rtk
  if (lhs->rtk != rhs->rtk) {
    return false;
  }
  // tag
  if (lhs->tag != rhs->tag) {
    return false;
  }
  // reflective_strip
  if (lhs->reflective_strip != rhs->reflective_strip) {
    return false;
  }
  return true;
}

bool
drdds__msg__InputStatusValue__copy(
  const drdds__msg__InputStatusValue * input,
  drdds__msg__InputStatusValue * output)
{
  if (!input || !output) {
    return false;
  }
  // lidar
  output->lidar = input->lidar;
  // imu
  output->imu = input->imu;
  // leg_odom
  output->leg_odom = input->leg_odom;
  // rtk
  output->rtk = input->rtk;
  // tag
  output->tag = input->tag;
  // reflective_strip
  output->reflective_strip = input->reflective_strip;
  return true;
}

drdds__msg__InputStatusValue *
drdds__msg__InputStatusValue__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__InputStatusValue * msg = (drdds__msg__InputStatusValue *)allocator.allocate(sizeof(drdds__msg__InputStatusValue), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__InputStatusValue));
  bool success = drdds__msg__InputStatusValue__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__InputStatusValue__destroy(drdds__msg__InputStatusValue * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__InputStatusValue__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__InputStatusValue__Sequence__init(drdds__msg__InputStatusValue__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__InputStatusValue * data = NULL;

  if (size) {
    data = (drdds__msg__InputStatusValue *)allocator.zero_allocate(size, sizeof(drdds__msg__InputStatusValue), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__InputStatusValue__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__InputStatusValue__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__InputStatusValue__Sequence__fini(drdds__msg__InputStatusValue__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__InputStatusValue__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__InputStatusValue__Sequence *
drdds__msg__InputStatusValue__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__InputStatusValue__Sequence * array = (drdds__msg__InputStatusValue__Sequence *)allocator.allocate(sizeof(drdds__msg__InputStatusValue__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__InputStatusValue__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__InputStatusValue__Sequence__destroy(drdds__msg__InputStatusValue__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__InputStatusValue__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__InputStatusValue__Sequence__are_equal(const drdds__msg__InputStatusValue__Sequence * lhs, const drdds__msg__InputStatusValue__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__InputStatusValue__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__InputStatusValue__Sequence__copy(
  const drdds__msg__InputStatusValue__Sequence * input,
  drdds__msg__InputStatusValue__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__InputStatusValue);
    drdds__msg__InputStatusValue * data =
      (drdds__msg__InputStatusValue *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__InputStatusValue__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          drdds__msg__InputStatusValue__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__InputStatusValue__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
