// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/FaultEventArray.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"
// Member 'active_faults'
#include "drdds/msg/detail/fault_event__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__drdds__msg__FaultEventArray __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__FaultEventArray __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct FaultEventArray_
{
  using Type = FaultEventArray_<ContainerAllocator>;

  explicit FaultEventArray_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    (void)_init;
  }

  explicit FaultEventArray_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;
  using _active_faults_type =
    std::vector<drdds::msg::FaultEvent_<ContainerAllocator>, typename ContainerAllocator::template rebind<drdds::msg::FaultEvent_<ContainerAllocator>>::other>;
  _active_faults_type active_faults;

  // setters for named parameter idiom
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__active_faults(
    const std::vector<drdds::msg::FaultEvent_<ContainerAllocator>, typename ContainerAllocator::template rebind<drdds::msg::FaultEvent_<ContainerAllocator>>::other> & _arg)
  {
    this->active_faults = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::FaultEventArray_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::FaultEventArray_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::FaultEventArray_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::FaultEventArray_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::FaultEventArray_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::FaultEventArray_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::FaultEventArray_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::FaultEventArray_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::FaultEventArray_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::FaultEventArray_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__FaultEventArray
    std::shared_ptr<drdds::msg::FaultEventArray_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__FaultEventArray
    std::shared_ptr<drdds::msg::FaultEventArray_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FaultEventArray_ & other) const
  {
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->active_faults != other.active_faults) {
      return false;
    }
    return true;
  }
  bool operator!=(const FaultEventArray_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FaultEventArray_

// alias to use template instance with default allocator
using FaultEventArray =
  drdds::msg::FaultEventArray_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__STRUCT_HPP_
