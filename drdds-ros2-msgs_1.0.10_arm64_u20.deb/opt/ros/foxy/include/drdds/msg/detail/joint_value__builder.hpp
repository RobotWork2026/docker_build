// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/JointValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__JOINT_VALUE__BUILDER_HPP_

#include "drdds/msg/detail/joint_value__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_JointValue_driver_temp
{
public:
  explicit Init_JointValue_driver_temp(::drdds::msg::JointValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::JointValue driver_temp(::drdds::msg::JointValue::_driver_temp_type arg)
  {
    msg_.driver_temp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::JointValue msg_;
};

class Init_JointValue_motion_temp
{
public:
  explicit Init_JointValue_motion_temp(::drdds::msg::JointValue & msg)
  : msg_(msg)
  {}
  Init_JointValue_driver_temp motion_temp(::drdds::msg::JointValue::_motion_temp_type arg)
  {
    msg_.motion_temp = std::move(arg);
    return Init_JointValue_driver_temp(msg_);
  }

private:
  ::drdds::msg::JointValue msg_;
};

class Init_JointValue_velocity
{
public:
  explicit Init_JointValue_velocity(::drdds::msg::JointValue & msg)
  : msg_(msg)
  {}
  Init_JointValue_motion_temp velocity(::drdds::msg::JointValue::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_JointValue_motion_temp(msg_);
  }

private:
  ::drdds::msg::JointValue msg_;
};

class Init_JointValue_torque
{
public:
  explicit Init_JointValue_torque(::drdds::msg::JointValue & msg)
  : msg_(msg)
  {}
  Init_JointValue_velocity torque(::drdds::msg::JointValue::_torque_type arg)
  {
    msg_.torque = std::move(arg);
    return Init_JointValue_velocity(msg_);
  }

private:
  ::drdds::msg::JointValue msg_;
};

class Init_JointValue_position
{
public:
  explicit Init_JointValue_position(::drdds::msg::JointValue & msg)
  : msg_(msg)
  {}
  Init_JointValue_torque position(::drdds::msg::JointValue::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_JointValue_torque(msg_);
  }

private:
  ::drdds::msg::JointValue msg_;
};

class Init_JointValue_status_word
{
public:
  explicit Init_JointValue_status_word(::drdds::msg::JointValue & msg)
  : msg_(msg)
  {}
  Init_JointValue_position status_word(::drdds::msg::JointValue::_status_word_type arg)
  {
    msg_.status_word = std::move(arg);
    return Init_JointValue_position(msg_);
  }

private:
  ::drdds::msg::JointValue msg_;
};

class Init_JointValue_data_id
{
public:
  explicit Init_JointValue_data_id(::drdds::msg::JointValue & msg)
  : msg_(msg)
  {}
  Init_JointValue_status_word data_id(::drdds::msg::JointValue::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_JointValue_status_word(msg_);
  }

private:
  ::drdds::msg::JointValue msg_;
};

class Init_JointValue_name
{
public:
  Init_JointValue_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_JointValue_data_id name(::drdds::msg::JointValue::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_JointValue_data_id(msg_);
  }

private:
  ::drdds::msg::JointValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::JointValue>()
{
  return drdds::msg::builder::Init_JointValue_name();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__JOINT_VALUE__BUILDER_HPP_
