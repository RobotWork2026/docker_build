// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/CpuData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__CPU_DATA__TRAITS_HPP_

#include "drdds/msg/detail/cpu_data__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__traits.hpp"
// Member 'data'
#include "drdds/msg/detail/cpu_data_value__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::CpuData>()
{
  return "drdds::msg::CpuData";
}

template<>
inline const char * name<drdds::msg::CpuData>()
{
  return "drdds/msg/CpuData";
}

template<>
struct has_fixed_size<drdds::msg::CpuData>
  : std::integral_constant<bool, has_fixed_size<drdds::msg::CpuDataValue>::value && has_fixed_size<drdds::msg::MetaType>::value> {};

template<>
struct has_bounded_size<drdds::msg::CpuData>
  : std::integral_constant<bool, has_bounded_size<drdds::msg::CpuDataValue>::value && has_bounded_size<drdds::msg::MetaType>::value> {};

template<>
struct is_message<drdds::msg::CpuData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__CPU_DATA__TRAITS_HPP_
