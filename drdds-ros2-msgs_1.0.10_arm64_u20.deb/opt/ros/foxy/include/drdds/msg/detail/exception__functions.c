// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/Exception.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/exception__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `stamp`
#include "builtin_interfaces/msg/detail/time__functions.h"
// Member `source`
// Member `description`
#include "rosidl_runtime_c/string_functions.h"

bool
drdds__msg__Exception__init(drdds__msg__Exception * msg)
{
  if (!msg) {
    return false;
  }
  // stamp
  if (!builtin_interfaces__msg__Time__init(&msg->stamp)) {
    drdds__msg__Exception__fini(msg);
    return false;
  }
  // source
  if (!rosidl_runtime_c__String__init(&msg->source)) {
    drdds__msg__Exception__fini(msg);
    return false;
  }
  // description
  if (!rosidl_runtime_c__String__init(&msg->description)) {
    drdds__msg__Exception__fini(msg);
    return false;
  }
  // is_abnormal
  return true;
}

void
drdds__msg__Exception__fini(drdds__msg__Exception * msg)
{
  if (!msg) {
    return;
  }
  // stamp
  builtin_interfaces__msg__Time__fini(&msg->stamp);
  // source
  rosidl_runtime_c__String__fini(&msg->source);
  // description
  rosidl_runtime_c__String__fini(&msg->description);
  // is_abnormal
}

bool
drdds__msg__Exception__are_equal(const drdds__msg__Exception * lhs, const drdds__msg__Exception * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // stamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->stamp), &(rhs->stamp)))
  {
    return false;
  }
  // source
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->source), &(rhs->source)))
  {
    return false;
  }
  // description
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->description), &(rhs->description)))
  {
    return false;
  }
  // is_abnormal
  if (lhs->is_abnormal != rhs->is_abnormal) {
    return false;
  }
  return true;
}

bool
drdds__msg__Exception__copy(
  const drdds__msg__Exception * input,
  drdds__msg__Exception * output)
{
  if (!input || !output) {
    return false;
  }
  // stamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->stamp), &(output->stamp)))
  {
    return false;
  }
  // source
  if (!rosidl_runtime_c__String__copy(
      &(input->source), &(output->source)))
  {
    return false;
  }
  // description
  if (!rosidl_runtime_c__String__copy(
      &(input->description), &(output->description)))
  {
    return false;
  }
  // is_abnormal
  output->is_abnormal = input->is_abnormal;
  return true;
}

drdds__msg__Exception *
drdds__msg__Exception__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__Exception * msg = (drdds__msg__Exception *)allocator.allocate(sizeof(drdds__msg__Exception), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__Exception));
  bool success = drdds__msg__Exception__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__Exception__destroy(drdds__msg__Exception * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__Exception__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__Exception__Sequence__init(drdds__msg__Exception__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__Exception * data = NULL;

  if (size) {
    data = (drdds__msg__Exception *)allocator.zero_allocate(size, sizeof(drdds__msg__Exception), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__Exception__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__Exception__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__Exception__Sequence__fini(drdds__msg__Exception__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__Exception__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__Exception__Sequence *
drdds__msg__Exception__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__Exception__Sequence * array = (drdds__msg__Exception__Sequence *)allocator.allocate(sizeof(drdds__msg__Exception__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__Exception__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__Exception__Sequence__destroy(drdds__msg__Exception__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__Exception__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__Exception__Sequence__are_equal(const drdds__msg__Exception__Sequence * lhs, const drdds__msg__Exception__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__Exception__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__Exception__Sequence__copy(
  const drdds__msg__Exception__Sequence * input,
  drdds__msg__Exception__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__Exception);
    drdds__msg__Exception * data =
      (drdds__msg__Exception *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__Exception__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          drdds__msg__Exception__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__Exception__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
