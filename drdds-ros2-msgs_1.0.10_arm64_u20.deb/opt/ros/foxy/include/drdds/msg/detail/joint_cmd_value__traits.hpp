// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/JointCmdValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__TRAITS_HPP_

#include "drdds/msg/detail/joint_cmd_value__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::JointCmdValue>()
{
  return "drdds::msg::JointCmdValue";
}

template<>
inline const char * name<drdds::msg::JointCmdValue>()
{
  return "drdds/msg/JointCmdValue";
}

template<>
struct has_fixed_size<drdds::msg::JointCmdValue>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::JointCmdValue>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::JointCmdValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__TRAITS_HPP_
