// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from drdds:msg/CpuDataValue.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "drdds/msg/detail/cpu_data_value__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace drdds
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void CpuDataValue_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) drdds::msg::CpuDataValue(_init);
}

void CpuDataValue_fini_function(void * message_memory)
{
  auto typed_message = static_cast<drdds::msg::CpuDataValue *>(message_memory);
  typed_message->~CpuDataValue();
}

size_t size_function__CpuDataValue__cpu_temperature(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__CpuDataValue__cpu_temperature(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__CpuDataValue__cpu_temperature(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void resize_function__CpuDataValue__cpu_temperature(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  member->resize(size);
}

size_t size_function__CpuDataValue__cpu_frequency(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return member->size();
}

const void * get_const_function__CpuDataValue__cpu_frequency(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void * get_function__CpuDataValue__cpu_frequency(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  return &member[index];
}

void resize_function__CpuDataValue__cpu_frequency(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<uint32_t> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember CpuDataValue_message_member_array[2] = {
  {
    "cpu_temperature",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CpuDataValue, cpu_temperature),  // bytes offset in struct
    nullptr,  // default value
    size_function__CpuDataValue__cpu_temperature,  // size() function pointer
    get_const_function__CpuDataValue__cpu_temperature,  // get_const(index) function pointer
    get_function__CpuDataValue__cpu_temperature,  // get(index) function pointer
    resize_function__CpuDataValue__cpu_temperature  // resize(index) function pointer
  },
  {
    "cpu_frequency",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds::msg::CpuDataValue, cpu_frequency),  // bytes offset in struct
    nullptr,  // default value
    size_function__CpuDataValue__cpu_frequency,  // size() function pointer
    get_const_function__CpuDataValue__cpu_frequency,  // get_const(index) function pointer
    get_function__CpuDataValue__cpu_frequency,  // get(index) function pointer
    resize_function__CpuDataValue__cpu_frequency  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers CpuDataValue_message_members = {
  "drdds::msg",  // message namespace
  "CpuDataValue",  // message name
  2,  // number of fields
  sizeof(drdds::msg::CpuDataValue),
  CpuDataValue_message_member_array,  // message members
  CpuDataValue_init_function,  // function to initialize message memory (memory has to be allocated)
  CpuDataValue_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t CpuDataValue_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &CpuDataValue_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace drdds


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<drdds::msg::CpuDataValue>()
{
  return &::drdds::msg::rosidl_typesupport_introspection_cpp::CpuDataValue_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, drdds, msg, CpuDataValue)() {
  return &::drdds::msg::rosidl_typesupport_introspection_cpp::CpuDataValue_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
