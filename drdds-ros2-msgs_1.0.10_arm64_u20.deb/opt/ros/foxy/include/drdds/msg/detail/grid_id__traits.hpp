// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/GridID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRID_ID__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__GRID_ID__TRAITS_HPP_

#include "drdds/msg/detail/grid_id__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::GridID>()
{
  return "drdds::msg::GridID";
}

template<>
inline const char * name<drdds::msg::GridID>()
{
  return "drdds/msg/GridID";
}

template<>
struct has_fixed_size<drdds::msg::GridID>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::GridID>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::GridID>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__GRID_ID__TRAITS_HPP_
