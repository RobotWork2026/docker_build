// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/Exception.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXCEPTION__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__EXCEPTION__BUILDER_HPP_

#include "drdds/msg/detail/exception__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_Exception_is_abnormal
{
public:
  explicit Init_Exception_is_abnormal(::drdds::msg::Exception & msg)
  : msg_(msg)
  {}
  ::drdds::msg::Exception is_abnormal(::drdds::msg::Exception::_is_abnormal_type arg)
  {
    msg_.is_abnormal = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::Exception msg_;
};

class Init_Exception_description
{
public:
  explicit Init_Exception_description(::drdds::msg::Exception & msg)
  : msg_(msg)
  {}
  Init_Exception_is_abnormal description(::drdds::msg::Exception::_description_type arg)
  {
    msg_.description = std::move(arg);
    return Init_Exception_is_abnormal(msg_);
  }

private:
  ::drdds::msg::Exception msg_;
};

class Init_Exception_source
{
public:
  explicit Init_Exception_source(::drdds::msg::Exception & msg)
  : msg_(msg)
  {}
  Init_Exception_description source(::drdds::msg::Exception::_source_type arg)
  {
    msg_.source = std::move(arg);
    return Init_Exception_description(msg_);
  }

private:
  ::drdds::msg::Exception msg_;
};

class Init_Exception_stamp
{
public:
  Init_Exception_stamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Exception_source stamp(::drdds::msg::Exception::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return Init_Exception_source(msg_);
  }

private:
  ::drdds::msg::Exception msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::Exception>()
{
  return drdds::msg::builder::Init_Exception_stamp();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__EXCEPTION__BUILDER_HPP_
