// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from drdds:msg/FileSystemStatus.idl
// generated code does not contain a copyright notice
#ifndef DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "drdds/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_drdds
size_t get_serialized_size_drdds__msg__FileSystemStatus(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_drdds
size_t max_serialized_size_drdds__msg__FileSystemStatus(
  bool & full_bounded,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, drdds, msg, FileSystemStatus)();

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
