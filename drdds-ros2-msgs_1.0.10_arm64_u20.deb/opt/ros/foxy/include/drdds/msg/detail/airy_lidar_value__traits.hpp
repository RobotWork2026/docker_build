// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/AiryLidarValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__TRAITS_HPP_

#include "drdds/msg/detail/airy_lidar_value__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<drdds::msg::AiryLidarValue>()
{
  return "drdds::msg::AiryLidarValue";
}

template<>
inline const char * name<drdds::msg::AiryLidarValue>()
{
  return "drdds/msg/AiryLidarValue";
}

template<>
struct has_fixed_size<drdds::msg::AiryLidarValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::AiryLidarValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::AiryLidarValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__TRAITS_HPP_
