// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/CPUStatus.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/cpu_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__functions.h"
// Member `soc_id`
// Member `gov_policy`
#include "rosidl_runtime_c/string_functions.h"
// Member `temps`
// Member `util`
// Member `cur_freq_khz`
// Member `hw_max_freq_khz`
// Member `hw_min_freq_khz`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
drdds__msg__CPUStatus__init(drdds__msg__CPUStatus * msg)
{
  if (!msg) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__init(&msg->timestamp)) {
    drdds__msg__CPUStatus__fini(msg);
    return false;
  }
  // soc_id
  if (!rosidl_runtime_c__String__init(&msg->soc_id)) {
    drdds__msg__CPUStatus__fini(msg);
    return false;
  }
  // package_temp
  // temps
  if (!rosidl_runtime_c__int32__Sequence__init(&msg->temps, 0)) {
    drdds__msg__CPUStatus__fini(msg);
    return false;
  }
  // avg_util
  // util
  if (!rosidl_runtime_c__uint16__Sequence__init(&msg->util, 0)) {
    drdds__msg__CPUStatus__fini(msg);
    return false;
  }
  // cur_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->cur_freq_khz, 0)) {
    drdds__msg__CPUStatus__fini(msg);
    return false;
  }
  // hw_max_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->hw_max_freq_khz, 0)) {
    drdds__msg__CPUStatus__fini(msg);
    return false;
  }
  // hw_min_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->hw_min_freq_khz, 0)) {
    drdds__msg__CPUStatus__fini(msg);
    return false;
  }
  // gov_policy
  if (!rosidl_runtime_c__String__Sequence__init(&msg->gov_policy, 0)) {
    drdds__msg__CPUStatus__fini(msg);
    return false;
  }
  return true;
}

void
drdds__msg__CPUStatus__fini(drdds__msg__CPUStatus * msg)
{
  if (!msg) {
    return;
  }
  // timestamp
  builtin_interfaces__msg__Time__fini(&msg->timestamp);
  // soc_id
  rosidl_runtime_c__String__fini(&msg->soc_id);
  // package_temp
  // temps
  rosidl_runtime_c__int32__Sequence__fini(&msg->temps);
  // avg_util
  // util
  rosidl_runtime_c__uint16__Sequence__fini(&msg->util);
  // cur_freq_khz
  rosidl_runtime_c__uint32__Sequence__fini(&msg->cur_freq_khz);
  // hw_max_freq_khz
  rosidl_runtime_c__uint32__Sequence__fini(&msg->hw_max_freq_khz);
  // hw_min_freq_khz
  rosidl_runtime_c__uint32__Sequence__fini(&msg->hw_min_freq_khz);
  // gov_policy
  rosidl_runtime_c__String__Sequence__fini(&msg->gov_policy);
}

bool
drdds__msg__CPUStatus__are_equal(const drdds__msg__CPUStatus * lhs, const drdds__msg__CPUStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->timestamp), &(rhs->timestamp)))
  {
    return false;
  }
  // soc_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->soc_id), &(rhs->soc_id)))
  {
    return false;
  }
  // package_temp
  if (lhs->package_temp != rhs->package_temp) {
    return false;
  }
  // temps
  if (!rosidl_runtime_c__int32__Sequence__are_equal(
      &(lhs->temps), &(rhs->temps)))
  {
    return false;
  }
  // avg_util
  if (lhs->avg_util != rhs->avg_util) {
    return false;
  }
  // util
  if (!rosidl_runtime_c__uint16__Sequence__are_equal(
      &(lhs->util), &(rhs->util)))
  {
    return false;
  }
  // cur_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__are_equal(
      &(lhs->cur_freq_khz), &(rhs->cur_freq_khz)))
  {
    return false;
  }
  // hw_max_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__are_equal(
      &(lhs->hw_max_freq_khz), &(rhs->hw_max_freq_khz)))
  {
    return false;
  }
  // hw_min_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__are_equal(
      &(lhs->hw_min_freq_khz), &(rhs->hw_min_freq_khz)))
  {
    return false;
  }
  // gov_policy
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->gov_policy), &(rhs->gov_policy)))
  {
    return false;
  }
  return true;
}

bool
drdds__msg__CPUStatus__copy(
  const drdds__msg__CPUStatus * input,
  drdds__msg__CPUStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->timestamp), &(output->timestamp)))
  {
    return false;
  }
  // soc_id
  if (!rosidl_runtime_c__String__copy(
      &(input->soc_id), &(output->soc_id)))
  {
    return false;
  }
  // package_temp
  output->package_temp = input->package_temp;
  // temps
  if (!rosidl_runtime_c__int32__Sequence__copy(
      &(input->temps), &(output->temps)))
  {
    return false;
  }
  // avg_util
  output->avg_util = input->avg_util;
  // util
  if (!rosidl_runtime_c__uint16__Sequence__copy(
      &(input->util), &(output->util)))
  {
    return false;
  }
  // cur_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__copy(
      &(input->cur_freq_khz), &(output->cur_freq_khz)))
  {
    return false;
  }
  // hw_max_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__copy(
      &(input->hw_max_freq_khz), &(output->hw_max_freq_khz)))
  {
    return false;
  }
  // hw_min_freq_khz
  if (!rosidl_runtime_c__uint32__Sequence__copy(
      &(input->hw_min_freq_khz), &(output->hw_min_freq_khz)))
  {
    return false;
  }
  // gov_policy
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->gov_policy), &(output->gov_policy)))
  {
    return false;
  }
  return true;
}

drdds__msg__CPUStatus *
drdds__msg__CPUStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__CPUStatus * msg = (drdds__msg__CPUStatus *)allocator.allocate(sizeof(drdds__msg__CPUStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__CPUStatus));
  bool success = drdds__msg__CPUStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__CPUStatus__destroy(drdds__msg__CPUStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__CPUStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__CPUStatus__Sequence__init(drdds__msg__CPUStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__CPUStatus * data = NULL;

  if (size) {
    data = (drdds__msg__CPUStatus *)allocator.zero_allocate(size, sizeof(drdds__msg__CPUStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__CPUStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__CPUStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__CPUStatus__Sequence__fini(drdds__msg__CPUStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__CPUStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__CPUStatus__Sequence *
drdds__msg__CPUStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__CPUStatus__Sequence * array = (drdds__msg__CPUStatus__Sequence *)allocator.allocate(sizeof(drdds__msg__CPUStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__CPUStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__CPUStatus__Sequence__destroy(drdds__msg__CPUStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__CPUStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__CPUStatus__Sequence__are_equal(const drdds__msg__CPUStatus__Sequence * lhs, const drdds__msg__CPUStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__CPUStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__CPUStatus__Sequence__copy(
  const drdds__msg__CPUStatus__Sequence * input,
  drdds__msg__CPUStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__CPUStatus);
    drdds__msg__CPUStatus * data =
      (drdds__msg__CPUStatus *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__CPUStatus__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          drdds__msg__CPUStatus__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__CPUStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
