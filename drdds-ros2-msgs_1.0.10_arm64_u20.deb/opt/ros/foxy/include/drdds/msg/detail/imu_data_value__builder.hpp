// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/ImuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__IMU_DATA_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__IMU_DATA_VALUE__BUILDER_HPP_

#include "drdds/msg/detail/imu_data_value__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_ImuDataValue_acc_z
{
public:
  explicit Init_ImuDataValue_acc_z(::drdds::msg::ImuDataValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::ImuDataValue acc_z(::drdds::msg::ImuDataValue::_acc_z_type arg)
  {
    msg_.acc_z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

class Init_ImuDataValue_acc_y
{
public:
  explicit Init_ImuDataValue_acc_y(::drdds::msg::ImuDataValue & msg)
  : msg_(msg)
  {}
  Init_ImuDataValue_acc_z acc_y(::drdds::msg::ImuDataValue::_acc_y_type arg)
  {
    msg_.acc_y = std::move(arg);
    return Init_ImuDataValue_acc_z(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

class Init_ImuDataValue_acc_x
{
public:
  explicit Init_ImuDataValue_acc_x(::drdds::msg::ImuDataValue & msg)
  : msg_(msg)
  {}
  Init_ImuDataValue_acc_y acc_x(::drdds::msg::ImuDataValue::_acc_x_type arg)
  {
    msg_.acc_x = std::move(arg);
    return Init_ImuDataValue_acc_y(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

class Init_ImuDataValue_omega_z
{
public:
  explicit Init_ImuDataValue_omega_z(::drdds::msg::ImuDataValue & msg)
  : msg_(msg)
  {}
  Init_ImuDataValue_acc_x omega_z(::drdds::msg::ImuDataValue::_omega_z_type arg)
  {
    msg_.omega_z = std::move(arg);
    return Init_ImuDataValue_acc_x(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

class Init_ImuDataValue_omega_y
{
public:
  explicit Init_ImuDataValue_omega_y(::drdds::msg::ImuDataValue & msg)
  : msg_(msg)
  {}
  Init_ImuDataValue_omega_z omega_y(::drdds::msg::ImuDataValue::_omega_y_type arg)
  {
    msg_.omega_y = std::move(arg);
    return Init_ImuDataValue_omega_z(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

class Init_ImuDataValue_omega_x
{
public:
  explicit Init_ImuDataValue_omega_x(::drdds::msg::ImuDataValue & msg)
  : msg_(msg)
  {}
  Init_ImuDataValue_omega_y omega_x(::drdds::msg::ImuDataValue::_omega_x_type arg)
  {
    msg_.omega_x = std::move(arg);
    return Init_ImuDataValue_omega_y(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

class Init_ImuDataValue_yaw
{
public:
  explicit Init_ImuDataValue_yaw(::drdds::msg::ImuDataValue & msg)
  : msg_(msg)
  {}
  Init_ImuDataValue_omega_x yaw(::drdds::msg::ImuDataValue::_yaw_type arg)
  {
    msg_.yaw = std::move(arg);
    return Init_ImuDataValue_omega_x(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

class Init_ImuDataValue_pitch
{
public:
  explicit Init_ImuDataValue_pitch(::drdds::msg::ImuDataValue & msg)
  : msg_(msg)
  {}
  Init_ImuDataValue_yaw pitch(::drdds::msg::ImuDataValue::_pitch_type arg)
  {
    msg_.pitch = std::move(arg);
    return Init_ImuDataValue_yaw(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

class Init_ImuDataValue_roll
{
public:
  Init_ImuDataValue_roll()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ImuDataValue_pitch roll(::drdds::msg::ImuDataValue::_roll_type arg)
  {
    msg_.roll = std::move(arg);
    return Init_ImuDataValue_pitch(msg_);
  }

private:
  ::drdds::msg::ImuDataValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::ImuDataValue>()
{
  return drdds::msg::builder::Init_ImuDataValue_roll();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__IMU_DATA_VALUE__BUILDER_HPP_
