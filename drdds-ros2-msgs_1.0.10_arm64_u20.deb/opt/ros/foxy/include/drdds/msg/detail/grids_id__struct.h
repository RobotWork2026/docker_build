// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/GridsID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRIDS_ID__STRUCT_H_
#define DRDDS__MSG__DETAIL__GRIDS_ID__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'path'
#include "rosidl_runtime_c/string.h"
// Member 'grids'
#include "drdds/msg/detail/grid_id__struct.h"

// Struct defined in msg/GridsID in the package drdds.
typedef struct drdds__msg__GridsID
{
  rosidl_runtime_c__String path;
  drdds__msg__GridID__Sequence grids;
} drdds__msg__GridsID;

// Struct for a sequence of drdds__msg__GridsID.
typedef struct drdds__msg__GridsID__Sequence
{
  drdds__msg__GridsID * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__GridsID__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__GRIDS_ID__STRUCT_H_
