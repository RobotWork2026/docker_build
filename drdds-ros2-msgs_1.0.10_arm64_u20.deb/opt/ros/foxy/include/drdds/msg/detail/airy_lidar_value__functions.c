// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/AiryLidarValue.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/airy_lidar_value__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
drdds__msg__AiryLidarValue__init(drdds__msg__AiryLidarValue * msg)
{
  if (!msg) {
    return false;
  }
  // is_runing
  // error_code
  // cld_size
  // temp
  // voltage
  return true;
}

void
drdds__msg__AiryLidarValue__fini(drdds__msg__AiryLidarValue * msg)
{
  if (!msg) {
    return;
  }
  // is_runing
  // error_code
  // cld_size
  // temp
  // voltage
}

bool
drdds__msg__AiryLidarValue__are_equal(const drdds__msg__AiryLidarValue * lhs, const drdds__msg__AiryLidarValue * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // is_runing
  if (lhs->is_runing != rhs->is_runing) {
    return false;
  }
  // error_code
  if (lhs->error_code != rhs->error_code) {
    return false;
  }
  // cld_size
  if (lhs->cld_size != rhs->cld_size) {
    return false;
  }
  // temp
  if (lhs->temp != rhs->temp) {
    return false;
  }
  // voltage
  if (lhs->voltage != rhs->voltage) {
    return false;
  }
  return true;
}

bool
drdds__msg__AiryLidarValue__copy(
  const drdds__msg__AiryLidarValue * input,
  drdds__msg__AiryLidarValue * output)
{
  if (!input || !output) {
    return false;
  }
  // is_runing
  output->is_runing = input->is_runing;
  // error_code
  output->error_code = input->error_code;
  // cld_size
  output->cld_size = input->cld_size;
  // temp
  output->temp = input->temp;
  // voltage
  output->voltage = input->voltage;
  return true;
}

drdds__msg__AiryLidarValue *
drdds__msg__AiryLidarValue__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__AiryLidarValue * msg = (drdds__msg__AiryLidarValue *)allocator.allocate(sizeof(drdds__msg__AiryLidarValue), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__AiryLidarValue));
  bool success = drdds__msg__AiryLidarValue__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__AiryLidarValue__destroy(drdds__msg__AiryLidarValue * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__AiryLidarValue__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__AiryLidarValue__Sequence__init(drdds__msg__AiryLidarValue__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__AiryLidarValue * data = NULL;

  if (size) {
    data = (drdds__msg__AiryLidarValue *)allocator.zero_allocate(size, sizeof(drdds__msg__AiryLidarValue), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__AiryLidarValue__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__AiryLidarValue__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__AiryLidarValue__Sequence__fini(drdds__msg__AiryLidarValue__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__AiryLidarValue__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__AiryLidarValue__Sequence *
drdds__msg__AiryLidarValue__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__AiryLidarValue__Sequence * array = (drdds__msg__AiryLidarValue__Sequence *)allocator.allocate(sizeof(drdds__msg__AiryLidarValue__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__AiryLidarValue__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__AiryLidarValue__Sequence__destroy(drdds__msg__AiryLidarValue__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__AiryLidarValue__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__AiryLidarValue__Sequence__are_equal(const drdds__msg__AiryLidarValue__Sequence * lhs, const drdds__msg__AiryLidarValue__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__AiryLidarValue__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__AiryLidarValue__Sequence__copy(
  const drdds__msg__AiryLidarValue__Sequence * input,
  drdds__msg__AiryLidarValue__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__AiryLidarValue);
    drdds__msg__AiryLidarValue * data =
      (drdds__msg__AiryLidarValue *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__AiryLidarValue__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          drdds__msg__AiryLidarValue__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__AiryLidarValue__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
