#!/bin/bash

XML_FILE="/opt/robot/fastdds.xml"

# 检查 XML 文件是否存在
if [ ! -f "$XML_FILE" ]; then
    echo "Error: $XML_FILE not found"
    exit 1
fi

###############################################################################
# 1️⃣ 明确：判断逻辑只依赖 eth0 的“单一 IP”
###############################################################################

ETH0_IP=$(ip -4 addr show eth0 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1)

if [ -z "$ETH0_IP" ]; then
    echo "Error: Could not detect eth0 IPv4 address"
    exit 1
fi

echo "Detected eth0 IP: $ETH0_IP"

###############################################################################
# 2️⃣ 从 eth0 IP 中解析最后一段（绝对安全）
###############################################################################

LAST_SEGMENT="${ETH0_IP##*.}"

###############################################################################
# 3️⃣ 根据 eth0 IP 的最后一段，决定要写入的 IP_LIST
###############################################################################

case "$LAST_SEGMENT" in
    103)
        IP_LIST="10.21.33.103"
        ;;
    106)
        IP_LIST="10.21.33.106 "
        ;;
    104)
        IP_LIST="10.21.31.104"
        ;;
    *)
        echo "Unknown eth0 IP last segment: $LAST_SEGMENT"
        IP_LIST="$ETH0_IP"
        ;;
esac

echo "Selected IP(s) based on eth0 IP ($ETH0_IP): $IP_LIST"

###############################################################################
# 4️⃣ 写入 fastdds.xml（幂等）
###############################################################################

for ip in $IP_LIST; do
    if grep -q "<address>${ip}</address>" "$XML_FILE"; then
        echo "IP ${ip} already exists in $XML_FILE"
    else
        sudo sed -i "/<\/interfaceWhiteList>/i \                <address>${ip}<\/address>" "$XML_FILE"
        echo "Inserted <address>${ip}</address> into $XML_FILE"
    fi
done

###############################################################################
# 5️⃣ ROS 2 环境
###############################################################################

if [ ! -f /etc/os-release ]; then
    echo "Error: /etc/os-release not found; cannot detect Ubuntu version"
    exit 1
fi

. /etc/os-release

if [ "${ID:-}" != "ubuntu" ]; then
    echo "Error: Unsupported OS: ID='${ID:-unknown}'. Only Ubuntu is supported."
    exit 1
fi

case "${VERSION_ID:-}" in
    20.04)
        ROS_DISTRO="foxy"
        ;;
    22.04)
        ROS_DISTRO="humble"
        ;;
    24.04)
        ROS_DISTRO="jazzy"
        ;;
    *)
        echo "Error: Unsupported Ubuntu VERSION_ID='${VERSION_ID:-unknown}'. Supported: 20.04/22.04/24.04."
        exit 1
        ;;
esac

if [ -n "${ZSH_VERSION:-}" ]; then
    ROS_SETUP="/opt/ros/${ROS_DISTRO}/setup.zsh"
elif [ -n "${BASH_VERSION:-}" ]; then
    ROS_SETUP="/opt/ros/${ROS_DISTRO}/setup.bash"
else
    ROS_SETUP="/opt/ros/${ROS_DISTRO}/setup.bash"
fi

if [ ! -f "$ROS_SETUP" ]; then
    echo "Error: ROS 2 setup not found at '$ROS_SETUP'"
    exit 1
fi

echo "Detected Ubuntu ${VERSION_ID}; using ROS 2 '${ROS_DISTRO}'"
source "$ROS_SETUP"

export FASTRTPS_DEFAULT_PROFILES_FILE=/opt/robot/fastdds.xml
echo "source ros2 env success"
