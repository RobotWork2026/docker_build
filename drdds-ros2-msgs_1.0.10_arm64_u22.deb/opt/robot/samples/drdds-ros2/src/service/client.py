#!/usr/bin/env python3

import sys
import rclpy
from rclpy.node import Node
from drdds.srv import StdSrvInt32


class CommandServiceClient(Node):
    def __init__(self):
        super().__init__('command_service_client')
        self.client = self.create_client(StdSrvInt32, '/client')
        self.get_logger().info('Client created, waiting for service /client...')

    def call(self, command: int) -> int:
        request = StdSrvInt32.Request()
        request.command = command

        if not self.client.wait_for_service(timeout_sec=5.0):
            self.get_logger().error('Service /client not available')
            return None

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future, timeout_sec=10.0)

        if future.result() is not None:
            return future.result().result
        self.get_logger().error('Service call failed')
        return None


def main(args=None):
    rclpy.init(args=args)
    node = CommandServiceClient()

    command = 42
    if len(sys.argv) >= 2:
        try:
            command = int(sys.argv[1])
        except ValueError:
            node.get_logger().error('Usage: client.py [command:int]')
            node.destroy_node()
            rclpy.shutdown()
            sys.exit(1)

    node.get_logger().info(f'Calling /client with command={command}')
    result = node.call(command)
    if result is not None:
        node.get_logger().info(f'Result: {result}')

    node.destroy_node()
    rclpy.shutdown()
    sys.exit(0 if result is not None else 1)


if __name__ == '__main__':
    main()
