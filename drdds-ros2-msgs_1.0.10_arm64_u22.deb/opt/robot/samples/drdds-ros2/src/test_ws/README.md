# test_ws — 独立 Test 服务工作空间

仅包含 `test.srv` 接口及其请求/响应服务的 ROS2 工作空间，不依赖主工程的 drdds 包。

## 结构

```
test_ws/
  src/
    test_srv/          # 包：接口 + 服务端/客户端
      srv/test.srv     # 服务定义
      test_server.py   # 服务端
      test_client.py   # 客户端
```

## 编译与运行

```bash
cd test_ws
colcon build --packages-select test_srv
source install/setup.bash

# 终端 1：启动服务端
ros2 run test_srv test_server.py

# 终端 2：调用客户端（可选参数：map_url command）
ros2 run test_srv test_client.py
ros2 run test_srv test_client.py "file:///my_map" true
```

## 使用 ros2 service call 调用服务

服务类型：`test_srv/srv/Test`，请求字段：`map_url` (string)、`command` (bool)。

```bash
# 默认：map_url='file:///default_map', command=true
ros2 service call /test_service test_srv/srv/Test "{map_url: 'file:///default_map', command: true}"

# 自定义
ros2 service call /test_service test_srv/srv/Test "{map_url: 'file:///my_map', command: false}"
```

或使用包内脚本（同上参数）：

```bash
ros2 run test_srv call_test_service.sh
ros2 run test_srv call_test_service.sh "file:///my_map" true
```

## test.srv 定义

- **Request**: `string map_url`, `bool command`
- **Response**: `bool result`

服务名：`/test_service`。
