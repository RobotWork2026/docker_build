#!/bin/bash
# 使用 ros2 service call 调用 /test_service（test_srv/srv/Test）
# 用法: call_test_service.sh [map_url] [command]
#   map_url  默认 "file:///default_map"
#   command 默认 true，可选 true/false/1/0

MAP_URL="${1:-file:///default_map}"
CMD="${2:-true}"
if [[ "$CMD" == "0" || "$CMD" == "false" ]]; then
  CMD="false"
else
  CMD="true"
fi

ros2 service call /test_service test_srv/srv/Test "{map_url: '${MAP_URL}', command: ${CMD}}"
