#!/usr/bin/env python3

import sys
import rclpy
from rclpy.node import Node
from test_srv.srv import Test


class TestServiceClient(Node):
    def __init__(self):
        super().__init__('test_service_client')
        self.client = self.create_client(Test, '/test_service')
        self.get_logger().info('Test service client created, waiting for service...')

    def call_service(self, map_url: str, command: bool):
        request = Test.Request()
        request.map_url = map_url
        request.command = command

        if not self.client.wait_for_service(timeout_sec=5.0):
            self.get_logger().error('Service /test_service not available')
            return None

        future = self.client.call_async(request)
        rclpy.spin_until_future_complete(self, future, timeout_sec=10.0)

        if future.result() is not None:
            return future.result().result
        self.get_logger().error('Service call failed')
        return None


def main(args=None):
    rclpy.init(args=args)
    node = TestServiceClient()

    map_url = 'file:///default_map'
    command = True
    if len(sys.argv) >= 2:
        map_url = sys.argv[1]
    if len(sys.argv) >= 3:
        command = sys.argv[2].lower() in ('true', '1', 'yes')

    node.get_logger().info(f'Calling service: map_url="{map_url}", command={command}')
    result = node.call_service(map_url, command)
    if result is not None:
        node.get_logger().info(f'Service returned result: {result}')

    node.destroy_node()
    rclpy.shutdown()
    sys.exit(0 if result is not None else 1)


if __name__ == '__main__':
    main()
