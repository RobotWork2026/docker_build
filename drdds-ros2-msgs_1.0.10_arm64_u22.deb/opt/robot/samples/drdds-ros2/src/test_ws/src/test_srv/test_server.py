#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from test_srv.srv import Test


class TestServiceServer(Node):
    def __init__(self):
        super().__init__('test_service_server')
        self.srv = self.create_service(
            Test,
            '/test_service',
            self.handle_request,
        )
        self.get_logger().info('Test service server ready on /test_service')

    def handle_request(self, request, response):
        self.get_logger().info(
            f'Received: map_url="{request.map_url}", command={request.command}'
        )
        response.result = request.command
        self.get_logger().info(f'Returning result: {response.result}')
        return response


def main(args=None):
    rclpy.init(args=args)
    node = TestServiceServer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
