// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from amap_nav_msgs:srv/PlanPathOffline.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__TRAITS_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "amap_nav_msgs/srv/detail/plan_path_offline__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'goal_point'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace amap_nav_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const PlanPathOffline_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: path_id
  {
    out << "path_id: ";
    rosidl_generator_traits::value_to_yaml(msg.path_id, out);
    out << ", ";
  }

  // member: goal_point
  {
    out << "goal_point: ";
    to_flow_style_yaml(msg.goal_point, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const PlanPathOffline_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: path_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "path_id: ";
    rosidl_generator_traits::value_to_yaml(msg.path_id, out);
    out << "\n";
  }

  // member: goal_point
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "goal_point:\n";
    to_block_style_yaml(msg.goal_point, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const PlanPathOffline_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace amap_nav_msgs

namespace rosidl_generator_traits
{

[[deprecated("use amap_nav_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const amap_nav_msgs::srv::PlanPathOffline_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  amap_nav_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use amap_nav_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const amap_nav_msgs::srv::PlanPathOffline_Request & msg)
{
  return amap_nav_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<amap_nav_msgs::srv::PlanPathOffline_Request>()
{
  return "amap_nav_msgs::srv::PlanPathOffline_Request";
}

template<>
inline const char * name<amap_nav_msgs::srv::PlanPathOffline_Request>()
{
  return "amap_nav_msgs/srv/PlanPathOffline_Request";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::PlanPathOffline_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::srv::PlanPathOffline_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::srv::PlanPathOffline_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'planned_path'
// already included above
// #include "geometry_msgs/msg/detail/point__traits.hpp"

namespace amap_nav_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const PlanPathOffline_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: planned_path
  {
    if (msg.planned_path.size() == 0) {
      out << "planned_path: []";
    } else {
      out << "planned_path: [";
      size_t pending_items = msg.planned_path.size();
      for (auto item : msg.planned_path) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const PlanPathOffline_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: planned_path
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.planned_path.size() == 0) {
      out << "planned_path: []\n";
    } else {
      out << "planned_path:\n";
      for (auto item : msg.planned_path) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const PlanPathOffline_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace amap_nav_msgs

namespace rosidl_generator_traits
{

[[deprecated("use amap_nav_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const amap_nav_msgs::srv::PlanPathOffline_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  amap_nav_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use amap_nav_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const amap_nav_msgs::srv::PlanPathOffline_Response & msg)
{
  return amap_nav_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<amap_nav_msgs::srv::PlanPathOffline_Response>()
{
  return "amap_nav_msgs::srv::PlanPathOffline_Response";
}

template<>
inline const char * name<amap_nav_msgs::srv::PlanPathOffline_Response>()
{
  return "amap_nav_msgs/srv/PlanPathOffline_Response";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::PlanPathOffline_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::srv::PlanPathOffline_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::srv::PlanPathOffline_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<amap_nav_msgs::srv::PlanPathOffline>()
{
  return "amap_nav_msgs::srv::PlanPathOffline";
}

template<>
inline const char * name<amap_nav_msgs::srv::PlanPathOffline>()
{
  return "amap_nav_msgs/srv/PlanPathOffline";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::PlanPathOffline>
  : std::integral_constant<
    bool,
    has_fixed_size<amap_nav_msgs::srv::PlanPathOffline_Request>::value &&
    has_fixed_size<amap_nav_msgs::srv::PlanPathOffline_Response>::value
  >
{
};

template<>
struct has_bounded_size<amap_nav_msgs::srv::PlanPathOffline>
  : std::integral_constant<
    bool,
    has_bounded_size<amap_nav_msgs::srv::PlanPathOffline_Request>::value &&
    has_bounded_size<amap_nav_msgs::srv::PlanPathOffline_Response>::value
  >
{
};

template<>
struct is_service<amap_nav_msgs::srv::PlanPathOffline>
  : std::true_type
{
};

template<>
struct is_service_request<amap_nav_msgs::srv::PlanPathOffline_Request>
  : std::true_type
{
};

template<>
struct is_service_response<amap_nav_msgs::srv::PlanPathOffline_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__TRAITS_HPP_
