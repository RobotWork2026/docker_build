// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from amap_nav_msgs:srv/StartOnlineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__BUILDER_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "amap_nav_msgs/srv/detail/start_online_navigation__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace amap_nav_msgs
{

namespace srv
{

namespace builder
{

class Init_StartOnlineNavigation_Request_amap_payload_json
{
public:
  explicit Init_StartOnlineNavigation_Request_amap_payload_json(::amap_nav_msgs::srv::StartOnlineNavigation_Request & msg)
  : msg_(msg)
  {}
  ::amap_nav_msgs::srv::StartOnlineNavigation_Request amap_payload_json(::amap_nav_msgs::srv::StartOnlineNavigation_Request::_amap_payload_json_type arg)
  {
    msg_.amap_payload_json = std::move(arg);
    return std::move(msg_);
  }

private:
  ::amap_nav_msgs::srv::StartOnlineNavigation_Request msg_;
};

class Init_StartOnlineNavigation_Request_header
{
public:
  Init_StartOnlineNavigation_Request_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_StartOnlineNavigation_Request_amap_payload_json header(::amap_nav_msgs::srv::StartOnlineNavigation_Request::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_StartOnlineNavigation_Request_amap_payload_json(msg_);
  }

private:
  ::amap_nav_msgs::srv::StartOnlineNavigation_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::amap_nav_msgs::srv::StartOnlineNavigation_Request>()
{
  return amap_nav_msgs::srv::builder::Init_StartOnlineNavigation_Request_header();
}

}  // namespace amap_nav_msgs


namespace amap_nav_msgs
{

namespace srv
{

namespace builder
{

class Init_StartOnlineNavigation_Response_accepted
{
public:
  Init_StartOnlineNavigation_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::amap_nav_msgs::srv::StartOnlineNavigation_Response accepted(::amap_nav_msgs::srv::StartOnlineNavigation_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return std::move(msg_);
  }

private:
  ::amap_nav_msgs::srv::StartOnlineNavigation_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::amap_nav_msgs::srv::StartOnlineNavigation_Response>()
{
  return amap_nav_msgs::srv::builder::Init_StartOnlineNavigation_Response_accepted();
}

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__BUILDER_HPP_
