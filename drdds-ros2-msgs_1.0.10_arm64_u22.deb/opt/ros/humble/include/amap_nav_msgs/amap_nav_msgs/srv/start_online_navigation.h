// generated from rosidl_generator_c/resource/idl.h.em
// with input from amap_nav_msgs:srv/StartOnlineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__START_ONLINE_NAVIGATION_H_
#define AMAP_NAV_MSGS__SRV__START_ONLINE_NAVIGATION_H_

#include "amap_nav_msgs/srv/detail/start_online_navigation__struct.h"
#include "amap_nav_msgs/srv/detail/start_online_navigation__functions.h"
#include "amap_nav_msgs/srv/detail/start_online_navigation__type_support.h"

#endif  // AMAP_NAV_MSGS__SRV__START_ONLINE_NAVIGATION_H_
