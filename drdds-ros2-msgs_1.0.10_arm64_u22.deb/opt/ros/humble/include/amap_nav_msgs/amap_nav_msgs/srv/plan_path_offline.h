// generated from rosidl_generator_c/resource/idl.h.em
// with input from amap_nav_msgs:srv/PlanPathOffline.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__PLAN_PATH_OFFLINE_H_
#define AMAP_NAV_MSGS__SRV__PLAN_PATH_OFFLINE_H_

#include "amap_nav_msgs/srv/detail/plan_path_offline__struct.h"
#include "amap_nav_msgs/srv/detail/plan_path_offline__functions.h"
#include "amap_nav_msgs/srv/detail/plan_path_offline__type_support.h"

#endif  // AMAP_NAV_MSGS__SRV__PLAN_PATH_OFFLINE_H_
