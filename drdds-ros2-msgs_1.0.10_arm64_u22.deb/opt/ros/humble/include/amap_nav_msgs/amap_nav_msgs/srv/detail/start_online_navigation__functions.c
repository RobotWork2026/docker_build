// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from amap_nav_msgs:srv/StartOnlineNavigation.idl
// generated code does not contain a copyright notice
#include "amap_nav_msgs/srv/detail/start_online_navigation__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `amap_payload_json`
#include "rosidl_runtime_c/string_functions.h"

bool
amap_nav_msgs__srv__StartOnlineNavigation_Request__init(amap_nav_msgs__srv__StartOnlineNavigation_Request * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    amap_nav_msgs__srv__StartOnlineNavigation_Request__fini(msg);
    return false;
  }
  // amap_payload_json
  if (!rosidl_runtime_c__String__init(&msg->amap_payload_json)) {
    amap_nav_msgs__srv__StartOnlineNavigation_Request__fini(msg);
    return false;
  }
  return true;
}

void
amap_nav_msgs__srv__StartOnlineNavigation_Request__fini(amap_nav_msgs__srv__StartOnlineNavigation_Request * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // amap_payload_json
  rosidl_runtime_c__String__fini(&msg->amap_payload_json);
}

bool
amap_nav_msgs__srv__StartOnlineNavigation_Request__are_equal(const amap_nav_msgs__srv__StartOnlineNavigation_Request * lhs, const amap_nav_msgs__srv__StartOnlineNavigation_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // amap_payload_json
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->amap_payload_json), &(rhs->amap_payload_json)))
  {
    return false;
  }
  return true;
}

bool
amap_nav_msgs__srv__StartOnlineNavigation_Request__copy(
  const amap_nav_msgs__srv__StartOnlineNavigation_Request * input,
  amap_nav_msgs__srv__StartOnlineNavigation_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // amap_payload_json
  if (!rosidl_runtime_c__String__copy(
      &(input->amap_payload_json), &(output->amap_payload_json)))
  {
    return false;
  }
  return true;
}

amap_nav_msgs__srv__StartOnlineNavigation_Request *
amap_nav_msgs__srv__StartOnlineNavigation_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOnlineNavigation_Request * msg = (amap_nav_msgs__srv__StartOnlineNavigation_Request *)allocator.allocate(sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Request));
  bool success = amap_nav_msgs__srv__StartOnlineNavigation_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
amap_nav_msgs__srv__StartOnlineNavigation_Request__destroy(amap_nav_msgs__srv__StartOnlineNavigation_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    amap_nav_msgs__srv__StartOnlineNavigation_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence__init(amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOnlineNavigation_Request * data = NULL;

  if (size) {
    data = (amap_nav_msgs__srv__StartOnlineNavigation_Request *)allocator.zero_allocate(size, sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = amap_nav_msgs__srv__StartOnlineNavigation_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        amap_nav_msgs__srv__StartOnlineNavigation_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence__fini(amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      amap_nav_msgs__srv__StartOnlineNavigation_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence *
amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence * array = (amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence *)allocator.allocate(sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence__destroy(amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence__are_equal(const amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence * lhs, const amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!amap_nav_msgs__srv__StartOnlineNavigation_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence__copy(
  const amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence * input,
  amap_nav_msgs__srv__StartOnlineNavigation_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    amap_nav_msgs__srv__StartOnlineNavigation_Request * data =
      (amap_nav_msgs__srv__StartOnlineNavigation_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!amap_nav_msgs__srv__StartOnlineNavigation_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          amap_nav_msgs__srv__StartOnlineNavigation_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!amap_nav_msgs__srv__StartOnlineNavigation_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


bool
amap_nav_msgs__srv__StartOnlineNavigation_Response__init(amap_nav_msgs__srv__StartOnlineNavigation_Response * msg)
{
  if (!msg) {
    return false;
  }
  // accepted
  return true;
}

void
amap_nav_msgs__srv__StartOnlineNavigation_Response__fini(amap_nav_msgs__srv__StartOnlineNavigation_Response * msg)
{
  if (!msg) {
    return;
  }
  // accepted
}

bool
amap_nav_msgs__srv__StartOnlineNavigation_Response__are_equal(const amap_nav_msgs__srv__StartOnlineNavigation_Response * lhs, const amap_nav_msgs__srv__StartOnlineNavigation_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // accepted
  if (lhs->accepted != rhs->accepted) {
    return false;
  }
  return true;
}

bool
amap_nav_msgs__srv__StartOnlineNavigation_Response__copy(
  const amap_nav_msgs__srv__StartOnlineNavigation_Response * input,
  amap_nav_msgs__srv__StartOnlineNavigation_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // accepted
  output->accepted = input->accepted;
  return true;
}

amap_nav_msgs__srv__StartOnlineNavigation_Response *
amap_nav_msgs__srv__StartOnlineNavigation_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOnlineNavigation_Response * msg = (amap_nav_msgs__srv__StartOnlineNavigation_Response *)allocator.allocate(sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Response));
  bool success = amap_nav_msgs__srv__StartOnlineNavigation_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
amap_nav_msgs__srv__StartOnlineNavigation_Response__destroy(amap_nav_msgs__srv__StartOnlineNavigation_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    amap_nav_msgs__srv__StartOnlineNavigation_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence__init(amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOnlineNavigation_Response * data = NULL;

  if (size) {
    data = (amap_nav_msgs__srv__StartOnlineNavigation_Response *)allocator.zero_allocate(size, sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = amap_nav_msgs__srv__StartOnlineNavigation_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        amap_nav_msgs__srv__StartOnlineNavigation_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence__fini(amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      amap_nav_msgs__srv__StartOnlineNavigation_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence *
amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence * array = (amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence *)allocator.allocate(sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence__destroy(amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence__are_equal(const amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence * lhs, const amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!amap_nav_msgs__srv__StartOnlineNavigation_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence__copy(
  const amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence * input,
  amap_nav_msgs__srv__StartOnlineNavigation_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(amap_nav_msgs__srv__StartOnlineNavigation_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    amap_nav_msgs__srv__StartOnlineNavigation_Response * data =
      (amap_nav_msgs__srv__StartOnlineNavigation_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!amap_nav_msgs__srv__StartOnlineNavigation_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          amap_nav_msgs__srv__StartOnlineNavigation_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!amap_nav_msgs__srv__StartOnlineNavigation_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
