﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from amap_nav_msgs:srv/StartOfflineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__STRUCT_H_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'destination'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/StartOfflineNavigation in the package amap_nav_msgs.
typedef struct amap_nav_msgs__srv__StartOfflineNavigation_Request
{
  /// 客户端发给导航节点的目的GCJ‑02坐标系下的经纬度（例如 "120.067489,30.327858"）
  rosidl_runtime_c__String destination;
} amap_nav_msgs__srv__StartOfflineNavigation_Request;

// Struct for a sequence of amap_nav_msgs__srv__StartOfflineNavigation_Request.
typedef struct amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence
{
  amap_nav_msgs__srv__StartOfflineNavigation_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'planned_path'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in srv/StartOfflineNavigation in the package amap_nav_msgs.
typedef struct amap_nav_msgs__srv__StartOfflineNavigation_Response
{
  /// 服务端是否接受并启动导航流程，若请求格式有误或没有默认终点，会返回 false
  bool accepted;
  /// 服务端规划出的GCJ-02路径（lon->x, lat->y），accepted为true时有效
  geometry_msgs__msg__Point__Sequence planned_path;
} amap_nav_msgs__srv__StartOfflineNavigation_Response;

// Struct for a sequence of amap_nav_msgs__srv__StartOfflineNavigation_Response.
typedef struct amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence
{
  amap_nav_msgs__srv__StartOfflineNavigation_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__STRUCT_H_
