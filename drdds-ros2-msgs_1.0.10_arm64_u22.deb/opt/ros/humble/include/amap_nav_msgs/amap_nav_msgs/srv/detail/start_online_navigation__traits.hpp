// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from amap_nav_msgs:srv/StartOnlineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__TRAITS_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "amap_nav_msgs/srv/detail/start_online_navigation__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace amap_nav_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const StartOnlineNavigation_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: amap_payload_json
  {
    out << "amap_payload_json: ";
    rosidl_generator_traits::value_to_yaml(msg.amap_payload_json, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const StartOnlineNavigation_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: amap_payload_json
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "amap_payload_json: ";
    rosidl_generator_traits::value_to_yaml(msg.amap_payload_json, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const StartOnlineNavigation_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace amap_nav_msgs

namespace rosidl_generator_traits
{

[[deprecated("use amap_nav_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const amap_nav_msgs::srv::StartOnlineNavigation_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  amap_nav_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use amap_nav_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const amap_nav_msgs::srv::StartOnlineNavigation_Request & msg)
{
  return amap_nav_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOnlineNavigation_Request>()
{
  return "amap_nav_msgs::srv::StartOnlineNavigation_Request";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOnlineNavigation_Request>()
{
  return "amap_nav_msgs/srv/StartOnlineNavigation_Request";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::srv::StartOnlineNavigation_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace amap_nav_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const StartOnlineNavigation_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: accepted
  {
    out << "accepted: ";
    rosidl_generator_traits::value_to_yaml(msg.accepted, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const StartOnlineNavigation_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: accepted
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accepted: ";
    rosidl_generator_traits::value_to_yaml(msg.accepted, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const StartOnlineNavigation_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace amap_nav_msgs

namespace rosidl_generator_traits
{

[[deprecated("use amap_nav_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const amap_nav_msgs::srv::StartOnlineNavigation_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  amap_nav_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use amap_nav_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const amap_nav_msgs::srv::StartOnlineNavigation_Response & msg)
{
  return amap_nav_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOnlineNavigation_Response>()
{
  return "amap_nav_msgs::srv::StartOnlineNavigation_Response";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOnlineNavigation_Response>()
{
  return "amap_nav_msgs/srv/StartOnlineNavigation_Response";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<amap_nav_msgs::srv::StartOnlineNavigation_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOnlineNavigation>()
{
  return "amap_nav_msgs::srv::StartOnlineNavigation";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOnlineNavigation>()
{
  return "amap_nav_msgs/srv/StartOnlineNavigation";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation>
  : std::integral_constant<
    bool,
    has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation_Request>::value &&
    has_fixed_size<amap_nav_msgs::srv::StartOnlineNavigation_Response>::value
  >
{
};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation>
  : std::integral_constant<
    bool,
    has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation_Request>::value &&
    has_bounded_size<amap_nav_msgs::srv::StartOnlineNavigation_Response>::value
  >
{
};

template<>
struct is_service<amap_nav_msgs::srv::StartOnlineNavigation>
  : std::true_type
{
};

template<>
struct is_service_request<amap_nav_msgs::srv::StartOnlineNavigation_Request>
  : std::true_type
{
};

template<>
struct is_service_response<amap_nav_msgs::srv::StartOnlineNavigation_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_ONLINE_NAVIGATION__TRAITS_HPP_
