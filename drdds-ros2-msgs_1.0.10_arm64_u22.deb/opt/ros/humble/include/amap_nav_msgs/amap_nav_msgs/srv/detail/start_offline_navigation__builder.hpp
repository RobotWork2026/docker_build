// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from amap_nav_msgs:srv/StartOfflineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__BUILDER_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "amap_nav_msgs/srv/detail/start_offline_navigation__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace amap_nav_msgs
{

namespace srv
{

namespace builder
{

class Init_StartOfflineNavigation_Request_destination
{
public:
  Init_StartOfflineNavigation_Request_destination()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::amap_nav_msgs::srv::StartOfflineNavigation_Request destination(::amap_nav_msgs::srv::StartOfflineNavigation_Request::_destination_type arg)
  {
    msg_.destination = std::move(arg);
    return std::move(msg_);
  }

private:
  ::amap_nav_msgs::srv::StartOfflineNavigation_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::amap_nav_msgs::srv::StartOfflineNavigation_Request>()
{
  return amap_nav_msgs::srv::builder::Init_StartOfflineNavigation_Request_destination();
}

}  // namespace amap_nav_msgs


namespace amap_nav_msgs
{

namespace srv
{

namespace builder
{

class Init_StartOfflineNavigation_Response_planned_path
{
public:
  explicit Init_StartOfflineNavigation_Response_planned_path(::amap_nav_msgs::srv::StartOfflineNavigation_Response & msg)
  : msg_(msg)
  {}
  ::amap_nav_msgs::srv::StartOfflineNavigation_Response planned_path(::amap_nav_msgs::srv::StartOfflineNavigation_Response::_planned_path_type arg)
  {
    msg_.planned_path = std::move(arg);
    return std::move(msg_);
  }

private:
  ::amap_nav_msgs::srv::StartOfflineNavigation_Response msg_;
};

class Init_StartOfflineNavigation_Response_accepted
{
public:
  Init_StartOfflineNavigation_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_StartOfflineNavigation_Response_planned_path accepted(::amap_nav_msgs::srv::StartOfflineNavigation_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return Init_StartOfflineNavigation_Response_planned_path(msg_);
  }

private:
  ::amap_nav_msgs::srv::StartOfflineNavigation_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::amap_nav_msgs::srv::StartOfflineNavigation_Response>()
{
  return amap_nav_msgs::srv::builder::Init_StartOfflineNavigation_Response_accepted();
}

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__BUILDER_HPP_
