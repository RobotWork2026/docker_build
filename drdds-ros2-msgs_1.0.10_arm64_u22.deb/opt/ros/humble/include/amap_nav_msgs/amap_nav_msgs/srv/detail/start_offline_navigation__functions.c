// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from amap_nav_msgs:srv/StartOfflineNavigation.idl
// generated code does not contain a copyright notice
#include "amap_nav_msgs/srv/detail/start_offline_navigation__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `destination`
#include "rosidl_runtime_c/string_functions.h"

bool
amap_nav_msgs__srv__StartOfflineNavigation_Request__init(amap_nav_msgs__srv__StartOfflineNavigation_Request * msg)
{
  if (!msg) {
    return false;
  }
  // destination
  if (!rosidl_runtime_c__String__init(&msg->destination)) {
    amap_nav_msgs__srv__StartOfflineNavigation_Request__fini(msg);
    return false;
  }
  return true;
}

void
amap_nav_msgs__srv__StartOfflineNavigation_Request__fini(amap_nav_msgs__srv__StartOfflineNavigation_Request * msg)
{
  if (!msg) {
    return;
  }
  // destination
  rosidl_runtime_c__String__fini(&msg->destination);
}

bool
amap_nav_msgs__srv__StartOfflineNavigation_Request__are_equal(const amap_nav_msgs__srv__StartOfflineNavigation_Request * lhs, const amap_nav_msgs__srv__StartOfflineNavigation_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // destination
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->destination), &(rhs->destination)))
  {
    return false;
  }
  return true;
}

bool
amap_nav_msgs__srv__StartOfflineNavigation_Request__copy(
  const amap_nav_msgs__srv__StartOfflineNavigation_Request * input,
  amap_nav_msgs__srv__StartOfflineNavigation_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // destination
  if (!rosidl_runtime_c__String__copy(
      &(input->destination), &(output->destination)))
  {
    return false;
  }
  return true;
}

amap_nav_msgs__srv__StartOfflineNavigation_Request *
amap_nav_msgs__srv__StartOfflineNavigation_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOfflineNavigation_Request * msg = (amap_nav_msgs__srv__StartOfflineNavigation_Request *)allocator.allocate(sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Request));
  bool success = amap_nav_msgs__srv__StartOfflineNavigation_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
amap_nav_msgs__srv__StartOfflineNavigation_Request__destroy(amap_nav_msgs__srv__StartOfflineNavigation_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    amap_nav_msgs__srv__StartOfflineNavigation_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence__init(amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOfflineNavigation_Request * data = NULL;

  if (size) {
    data = (amap_nav_msgs__srv__StartOfflineNavigation_Request *)allocator.zero_allocate(size, sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = amap_nav_msgs__srv__StartOfflineNavigation_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        amap_nav_msgs__srv__StartOfflineNavigation_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence__fini(amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      amap_nav_msgs__srv__StartOfflineNavigation_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence *
amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence * array = (amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence *)allocator.allocate(sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence__destroy(amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence__are_equal(const amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence * lhs, const amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!amap_nav_msgs__srv__StartOfflineNavigation_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence__copy(
  const amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence * input,
  amap_nav_msgs__srv__StartOfflineNavigation_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    amap_nav_msgs__srv__StartOfflineNavigation_Request * data =
      (amap_nav_msgs__srv__StartOfflineNavigation_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!amap_nav_msgs__srv__StartOfflineNavigation_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          amap_nav_msgs__srv__StartOfflineNavigation_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!amap_nav_msgs__srv__StartOfflineNavigation_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `planned_path`
#include "geometry_msgs/msg/detail/point__functions.h"

bool
amap_nav_msgs__srv__StartOfflineNavigation_Response__init(amap_nav_msgs__srv__StartOfflineNavigation_Response * msg)
{
  if (!msg) {
    return false;
  }
  // accepted
  // planned_path
  if (!geometry_msgs__msg__Point__Sequence__init(&msg->planned_path, 0)) {
    amap_nav_msgs__srv__StartOfflineNavigation_Response__fini(msg);
    return false;
  }
  return true;
}

void
amap_nav_msgs__srv__StartOfflineNavigation_Response__fini(amap_nav_msgs__srv__StartOfflineNavigation_Response * msg)
{
  if (!msg) {
    return;
  }
  // accepted
  // planned_path
  geometry_msgs__msg__Point__Sequence__fini(&msg->planned_path);
}

bool
amap_nav_msgs__srv__StartOfflineNavigation_Response__are_equal(const amap_nav_msgs__srv__StartOfflineNavigation_Response * lhs, const amap_nav_msgs__srv__StartOfflineNavigation_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // accepted
  if (lhs->accepted != rhs->accepted) {
    return false;
  }
  // planned_path
  if (!geometry_msgs__msg__Point__Sequence__are_equal(
      &(lhs->planned_path), &(rhs->planned_path)))
  {
    return false;
  }
  return true;
}

bool
amap_nav_msgs__srv__StartOfflineNavigation_Response__copy(
  const amap_nav_msgs__srv__StartOfflineNavigation_Response * input,
  amap_nav_msgs__srv__StartOfflineNavigation_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // accepted
  output->accepted = input->accepted;
  // planned_path
  if (!geometry_msgs__msg__Point__Sequence__copy(
      &(input->planned_path), &(output->planned_path)))
  {
    return false;
  }
  return true;
}

amap_nav_msgs__srv__StartOfflineNavigation_Response *
amap_nav_msgs__srv__StartOfflineNavigation_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOfflineNavigation_Response * msg = (amap_nav_msgs__srv__StartOfflineNavigation_Response *)allocator.allocate(sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Response));
  bool success = amap_nav_msgs__srv__StartOfflineNavigation_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
amap_nav_msgs__srv__StartOfflineNavigation_Response__destroy(amap_nav_msgs__srv__StartOfflineNavigation_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    amap_nav_msgs__srv__StartOfflineNavigation_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence__init(amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOfflineNavigation_Response * data = NULL;

  if (size) {
    data = (amap_nav_msgs__srv__StartOfflineNavigation_Response *)allocator.zero_allocate(size, sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = amap_nav_msgs__srv__StartOfflineNavigation_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        amap_nav_msgs__srv__StartOfflineNavigation_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence__fini(amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      amap_nav_msgs__srv__StartOfflineNavigation_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence *
amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence * array = (amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence *)allocator.allocate(sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence__destroy(amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence__are_equal(const amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence * lhs, const amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!amap_nav_msgs__srv__StartOfflineNavigation_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence__copy(
  const amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence * input,
  amap_nav_msgs__srv__StartOfflineNavigation_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(amap_nav_msgs__srv__StartOfflineNavigation_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    amap_nav_msgs__srv__StartOfflineNavigation_Response * data =
      (amap_nav_msgs__srv__StartOfflineNavigation_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!amap_nav_msgs__srv__StartOfflineNavigation_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          amap_nav_msgs__srv__StartOfflineNavigation_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!amap_nav_msgs__srv__StartOfflineNavigation_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
