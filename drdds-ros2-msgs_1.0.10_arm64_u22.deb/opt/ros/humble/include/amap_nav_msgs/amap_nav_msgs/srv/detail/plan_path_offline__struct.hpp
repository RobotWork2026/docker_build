// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from amap_nav_msgs:srv/PlanPathOffline.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__STRUCT_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'goal_point'
#include "geometry_msgs/msg/detail/point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__amap_nav_msgs__srv__PlanPathOffline_Request __attribute__((deprecated))
#else
# define DEPRECATED__amap_nav_msgs__srv__PlanPathOffline_Request __declspec(deprecated)
#endif

namespace amap_nav_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct PlanPathOffline_Request_
{
  using Type = PlanPathOffline_Request_<ContainerAllocator>;

  explicit PlanPathOffline_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    goal_point(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->path_id = "";
    }
  }

  explicit PlanPathOffline_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    path_id(_alloc),
    goal_point(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->path_id = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _path_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _path_id_type path_id;
  using _goal_point_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _goal_point_type goal_point;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__path_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->path_id = _arg;
    return *this;
  }
  Type & set__goal_point(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->goal_point = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__amap_nav_msgs__srv__PlanPathOffline_Request
    std::shared_ptr<amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__amap_nav_msgs__srv__PlanPathOffline_Request
    std::shared_ptr<amap_nav_msgs::srv::PlanPathOffline_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PlanPathOffline_Request_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->path_id != other.path_id) {
      return false;
    }
    if (this->goal_point != other.goal_point) {
      return false;
    }
    return true;
  }
  bool operator!=(const PlanPathOffline_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PlanPathOffline_Request_

// alias to use template instance with default allocator
using PlanPathOffline_Request =
  amap_nav_msgs::srv::PlanPathOffline_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace amap_nav_msgs


// Include directives for member types
// Member 'planned_path'
// already included above
// #include "geometry_msgs/msg/detail/point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__amap_nav_msgs__srv__PlanPathOffline_Response __attribute__((deprecated))
#else
# define DEPRECATED__amap_nav_msgs__srv__PlanPathOffline_Response __declspec(deprecated)
#endif

namespace amap_nav_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct PlanPathOffline_Response_
{
  using Type = PlanPathOffline_Response_<ContainerAllocator>;

  explicit PlanPathOffline_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
  }

  explicit PlanPathOffline_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_init;
    (void)_alloc;
  }

  // field types and members
  using _planned_path_type =
    std::vector<geometry_msgs::msg::Point_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<geometry_msgs::msg::Point_<ContainerAllocator>>>;
  _planned_path_type planned_path;

  // setters for named parameter idiom
  Type & set__planned_path(
    const std::vector<geometry_msgs::msg::Point_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<geometry_msgs::msg::Point_<ContainerAllocator>>> & _arg)
  {
    this->planned_path = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__amap_nav_msgs__srv__PlanPathOffline_Response
    std::shared_ptr<amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__amap_nav_msgs__srv__PlanPathOffline_Response
    std::shared_ptr<amap_nav_msgs::srv::PlanPathOffline_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PlanPathOffline_Response_ & other) const
  {
    if (this->planned_path != other.planned_path) {
      return false;
    }
    return true;
  }
  bool operator!=(const PlanPathOffline_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PlanPathOffline_Response_

// alias to use template instance with default allocator
using PlanPathOffline_Response =
  amap_nav_msgs::srv::PlanPathOffline_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace amap_nav_msgs

namespace amap_nav_msgs
{

namespace srv
{

struct PlanPathOffline
{
  using Request = amap_nav_msgs::srv::PlanPathOffline_Request;
  using Response = amap_nav_msgs::srv::PlanPathOffline_Response;
};

}  // namespace srv

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__PLAN_PATH_OFFLINE__STRUCT_HPP_
