// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from amap_nav_msgs:srv/StartOfflineNavigation.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__TRAITS_HPP_
#define AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "amap_nav_msgs/srv/detail/start_offline_navigation__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace amap_nav_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const StartOfflineNavigation_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: destination
  {
    out << "destination: ";
    rosidl_generator_traits::value_to_yaml(msg.destination, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const StartOfflineNavigation_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: destination
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "destination: ";
    rosidl_generator_traits::value_to_yaml(msg.destination, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const StartOfflineNavigation_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace amap_nav_msgs

namespace rosidl_generator_traits
{

[[deprecated("use amap_nav_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const amap_nav_msgs::srv::StartOfflineNavigation_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  amap_nav_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use amap_nav_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const amap_nav_msgs::srv::StartOfflineNavigation_Request & msg)
{
  return amap_nav_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOfflineNavigation_Request>()
{
  return "amap_nav_msgs::srv::StartOfflineNavigation_Request";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOfflineNavigation_Request>()
{
  return "amap_nav_msgs/srv/StartOfflineNavigation_Request";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOfflineNavigation_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOfflineNavigation_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::srv::StartOfflineNavigation_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

// Include directives for member types
// Member 'planned_path'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace amap_nav_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const StartOfflineNavigation_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: accepted
  {
    out << "accepted: ";
    rosidl_generator_traits::value_to_yaml(msg.accepted, out);
    out << ", ";
  }

  // member: planned_path
  {
    if (msg.planned_path.size() == 0) {
      out << "planned_path: []";
    } else {
      out << "planned_path: [";
      size_t pending_items = msg.planned_path.size();
      for (auto item : msg.planned_path) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const StartOfflineNavigation_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: accepted
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "accepted: ";
    rosidl_generator_traits::value_to_yaml(msg.accepted, out);
    out << "\n";
  }

  // member: planned_path
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.planned_path.size() == 0) {
      out << "planned_path: []\n";
    } else {
      out << "planned_path:\n";
      for (auto item : msg.planned_path) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const StartOfflineNavigation_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace amap_nav_msgs

namespace rosidl_generator_traits
{

[[deprecated("use amap_nav_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const amap_nav_msgs::srv::StartOfflineNavigation_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  amap_nav_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use amap_nav_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const amap_nav_msgs::srv::StartOfflineNavigation_Response & msg)
{
  return amap_nav_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOfflineNavigation_Response>()
{
  return "amap_nav_msgs::srv::StartOfflineNavigation_Response";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOfflineNavigation_Response>()
{
  return "amap_nav_msgs/srv/StartOfflineNavigation_Response";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOfflineNavigation_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOfflineNavigation_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::srv::StartOfflineNavigation_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<amap_nav_msgs::srv::StartOfflineNavigation>()
{
  return "amap_nav_msgs::srv::StartOfflineNavigation";
}

template<>
inline const char * name<amap_nav_msgs::srv::StartOfflineNavigation>()
{
  return "amap_nav_msgs/srv/StartOfflineNavigation";
}

template<>
struct has_fixed_size<amap_nav_msgs::srv::StartOfflineNavigation>
  : std::integral_constant<
    bool,
    has_fixed_size<amap_nav_msgs::srv::StartOfflineNavigation_Request>::value &&
    has_fixed_size<amap_nav_msgs::srv::StartOfflineNavigation_Response>::value
  >
{
};

template<>
struct has_bounded_size<amap_nav_msgs::srv::StartOfflineNavigation>
  : std::integral_constant<
    bool,
    has_bounded_size<amap_nav_msgs::srv::StartOfflineNavigation_Request>::value &&
    has_bounded_size<amap_nav_msgs::srv::StartOfflineNavigation_Response>::value
  >
{
};

template<>
struct is_service<amap_nav_msgs::srv::StartOfflineNavigation>
  : std::true_type
{
};

template<>
struct is_service_request<amap_nav_msgs::srv::StartOfflineNavigation_Request>
  : std::true_type
{
};

template<>
struct is_service_response<amap_nav_msgs::srv::StartOfflineNavigation_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // AMAP_NAV_MSGS__SRV__DETAIL__START_OFFLINE_NAVIGATION__TRAITS_HPP_
