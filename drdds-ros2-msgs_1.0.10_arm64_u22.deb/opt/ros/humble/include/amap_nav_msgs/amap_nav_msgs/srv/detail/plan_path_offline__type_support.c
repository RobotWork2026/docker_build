// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from amap_nav_msgs:srv/PlanPathOffline.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "amap_nav_msgs/srv/detail/plan_path_offline__rosidl_typesupport_introspection_c.h"
#include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "amap_nav_msgs/srv/detail/plan_path_offline__functions.h"
#include "amap_nav_msgs/srv/detail/plan_path_offline__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `path_id`
#include "rosidl_runtime_c/string_functions.h"
// Member `goal_point`
#include "geometry_msgs/msg/point.h"
// Member `goal_point`
#include "geometry_msgs/msg/detail/point__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  amap_nav_msgs__srv__PlanPathOffline_Request__init(message_memory);
}

void amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_fini_function(void * message_memory)
{
  amap_nav_msgs__srv__PlanPathOffline_Request__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_member_array[3] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__PlanPathOffline_Request, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "path_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__PlanPathOffline_Request, path_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "goal_point",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__PlanPathOffline_Request, goal_point),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_members = {
  "amap_nav_msgs__srv",  // message namespace
  "PlanPathOffline_Request",  // message name
  3,  // number of fields
  sizeof(amap_nav_msgs__srv__PlanPathOffline_Request),
  amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_member_array,  // message members
  amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_init_function,  // function to initialize message memory (memory has to be allocated)
  amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_type_support_handle = {
  0,
  &amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, PlanPathOffline_Request)() {
  amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Point)();
  if (!amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_type_support_handle.typesupport_identifier) {
    amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &amap_nav_msgs__srv__PlanPathOffline_Request__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

// already included above
// #include <stddef.h>
// already included above
// #include "amap_nav_msgs/srv/detail/plan_path_offline__rosidl_typesupport_introspection_c.h"
// already included above
// #include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "rosidl_typesupport_introspection_c/field_types.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
// already included above
// #include "rosidl_typesupport_introspection_c/message_introspection.h"
// already included above
// #include "amap_nav_msgs/srv/detail/plan_path_offline__functions.h"
// already included above
// #include "amap_nav_msgs/srv/detail/plan_path_offline__struct.h"


// Include directives for member types
// Member `planned_path`
// already included above
// #include "geometry_msgs/msg/point.h"
// Member `planned_path`
// already included above
// #include "geometry_msgs/msg/detail/point__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  amap_nav_msgs__srv__PlanPathOffline_Response__init(message_memory);
}

void amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_fini_function(void * message_memory)
{
  amap_nav_msgs__srv__PlanPathOffline_Response__fini(message_memory);
}

size_t amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__size_function__PlanPathOffline_Response__planned_path(
  const void * untyped_member)
{
  const geometry_msgs__msg__Point__Sequence * member =
    (const geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return member->size;
}

const void * amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__get_const_function__PlanPathOffline_Response__planned_path(
  const void * untyped_member, size_t index)
{
  const geometry_msgs__msg__Point__Sequence * member =
    (const geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return &member->data[index];
}

void * amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__get_function__PlanPathOffline_Response__planned_path(
  void * untyped_member, size_t index)
{
  geometry_msgs__msg__Point__Sequence * member =
    (geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return &member->data[index];
}

void amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__fetch_function__PlanPathOffline_Response__planned_path(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const geometry_msgs__msg__Point * item =
    ((const geometry_msgs__msg__Point *)
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__get_const_function__PlanPathOffline_Response__planned_path(untyped_member, index));
  geometry_msgs__msg__Point * value =
    (geometry_msgs__msg__Point *)(untyped_value);
  *value = *item;
}

void amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__assign_function__PlanPathOffline_Response__planned_path(
  void * untyped_member, size_t index, const void * untyped_value)
{
  geometry_msgs__msg__Point * item =
    ((geometry_msgs__msg__Point *)
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__get_function__PlanPathOffline_Response__planned_path(untyped_member, index));
  const geometry_msgs__msg__Point * value =
    (const geometry_msgs__msg__Point *)(untyped_value);
  *item = *value;
}

bool amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__resize_function__PlanPathOffline_Response__planned_path(
  void * untyped_member, size_t size)
{
  geometry_msgs__msg__Point__Sequence * member =
    (geometry_msgs__msg__Point__Sequence *)(untyped_member);
  geometry_msgs__msg__Point__Sequence__fini(member);
  return geometry_msgs__msg__Point__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_member_array[1] = {
  {
    "planned_path",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(amap_nav_msgs__srv__PlanPathOffline_Response, planned_path),  // bytes offset in struct
    NULL,  // default value
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__size_function__PlanPathOffline_Response__planned_path,  // size() function pointer
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__get_const_function__PlanPathOffline_Response__planned_path,  // get_const(index) function pointer
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__get_function__PlanPathOffline_Response__planned_path,  // get(index) function pointer
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__fetch_function__PlanPathOffline_Response__planned_path,  // fetch(index, &value) function pointer
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__assign_function__PlanPathOffline_Response__planned_path,  // assign(index, value) function pointer
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__resize_function__PlanPathOffline_Response__planned_path  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_members = {
  "amap_nav_msgs__srv",  // message namespace
  "PlanPathOffline_Response",  // message name
  1,  // number of fields
  sizeof(amap_nav_msgs__srv__PlanPathOffline_Response),
  amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_member_array,  // message members
  amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_init_function,  // function to initialize message memory (memory has to be allocated)
  amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_type_support_handle = {
  0,
  &amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, PlanPathOffline_Response)() {
  amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Point)();
  if (!amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_type_support_handle.typesupport_identifier) {
    amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &amap_nav_msgs__srv__PlanPathOffline_Response__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif

#include "rosidl_runtime_c/service_type_support_struct.h"
// already included above
// #include "amap_nav_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
// already included above
// #include "amap_nav_msgs/srv/detail/plan_path_offline__rosidl_typesupport_introspection_c.h"
// already included above
// #include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/service_introspection.h"

// this is intentionally not const to allow initialization later to prevent an initialization race
static rosidl_typesupport_introspection_c__ServiceMembers amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_service_members = {
  "amap_nav_msgs__srv",  // service namespace
  "PlanPathOffline",  // service name
  // these two fields are initialized below on the first access
  NULL,  // request message
  // amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_Request_message_type_support_handle,
  NULL  // response message
  // amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_Response_message_type_support_handle
};

static rosidl_service_type_support_t amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_service_type_support_handle = {
  0,
  &amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_service_members,
  get_service_typesupport_handle_function,
};

// Forward declaration of request/response type support functions
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, PlanPathOffline_Request)();

const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, PlanPathOffline_Response)();

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_amap_nav_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, PlanPathOffline)() {
  if (!amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_service_type_support_handle.typesupport_identifier) {
    amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_service_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  rosidl_typesupport_introspection_c__ServiceMembers * service_members =
    (rosidl_typesupport_introspection_c__ServiceMembers *)amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_service_type_support_handle.data;

  if (!service_members->request_members_) {
    service_members->request_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, PlanPathOffline_Request)()->data;
  }
  if (!service_members->response_members_) {
    service_members->response_members_ =
      (const rosidl_typesupport_introspection_c__MessageMembers *)
      ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, amap_nav_msgs, srv, PlanPathOffline_Response)()->data;
  }

  return &amap_nav_msgs__srv__detail__plan_path_offline__rosidl_typesupport_introspection_c__PlanPathOffline_service_type_support_handle;
}
