// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from amap_nav_msgs:msg/AMapNavState.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__BUILDER_HPP_
#define AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "amap_nav_msgs/msg/detail/a_map_nav_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace amap_nav_msgs
{

namespace msg
{

namespace builder
{

class Init_AMapNavState_destination_text
{
public:
  explicit Init_AMapNavState_destination_text(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  ::amap_nav_msgs::msg::AMapNavState destination_text(::amap_nav_msgs::msg::AMapNavState::_destination_text_type arg)
  {
    msg_.destination_text = std::move(arg);
    return std::move(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_takeover_action
{
public:
  explicit Init_AMapNavState_takeover_action(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_destination_text takeover_action(::amap_nav_msgs::msg::AMapNavState::_takeover_action_type arg)
  {
    msg_.takeover_action = std::move(arg);
    return Init_AMapNavState_destination_text(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_need_takeover
{
public:
  explicit Init_AMapNavState_need_takeover(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_takeover_action need_takeover(::amap_nav_msgs::msg::AMapNavState::_need_takeover_type arg)
  {
    msg_.need_takeover = std::move(arg);
    return Init_AMapNavState_takeover_action(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_route_available
{
public:
  explicit Init_AMapNavState_route_available(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_need_takeover route_available(::amap_nav_msgs::msg::AMapNavState::_route_available_type arg)
  {
    msg_.route_available = std::move(arg);
    return Init_AMapNavState_need_takeover(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_arrival_announced
{
public:
  explicit Init_AMapNavState_arrival_announced(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_route_available arrival_announced(::amap_nav_msgs::msg::AMapNavState::_arrival_announced_type arg)
  {
    msg_.arrival_announced = std::move(arg);
    return Init_AMapNavState_route_available(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_pending_plan
{
public:
  explicit Init_AMapNavState_pending_plan(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_arrival_announced pending_plan(::amap_nav_msgs::msg::AMapNavState::_pending_plan_type arg)
  {
    msg_.pending_plan = std::move(arg);
    return Init_AMapNavState_arrival_announced(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_navigation_active
{
public:
  explicit Init_AMapNavState_navigation_active(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_pending_plan navigation_active(::amap_nav_msgs::msg::AMapNavState::_navigation_active_type arg)
  {
    msg_.navigation_active = std::move(arg);
    return Init_AMapNavState_pending_plan(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_position_valid
{
public:
  explicit Init_AMapNavState_position_valid(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_navigation_active position_valid(::amap_nav_msgs::msg::AMapNavState::_position_valid_type arg)
  {
    msg_.position_valid = std::move(arg);
    return Init_AMapNavState_navigation_active(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_distance_to_destination_m
{
public:
  explicit Init_AMapNavState_distance_to_destination_m(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_position_valid distance_to_destination_m(::amap_nav_msgs::msg::AMapNavState::_distance_to_destination_m_type arg)
  {
    msg_.distance_to_destination_m = std::move(arg);
    return Init_AMapNavState_position_valid(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_target_heading
{
public:
  explicit Init_AMapNavState_target_heading(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_distance_to_destination_m target_heading(::amap_nav_msgs::msg::AMapNavState::_target_heading_type arg)
  {
    msg_.target_heading = std::move(arg);
    return Init_AMapNavState_distance_to_destination_m(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_yaw_deg
{
public:
  explicit Init_AMapNavState_yaw_deg(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_target_heading yaw_deg(::amap_nav_msgs::msg::AMapNavState::_yaw_deg_type arg)
  {
    msg_.yaw_deg = std::move(arg);
    return Init_AMapNavState_target_heading(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_latitude
{
public:
  explicit Init_AMapNavState_latitude(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_yaw_deg latitude(::amap_nav_msgs::msg::AMapNavState::_latitude_type arg)
  {
    msg_.latitude = std::move(arg);
    return Init_AMapNavState_yaw_deg(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_longitude
{
public:
  explicit Init_AMapNavState_longitude(::amap_nav_msgs::msg::AMapNavState & msg)
  : msg_(msg)
  {}
  Init_AMapNavState_latitude longitude(::amap_nav_msgs::msg::AMapNavState::_longitude_type arg)
  {
    msg_.longitude = std::move(arg);
    return Init_AMapNavState_latitude(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

class Init_AMapNavState_header
{
public:
  Init_AMapNavState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AMapNavState_longitude header(::amap_nav_msgs::msg::AMapNavState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_AMapNavState_longitude(msg_);
  }

private:
  ::amap_nav_msgs::msg::AMapNavState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::amap_nav_msgs::msg::AMapNavState>()
{
  return amap_nav_msgs::msg::builder::Init_AMapNavState_header();
}

}  // namespace amap_nav_msgs

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__BUILDER_HPP_
