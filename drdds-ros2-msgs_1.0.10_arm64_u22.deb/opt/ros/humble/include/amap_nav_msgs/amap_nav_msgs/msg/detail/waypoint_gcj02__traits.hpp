// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__TRAITS_HPP_
#define AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "amap_nav_msgs/msg/detail/waypoint_gcj02__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace amap_nav_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const WaypointGCJ02 & msg,
  std::ostream & out)
{
  out << "{";
  // member: longitude
  {
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << ", ";
  }

  // member: latitude
  {
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << ", ";
  }

  // member: altitude
  {
    out << "altitude: ";
    rosidl_generator_traits::value_to_yaml(msg.altitude, out);
    out << ", ";
  }

  // member: label
  {
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const WaypointGCJ02 & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: longitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << "\n";
  }

  // member: latitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << "\n";
  }

  // member: altitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "altitude: ";
    rosidl_generator_traits::value_to_yaml(msg.altitude, out);
    out << "\n";
  }

  // member: label
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const WaypointGCJ02 & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace amap_nav_msgs

namespace rosidl_generator_traits
{

[[deprecated("use amap_nav_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const amap_nav_msgs::msg::WaypointGCJ02 & msg,
  std::ostream & out, size_t indentation = 0)
{
  amap_nav_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use amap_nav_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const amap_nav_msgs::msg::WaypointGCJ02 & msg)
{
  return amap_nav_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<amap_nav_msgs::msg::WaypointGCJ02>()
{
  return "amap_nav_msgs::msg::WaypointGCJ02";
}

template<>
inline const char * name<amap_nav_msgs::msg::WaypointGCJ02>()
{
  return "amap_nav_msgs/msg/WaypointGCJ02";
}

template<>
struct has_fixed_size<amap_nav_msgs::msg::WaypointGCJ02>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::msg::WaypointGCJ02>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::msg::WaypointGCJ02>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__WAYPOINT_GCJ02__TRAITS_HPP_
