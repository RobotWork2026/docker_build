// generated from rosidl_generator_c/resource/idl.h.em
// with input from amap_nav_msgs:msg/AMapNavState.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__A_MAP_NAV_STATE_H_
#define AMAP_NAV_MSGS__MSG__A_MAP_NAV_STATE_H_

#include "amap_nav_msgs/msg/detail/a_map_nav_state__struct.h"
#include "amap_nav_msgs/msg/detail/a_map_nav_state__functions.h"
#include "amap_nav_msgs/msg/detail/a_map_nav_state__type_support.h"

#endif  // AMAP_NAV_MSGS__MSG__A_MAP_NAV_STATE_H_
