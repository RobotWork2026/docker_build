// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from amap_nav_msgs:msg/AMapNavState.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__TRAITS_HPP_
#define AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "amap_nav_msgs/msg/detail/a_map_nav_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace amap_nav_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const AMapNavState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: longitude
  {
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << ", ";
  }

  // member: latitude
  {
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << ", ";
  }

  // member: yaw_deg
  {
    out << "yaw_deg: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw_deg, out);
    out << ", ";
  }

  // member: target_heading
  {
    out << "target_heading: ";
    rosidl_generator_traits::value_to_yaml(msg.target_heading, out);
    out << ", ";
  }

  // member: distance_to_destination_m
  {
    out << "distance_to_destination_m: ";
    rosidl_generator_traits::value_to_yaml(msg.distance_to_destination_m, out);
    out << ", ";
  }

  // member: position_valid
  {
    out << "position_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.position_valid, out);
    out << ", ";
  }

  // member: navigation_active
  {
    out << "navigation_active: ";
    rosidl_generator_traits::value_to_yaml(msg.navigation_active, out);
    out << ", ";
  }

  // member: pending_plan
  {
    out << "pending_plan: ";
    rosidl_generator_traits::value_to_yaml(msg.pending_plan, out);
    out << ", ";
  }

  // member: arrival_announced
  {
    out << "arrival_announced: ";
    rosidl_generator_traits::value_to_yaml(msg.arrival_announced, out);
    out << ", ";
  }

  // member: route_available
  {
    out << "route_available: ";
    rosidl_generator_traits::value_to_yaml(msg.route_available, out);
    out << ", ";
  }

  // member: need_takeover
  {
    out << "need_takeover: ";
    rosidl_generator_traits::value_to_yaml(msg.need_takeover, out);
    out << ", ";
  }

  // member: takeover_action
  {
    out << "takeover_action: ";
    rosidl_generator_traits::value_to_yaml(msg.takeover_action, out);
    out << ", ";
  }

  // member: destination_text
  {
    out << "destination_text: ";
    rosidl_generator_traits::value_to_yaml(msg.destination_text, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AMapNavState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: longitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << "\n";
  }

  // member: latitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << "\n";
  }

  // member: yaw_deg
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "yaw_deg: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw_deg, out);
    out << "\n";
  }

  // member: target_heading
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_heading: ";
    rosidl_generator_traits::value_to_yaml(msg.target_heading, out);
    out << "\n";
  }

  // member: distance_to_destination_m
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "distance_to_destination_m: ";
    rosidl_generator_traits::value_to_yaml(msg.distance_to_destination_m, out);
    out << "\n";
  }

  // member: position_valid
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_valid: ";
    rosidl_generator_traits::value_to_yaml(msg.position_valid, out);
    out << "\n";
  }

  // member: navigation_active
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "navigation_active: ";
    rosidl_generator_traits::value_to_yaml(msg.navigation_active, out);
    out << "\n";
  }

  // member: pending_plan
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pending_plan: ";
    rosidl_generator_traits::value_to_yaml(msg.pending_plan, out);
    out << "\n";
  }

  // member: arrival_announced
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "arrival_announced: ";
    rosidl_generator_traits::value_to_yaml(msg.arrival_announced, out);
    out << "\n";
  }

  // member: route_available
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "route_available: ";
    rosidl_generator_traits::value_to_yaml(msg.route_available, out);
    out << "\n";
  }

  // member: need_takeover
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "need_takeover: ";
    rosidl_generator_traits::value_to_yaml(msg.need_takeover, out);
    out << "\n";
  }

  // member: takeover_action
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "takeover_action: ";
    rosidl_generator_traits::value_to_yaml(msg.takeover_action, out);
    out << "\n";
  }

  // member: destination_text
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "destination_text: ";
    rosidl_generator_traits::value_to_yaml(msg.destination_text, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AMapNavState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace amap_nav_msgs

namespace rosidl_generator_traits
{

[[deprecated("use amap_nav_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const amap_nav_msgs::msg::AMapNavState & msg,
  std::ostream & out, size_t indentation = 0)
{
  amap_nav_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use amap_nav_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const amap_nav_msgs::msg::AMapNavState & msg)
{
  return amap_nav_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<amap_nav_msgs::msg::AMapNavState>()
{
  return "amap_nav_msgs::msg::AMapNavState";
}

template<>
inline const char * name<amap_nav_msgs::msg::AMapNavState>()
{
  return "amap_nav_msgs/msg/AMapNavState";
}

template<>
struct has_fixed_size<amap_nav_msgs::msg::AMapNavState>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<amap_nav_msgs::msg::AMapNavState>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<amap_nav_msgs::msg::AMapNavState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__TRAITS_HPP_
