﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from amap_nav_msgs:msg/AMapNavState.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_H_
#define AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'takeover_action'
// Member 'destination_text'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/AMapNavState in the package amap_nav_msgs.
typedef struct amap_nav_msgs__msg__AMapNavState
{
  std_msgs__msg__Header header;
  /// GCJ-02 longitude in degrees.
  double longitude;
  /// GCJ-02 latitude in degrees.
  double latitude;
  /// Heading in degrees using the ENU convention (east = 0°, counter-clockwise positive).
  double yaw_deg;
  /// Rotation in degrees needed to align the current heading to the local target
  /// (north = 0°, counter-clockwise positive). NaN if unavailable.
  double target_heading;
  /// Straight-line distance to the active destination in meters (NaN if unknown).
  double distance_to_destination_m;
  /// True when latitude/longitude carry a valid position.
  bool position_valid;
  /// True once a route has been received and actively tracked.
  bool navigation_active;
  /// True while the node is waiting for prerequisites before planning.
  bool pending_plan;
  /// True after arrival has been announced for the current destination.
  bool arrival_announced;
  /// True when at least one route is available in the tracker.
  bool route_available;
  /// True when a turn requires manual takeover from the VLM planner.
  bool need_takeover;
  /// Text description of the takeover action from the VLM planner (may be empty).
  rosidl_runtime_c__String takeover_action;
  /// Human-readable text for the active destination (may be empty).
  rosidl_runtime_c__String destination_text;
} amap_nav_msgs__msg__AMapNavState;

// Struct for a sequence of amap_nav_msgs__msg__AMapNavState.
typedef struct amap_nav_msgs__msg__AMapNavState__Sequence
{
  amap_nav_msgs__msg__AMapNavState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} amap_nav_msgs__msg__AMapNavState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__STRUCT_H_
