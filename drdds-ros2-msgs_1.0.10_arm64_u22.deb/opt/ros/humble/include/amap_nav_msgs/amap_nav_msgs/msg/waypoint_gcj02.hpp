// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__WAYPOINT_GCJ02_HPP_
#define AMAP_NAV_MSGS__MSG__WAYPOINT_GCJ02_HPP_

#include "amap_nav_msgs/msg/detail/waypoint_gcj02__struct.hpp"
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__builder.hpp"
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__traits.hpp"
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__type_support.hpp"

#endif  // AMAP_NAV_MSGS__MSG__WAYPOINT_GCJ02_HPP_
