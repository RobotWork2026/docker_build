// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from amap_nav_msgs:msg/AMapNavState.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__FUNCTIONS_H_
#define AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "amap_nav_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "amap_nav_msgs/msg/detail/a_map_nav_state__struct.h"

/// Initialize msg/AMapNavState message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * amap_nav_msgs__msg__AMapNavState
 * )) before or use
 * amap_nav_msgs__msg__AMapNavState__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
bool
amap_nav_msgs__msg__AMapNavState__init(amap_nav_msgs__msg__AMapNavState * msg);

/// Finalize msg/AMapNavState message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
void
amap_nav_msgs__msg__AMapNavState__fini(amap_nav_msgs__msg__AMapNavState * msg);

/// Create msg/AMapNavState message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * amap_nav_msgs__msg__AMapNavState__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
amap_nav_msgs__msg__AMapNavState *
amap_nav_msgs__msg__AMapNavState__create();

/// Destroy msg/AMapNavState message.
/**
 * It calls
 * amap_nav_msgs__msg__AMapNavState__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
void
amap_nav_msgs__msg__AMapNavState__destroy(amap_nav_msgs__msg__AMapNavState * msg);

/// Check for msg/AMapNavState message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
bool
amap_nav_msgs__msg__AMapNavState__are_equal(const amap_nav_msgs__msg__AMapNavState * lhs, const amap_nav_msgs__msg__AMapNavState * rhs);

/// Copy a msg/AMapNavState message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
bool
amap_nav_msgs__msg__AMapNavState__copy(
  const amap_nav_msgs__msg__AMapNavState * input,
  amap_nav_msgs__msg__AMapNavState * output);

/// Initialize array of msg/AMapNavState messages.
/**
 * It allocates the memory for the number of elements and calls
 * amap_nav_msgs__msg__AMapNavState__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
bool
amap_nav_msgs__msg__AMapNavState__Sequence__init(amap_nav_msgs__msg__AMapNavState__Sequence * array, size_t size);

/// Finalize array of msg/AMapNavState messages.
/**
 * It calls
 * amap_nav_msgs__msg__AMapNavState__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
void
amap_nav_msgs__msg__AMapNavState__Sequence__fini(amap_nav_msgs__msg__AMapNavState__Sequence * array);

/// Create array of msg/AMapNavState messages.
/**
 * It allocates the memory for the array and calls
 * amap_nav_msgs__msg__AMapNavState__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
amap_nav_msgs__msg__AMapNavState__Sequence *
amap_nav_msgs__msg__AMapNavState__Sequence__create(size_t size);

/// Destroy array of msg/AMapNavState messages.
/**
 * It calls
 * amap_nav_msgs__msg__AMapNavState__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
void
amap_nav_msgs__msg__AMapNavState__Sequence__destroy(amap_nav_msgs__msg__AMapNavState__Sequence * array);

/// Check for msg/AMapNavState message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
bool
amap_nav_msgs__msg__AMapNavState__Sequence__are_equal(const amap_nav_msgs__msg__AMapNavState__Sequence * lhs, const amap_nav_msgs__msg__AMapNavState__Sequence * rhs);

/// Copy an array of msg/AMapNavState messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_amap_nav_msgs
bool
amap_nav_msgs__msg__AMapNavState__Sequence__copy(
  const amap_nav_msgs__msg__AMapNavState__Sequence * input,
  amap_nav_msgs__msg__AMapNavState__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // AMAP_NAV_MSGS__MSG__DETAIL__A_MAP_NAV_STATE__FUNCTIONS_H_
