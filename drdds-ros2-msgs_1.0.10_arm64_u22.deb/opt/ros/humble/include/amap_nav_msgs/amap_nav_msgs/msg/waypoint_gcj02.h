// generated from rosidl_generator_c/resource/idl.h.em
// with input from amap_nav_msgs:msg/WaypointGCJ02.idl
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__WAYPOINT_GCJ02_H_
#define AMAP_NAV_MSGS__MSG__WAYPOINT_GCJ02_H_

#include "amap_nav_msgs/msg/detail/waypoint_gcj02__struct.h"
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__functions.h"
#include "amap_nav_msgs/msg/detail/waypoint_gcj02__type_support.h"

#endif  // AMAP_NAV_MSGS__MSG__WAYPOINT_GCJ02_H_
