// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AMAP_NAV_MSGS__MSG__A_MAP_NAV_STATE_HPP_
#define AMAP_NAV_MSGS__MSG__A_MAP_NAV_STATE_HPP_

#include "amap_nav_msgs/msg/detail/a_map_nav_state__struct.hpp"
#include "amap_nav_msgs/msg/detail/a_map_nav_state__builder.hpp"
#include "amap_nav_msgs/msg/detail/a_map_nav_state__traits.hpp"
#include "amap_nav_msgs/msg/detail/a_map_nav_state__type_support.hpp"

#endif  // AMAP_NAV_MSGS__MSG__A_MAP_NAV_STATE_HPP_
