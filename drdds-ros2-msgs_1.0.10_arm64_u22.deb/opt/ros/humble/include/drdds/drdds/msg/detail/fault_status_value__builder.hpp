// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/FaultStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/fault_status_value__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_FaultStatusValue_cpu_freq_warn
{
public:
  explicit Init_FaultStatusValue_cpu_freq_warn(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::FaultStatusValue cpu_freq_warn(::drdds::msg::FaultStatusValue::_cpu_freq_warn_type arg)
  {
    msg_.cpu_freq_warn = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_cpu_heat_warn
{
public:
  explicit Init_FaultStatusValue_cpu_heat_warn(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_cpu_freq_warn cpu_heat_warn(::drdds::msg::FaultStatusValue::_cpu_heat_warn_type arg)
  {
    msg_.cpu_heat_warn = std::move(arg);
    return Init_FaultStatusValue_cpu_freq_warn(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_battery_heat_error
{
public:
  explicit Init_FaultStatusValue_battery_heat_error(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_cpu_heat_warn battery_heat_error(::drdds::msg::FaultStatusValue::_battery_heat_error_type arg)
  {
    msg_.battery_heat_error = std::move(arg);
    return Init_FaultStatusValue_cpu_heat_warn(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_battery_heat_warn
{
public:
  explicit Init_FaultStatusValue_battery_heat_warn(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_battery_heat_error battery_heat_warn(::drdds::msg::FaultStatusValue::_battery_heat_warn_type arg)
  {
    msg_.battery_heat_warn = std::move(arg);
    return Init_FaultStatusValue_battery_heat_error(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_battery_voltage_error
{
public:
  explicit Init_FaultStatusValue_battery_voltage_error(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_battery_heat_warn battery_voltage_error(::drdds::msg::FaultStatusValue::_battery_voltage_error_type arg)
  {
    msg_.battery_voltage_error = std::move(arg);
    return Init_FaultStatusValue_battery_heat_warn(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_battery_voltage_warn
{
public:
  explicit Init_FaultStatusValue_battery_voltage_warn(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_battery_voltage_error battery_voltage_warn(::drdds::msg::FaultStatusValue::_battery_voltage_warn_type arg)
  {
    msg_.battery_voltage_warn = std::move(arg);
    return Init_FaultStatusValue_battery_voltage_error(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_battery_low_error
{
public:
  explicit Init_FaultStatusValue_battery_low_error(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_battery_voltage_warn battery_low_error(::drdds::msg::FaultStatusValue::_battery_low_error_type arg)
  {
    msg_.battery_low_error = std::move(arg);
    return Init_FaultStatusValue_battery_voltage_warn(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_battery_low_warn
{
public:
  explicit Init_FaultStatusValue_battery_low_warn(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_battery_low_error battery_low_warn(::drdds::msg::FaultStatusValue::_battery_low_warn_type arg)
  {
    msg_.battery_low_warn = std::move(arg);
    return Init_FaultStatusValue_battery_low_error(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_motor_heat_error
{
public:
  explicit Init_FaultStatusValue_motor_heat_error(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_battery_low_warn motor_heat_error(::drdds::msg::FaultStatusValue::_motor_heat_error_type arg)
  {
    msg_.motor_heat_error = std::move(arg);
    return Init_FaultStatusValue_battery_low_warn(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_motor_heat_warn
{
public:
  explicit Init_FaultStatusValue_motor_heat_warn(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_motor_heat_error motor_heat_warn(::drdds::msg::FaultStatusValue::_motor_heat_warn_type arg)
  {
    msg_.motor_heat_warn = std::move(arg);
    return Init_FaultStatusValue_motor_heat_error(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_driver_heat_error
{
public:
  explicit Init_FaultStatusValue_driver_heat_error(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_motor_heat_warn driver_heat_error(::drdds::msg::FaultStatusValue::_driver_heat_error_type arg)
  {
    msg_.driver_heat_error = std::move(arg);
    return Init_FaultStatusValue_motor_heat_warn(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_driver_heat_warn
{
public:
  explicit Init_FaultStatusValue_driver_heat_warn(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_driver_heat_error driver_heat_warn(::drdds::msg::FaultStatusValue::_driver_heat_warn_type arg)
  {
    msg_.driver_heat_warn = std::move(arg);
    return Init_FaultStatusValue_driver_heat_error(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_wifi_error
{
public:
  explicit Init_FaultStatusValue_wifi_error(::drdds::msg::FaultStatusValue & msg)
  : msg_(msg)
  {}
  Init_FaultStatusValue_driver_heat_warn wifi_error(::drdds::msg::FaultStatusValue::_wifi_error_type arg)
  {
    msg_.wifi_error = std::move(arg);
    return Init_FaultStatusValue_driver_heat_warn(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

class Init_FaultStatusValue_imu_error
{
public:
  Init_FaultStatusValue_imu_error()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FaultStatusValue_wifi_error imu_error(::drdds::msg::FaultStatusValue::_imu_error_type arg)
  {
    msg_.imu_error = std::move(arg);
    return Init_FaultStatusValue_wifi_error(msg_);
  }

private:
  ::drdds::msg::FaultStatusValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::FaultStatusValue>()
{
  return drdds::msg::builder::Init_FaultStatusValue_imu_error();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__BUILDER_HPP_
