// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/GaitValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GAIT_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__GAIT_VALUE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/gait_value__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const GaitValue & msg,
  std::ostream & out)
{
  out << "{";
  // member: gait
  {
    out << "gait: ";
    rosidl_generator_traits::value_to_yaml(msg.gait, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const GaitValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: gait
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gait: ";
    rosidl_generator_traits::value_to_yaml(msg.gait, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const GaitValue & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::GaitValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::GaitValue & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::GaitValue>()
{
  return "drdds::msg::GaitValue";
}

template<>
inline const char * name<drdds::msg::GaitValue>()
{
  return "drdds/msg/GaitValue";
}

template<>
struct has_fixed_size<drdds::msg::GaitValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::GaitValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::GaitValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__GAIT_VALUE__TRAITS_HPP_
