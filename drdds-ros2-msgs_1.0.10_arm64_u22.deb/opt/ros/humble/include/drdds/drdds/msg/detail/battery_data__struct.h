// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/BatteryData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA__STRUCT_H_
#define DRDDS__MSG__DETAIL__BATTERY_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__struct.h"
// Member 'data'
#include "drdds/msg/detail/battery_data_value__struct.h"

/// Struct defined in msg/BatteryData in the package drdds.
typedef struct drdds__msg__BatteryData
{
  drdds__msg__MetaType header;
  drdds__msg__BatteryDataValue__Sequence data;
} drdds__msg__BatteryData;

// Struct for a sequence of drdds__msg__BatteryData.
typedef struct drdds__msg__BatteryData__Sequence
{
  drdds__msg__BatteryData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__BatteryData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA__STRUCT_H_
