// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/CpuData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__CPU_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/cpu_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_CpuData_data
{
public:
  explicit Init_CpuData_data(::drdds::msg::CpuData & msg)
  : msg_(msg)
  {}
  ::drdds::msg::CpuData data(::drdds::msg::CpuData::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::CpuData msg_;
};

class Init_CpuData_header
{
public:
  Init_CpuData_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CpuData_data header(::drdds::msg::CpuData::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CpuData_data(msg_);
  }

private:
  ::drdds::msg::CpuData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::CpuData>()
{
  return drdds::msg::builder::Init_CpuData_header();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__CPU_DATA__BUILDER_HPP_
