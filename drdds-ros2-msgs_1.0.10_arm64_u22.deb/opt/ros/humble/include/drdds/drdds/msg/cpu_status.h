// generated from rosidl_generator_c/resource/idl.h.em
// with input from drdds:msg/CPUStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__CPU_STATUS_H_
#define DRDDS__MSG__CPU_STATUS_H_

#include "drdds/msg/detail/cpu_status__struct.h"
#include "drdds/msg/detail/cpu_status__functions.h"
#include "drdds/msg/detail/cpu_status__type_support.h"

#endif  // DRDDS__MSG__CPU_STATUS_H_
