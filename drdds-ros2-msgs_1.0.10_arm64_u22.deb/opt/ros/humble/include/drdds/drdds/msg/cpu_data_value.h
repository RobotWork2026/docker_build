// generated from rosidl_generator_c/resource/idl.h.em
// with input from drdds:msg/CpuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__CPU_DATA_VALUE_H_
#define DRDDS__MSG__CPU_DATA_VALUE_H_

#include "drdds/msg/detail/cpu_data_value__struct.h"
#include "drdds/msg/detail/cpu_data_value__functions.h"
#include "drdds/msg/detail/cpu_data_value__type_support.h"

#endif  // DRDDS__MSG__CPU_DATA_VALUE_H_
