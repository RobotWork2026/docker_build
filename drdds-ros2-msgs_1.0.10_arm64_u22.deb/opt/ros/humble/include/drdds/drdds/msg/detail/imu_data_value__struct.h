// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/ImuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__IMU_DATA_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__IMU_DATA_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/ImuDataValue in the package drdds.
typedef struct drdds__msg__ImuDataValue
{
  float roll;
  float pitch;
  float yaw;
  float omega_x;
  float omega_y;
  float omega_z;
  float acc_x;
  float acc_y;
  float acc_z;
} drdds__msg__ImuDataValue;

// Struct for a sequence of drdds__msg__ImuDataValue.
typedef struct drdds__msg__ImuDataValue__Sequence
{
  drdds__msg__ImuDataValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__ImuDataValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__IMU_DATA_VALUE__STRUCT_H_
