﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/FaultStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/FaultStatusValue in the package drdds.
typedef struct drdds__msg__FaultStatusValue
{
  /// IMU 错误
  bool imu_error;
  /// WiFi 错误
  bool wifi_error;
  /// 驱动器温度警告/错误计数或标志
  uint32_t driver_heat_warn;
  uint32_t driver_heat_error;
  /// 电机温度警告/错误
  uint32_t motor_heat_warn;
  uint32_t motor_heat_error;
  /// 电池相关
  uint32_t battery_low_warn;
  uint32_t battery_low_error;
  uint32_t battery_voltage_warn;
  uint32_t battery_voltage_error;
  uint32_t battery_heat_warn;
  uint32_t battery_heat_error;
  /// CPU / 频率
  uint32_t cpu_heat_warn;
  uint32_t cpu_freq_warn;
} drdds__msg__FaultStatusValue;

// Struct for a sequence of drdds__msg__FaultStatusValue.
typedef struct drdds__msg__FaultStatusValue__Sequence
{
  drdds__msg__FaultStatusValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__FaultStatusValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__STRUCT_H_
