// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/GridsID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRIDS_ID__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__GRIDS_ID__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/grids_id__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'grids'
#include "drdds/msg/detail/grid_id__traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const GridsID & msg,
  std::ostream & out)
{
  out << "{";
  // member: path
  {
    out << "path: ";
    rosidl_generator_traits::value_to_yaml(msg.path, out);
    out << ", ";
  }

  // member: grids
  {
    if (msg.grids.size() == 0) {
      out << "grids: []";
    } else {
      out << "grids: [";
      size_t pending_items = msg.grids.size();
      for (auto item : msg.grids) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const GridsID & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: path
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "path: ";
    rosidl_generator_traits::value_to_yaml(msg.path, out);
    out << "\n";
  }

  // member: grids
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.grids.size() == 0) {
      out << "grids: []\n";
    } else {
      out << "grids:\n";
      for (auto item : msg.grids) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const GridsID & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::GridsID & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::GridsID & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::GridsID>()
{
  return "drdds::msg::GridsID";
}

template<>
inline const char * name<drdds::msg::GridsID>()
{
  return "drdds/msg/GridsID";
}

template<>
struct has_fixed_size<drdds::msg::GridsID>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::GridsID>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::GridsID>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__GRIDS_ID__TRAITS_HPP_
