// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/JointData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_DATA__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__JOINT_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__drdds__msg__JointData __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__JointData __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct JointData_
{
  using Type = JointData_<ContainerAllocator>;

  explicit JointData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<uint8_t, 4>::iterator, uint8_t>(this->name.begin(), this->name.end(), 0);
      this->data_id = 0;
      this->status_word = 0;
      this->position = 0.0f;
      this->torque = 0.0f;
      this->velocity = 0.0f;
      this->motion_temp = 0.0f;
      this->driver_temp = 0.0f;
    }
  }

  explicit JointData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      std::fill<typename std::array<uint8_t, 4>::iterator, uint8_t>(this->name.begin(), this->name.end(), 0);
      this->data_id = 0;
      this->status_word = 0;
      this->position = 0.0f;
      this->torque = 0.0f;
      this->velocity = 0.0f;
      this->motion_temp = 0.0f;
      this->driver_temp = 0.0f;
    }
  }

  // field types and members
  using _name_type =
    std::array<uint8_t, 4>;
  _name_type name;
  using _data_id_type =
    uint16_t;
  _data_id_type data_id;
  using _status_word_type =
    uint16_t;
  _status_word_type status_word;
  using _position_type =
    float;
  _position_type position;
  using _torque_type =
    float;
  _torque_type torque;
  using _velocity_type =
    float;
  _velocity_type velocity;
  using _motion_temp_type =
    float;
  _motion_temp_type motion_temp;
  using _driver_temp_type =
    float;
  _driver_temp_type driver_temp;

  // setters for named parameter idiom
  Type & set__name(
    const std::array<uint8_t, 4> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__data_id(
    const uint16_t & _arg)
  {
    this->data_id = _arg;
    return *this;
  }
  Type & set__status_word(
    const uint16_t & _arg)
  {
    this->status_word = _arg;
    return *this;
  }
  Type & set__position(
    const float & _arg)
  {
    this->position = _arg;
    return *this;
  }
  Type & set__torque(
    const float & _arg)
  {
    this->torque = _arg;
    return *this;
  }
  Type & set__velocity(
    const float & _arg)
  {
    this->velocity = _arg;
    return *this;
  }
  Type & set__motion_temp(
    const float & _arg)
  {
    this->motion_temp = _arg;
    return *this;
  }
  Type & set__driver_temp(
    const float & _arg)
  {
    this->driver_temp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::JointData_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::JointData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::JointData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::JointData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::JointData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::JointData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::JointData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::JointData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::JointData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::JointData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__JointData
    std::shared_ptr<drdds::msg::JointData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__JointData
    std::shared_ptr<drdds::msg::JointData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const JointData_ & other) const
  {
    if (this->name != other.name) {
      return false;
    }
    if (this->data_id != other.data_id) {
      return false;
    }
    if (this->status_word != other.status_word) {
      return false;
    }
    if (this->position != other.position) {
      return false;
    }
    if (this->torque != other.torque) {
      return false;
    }
    if (this->velocity != other.velocity) {
      return false;
    }
    if (this->motion_temp != other.motion_temp) {
      return false;
    }
    if (this->driver_temp != other.driver_temp) {
      return false;
    }
    return true;
  }
  bool operator!=(const JointData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct JointData_

// alias to use template instance with default allocator
using JointData =
  drdds::msg::JointData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__JOINT_DATA__STRUCT_HPP_
