// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/Exception.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXCEPTION__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__EXCEPTION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/exception__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const Exception & msg,
  std::ostream & out)
{
  out << "{";
  // member: stamp
  {
    out << "stamp: ";
    to_flow_style_yaml(msg.stamp, out);
    out << ", ";
  }

  // member: source
  {
    out << "source: ";
    rosidl_generator_traits::value_to_yaml(msg.source, out);
    out << ", ";
  }

  // member: description
  {
    out << "description: ";
    rosidl_generator_traits::value_to_yaml(msg.description, out);
    out << ", ";
  }

  // member: is_abnormal
  {
    out << "is_abnormal: ";
    rosidl_generator_traits::value_to_yaml(msg.is_abnormal, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Exception & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stamp:\n";
    to_block_style_yaml(msg.stamp, out, indentation + 2);
  }

  // member: source
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "source: ";
    rosidl_generator_traits::value_to_yaml(msg.source, out);
    out << "\n";
  }

  // member: description
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "description: ";
    rosidl_generator_traits::value_to_yaml(msg.description, out);
    out << "\n";
  }

  // member: is_abnormal
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_abnormal: ";
    rosidl_generator_traits::value_to_yaml(msg.is_abnormal, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Exception & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::Exception & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::Exception & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::Exception>()
{
  return "drdds::msg::Exception";
}

template<>
inline const char * name<drdds::msg::Exception>()
{
  return "drdds/msg/Exception";
}

template<>
struct has_fixed_size<drdds::msg::Exception>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::Exception>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::Exception>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__EXCEPTION__TRAITS_HPP_
