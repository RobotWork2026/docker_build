// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/FaultEventArray.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/fault_event_array__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/fault_event_array__functions.h"
#include "drdds/msg/detail/fault_event_array__struct.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/time.h"
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__rosidl_typesupport_introspection_c.h"
// Member `active_faults`
#include "drdds/msg/fault_event.h"
// Member `active_faults`
#include "drdds/msg/detail/fault_event__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__FaultEventArray__init(message_memory);
}

void drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_fini_function(void * message_memory)
{
  drdds__msg__FaultEventArray__fini(message_memory);
}

size_t drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__size_function__FaultEventArray__active_faults(
  const void * untyped_member)
{
  const drdds__msg__FaultEvent__Sequence * member =
    (const drdds__msg__FaultEvent__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__get_const_function__FaultEventArray__active_faults(
  const void * untyped_member, size_t index)
{
  const drdds__msg__FaultEvent__Sequence * member =
    (const drdds__msg__FaultEvent__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__get_function__FaultEventArray__active_faults(
  void * untyped_member, size_t index)
{
  drdds__msg__FaultEvent__Sequence * member =
    (drdds__msg__FaultEvent__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__fetch_function__FaultEventArray__active_faults(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const drdds__msg__FaultEvent * item =
    ((const drdds__msg__FaultEvent *)
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__get_const_function__FaultEventArray__active_faults(untyped_member, index));
  drdds__msg__FaultEvent * value =
    (drdds__msg__FaultEvent *)(untyped_value);
  *value = *item;
}

void drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__assign_function__FaultEventArray__active_faults(
  void * untyped_member, size_t index, const void * untyped_value)
{
  drdds__msg__FaultEvent * item =
    ((drdds__msg__FaultEvent *)
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__get_function__FaultEventArray__active_faults(untyped_member, index));
  const drdds__msg__FaultEvent * value =
    (const drdds__msg__FaultEvent *)(untyped_value);
  *item = *value;
}

bool drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__resize_function__FaultEventArray__active_faults(
  void * untyped_member, size_t size)
{
  drdds__msg__FaultEvent__Sequence * member =
    (drdds__msg__FaultEvent__Sequence *)(untyped_member);
  drdds__msg__FaultEvent__Sequence__fini(member);
  return drdds__msg__FaultEvent__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_member_array[2] = {
  {
    "timestamp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__FaultEventArray, timestamp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "active_faults",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__FaultEventArray, active_faults),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__size_function__FaultEventArray__active_faults,  // size() function pointer
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__get_const_function__FaultEventArray__active_faults,  // get_const(index) function pointer
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__get_function__FaultEventArray__active_faults,  // get(index) function pointer
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__fetch_function__FaultEventArray__active_faults,  // fetch(index, &value) function pointer
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__assign_function__FaultEventArray__active_faults,  // assign(index, value) function pointer
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__resize_function__FaultEventArray__active_faults  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_members = {
  "drdds__msg",  // message namespace
  "FaultEventArray",  // message name
  2,  // number of fields
  sizeof(drdds__msg__FaultEventArray),
  drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_member_array,  // message members
  drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_init_function,  // function to initialize message memory (memory has to be allocated)
  drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_type_support_handle = {
  0,
  &drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, FaultEventArray)() {
  drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, builtin_interfaces, msg, Time)();
  drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, FaultEvent)();
  if (!drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_type_support_handle.typesupport_identifier) {
    drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &drdds__msg__FaultEventArray__rosidl_typesupport_introspection_c__FaultEventArray_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
