// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/AiryLidarStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__struct.hpp"
// Member 'data'
#include "drdds/msg/detail/airy_lidar_value__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__drdds__msg__AiryLidarStatus __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__AiryLidarStatus __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AiryLidarStatus_
{
  using Type = AiryLidarStatus_<ContainerAllocator>;

  explicit AiryLidarStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    (void)_init;
  }

  explicit AiryLidarStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    drdds::msg::MetaType_<ContainerAllocator>;
  _header_type header;
  using _data_type =
    std::vector<drdds::msg::AiryLidarValue_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<drdds::msg::AiryLidarValue_<ContainerAllocator>>>;
  _data_type data;

  // setters for named parameter idiom
  Type & set__header(
    const drdds::msg::MetaType_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__data(
    const std::vector<drdds::msg::AiryLidarValue_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<drdds::msg::AiryLidarValue_<ContainerAllocator>>> & _arg)
  {
    this->data = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::AiryLidarStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::AiryLidarStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::AiryLidarStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::AiryLidarStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::AiryLidarStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::AiryLidarStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::AiryLidarStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::AiryLidarStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::AiryLidarStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::AiryLidarStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__AiryLidarStatus
    std::shared_ptr<drdds::msg::AiryLidarStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__AiryLidarStatus
    std::shared_ptr<drdds::msg::AiryLidarStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AiryLidarStatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->data != other.data) {
      return false;
    }
    return true;
  }
  bool operator!=(const AiryLidarStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AiryLidarStatus_

// alias to use template instance with default allocator
using AiryLidarStatus =
  drdds::msg::AiryLidarStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_STATUS__STRUCT_HPP_
