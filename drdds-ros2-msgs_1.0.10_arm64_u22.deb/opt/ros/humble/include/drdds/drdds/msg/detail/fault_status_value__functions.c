// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/FaultStatusValue.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/fault_status_value__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
drdds__msg__FaultStatusValue__init(drdds__msg__FaultStatusValue * msg)
{
  if (!msg) {
    return false;
  }
  // imu_error
  // wifi_error
  // driver_heat_warn
  // driver_heat_error
  // motor_heat_warn
  // motor_heat_error
  // battery_low_warn
  // battery_low_error
  // battery_voltage_warn
  // battery_voltage_error
  // battery_heat_warn
  // battery_heat_error
  // cpu_heat_warn
  // cpu_freq_warn
  return true;
}

void
drdds__msg__FaultStatusValue__fini(drdds__msg__FaultStatusValue * msg)
{
  if (!msg) {
    return;
  }
  // imu_error
  // wifi_error
  // driver_heat_warn
  // driver_heat_error
  // motor_heat_warn
  // motor_heat_error
  // battery_low_warn
  // battery_low_error
  // battery_voltage_warn
  // battery_voltage_error
  // battery_heat_warn
  // battery_heat_error
  // cpu_heat_warn
  // cpu_freq_warn
}

bool
drdds__msg__FaultStatusValue__are_equal(const drdds__msg__FaultStatusValue * lhs, const drdds__msg__FaultStatusValue * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // imu_error
  if (lhs->imu_error != rhs->imu_error) {
    return false;
  }
  // wifi_error
  if (lhs->wifi_error != rhs->wifi_error) {
    return false;
  }
  // driver_heat_warn
  if (lhs->driver_heat_warn != rhs->driver_heat_warn) {
    return false;
  }
  // driver_heat_error
  if (lhs->driver_heat_error != rhs->driver_heat_error) {
    return false;
  }
  // motor_heat_warn
  if (lhs->motor_heat_warn != rhs->motor_heat_warn) {
    return false;
  }
  // motor_heat_error
  if (lhs->motor_heat_error != rhs->motor_heat_error) {
    return false;
  }
  // battery_low_warn
  if (lhs->battery_low_warn != rhs->battery_low_warn) {
    return false;
  }
  // battery_low_error
  if (lhs->battery_low_error != rhs->battery_low_error) {
    return false;
  }
  // battery_voltage_warn
  if (lhs->battery_voltage_warn != rhs->battery_voltage_warn) {
    return false;
  }
  // battery_voltage_error
  if (lhs->battery_voltage_error != rhs->battery_voltage_error) {
    return false;
  }
  // battery_heat_warn
  if (lhs->battery_heat_warn != rhs->battery_heat_warn) {
    return false;
  }
  // battery_heat_error
  if (lhs->battery_heat_error != rhs->battery_heat_error) {
    return false;
  }
  // cpu_heat_warn
  if (lhs->cpu_heat_warn != rhs->cpu_heat_warn) {
    return false;
  }
  // cpu_freq_warn
  if (lhs->cpu_freq_warn != rhs->cpu_freq_warn) {
    return false;
  }
  return true;
}

bool
drdds__msg__FaultStatusValue__copy(
  const drdds__msg__FaultStatusValue * input,
  drdds__msg__FaultStatusValue * output)
{
  if (!input || !output) {
    return false;
  }
  // imu_error
  output->imu_error = input->imu_error;
  // wifi_error
  output->wifi_error = input->wifi_error;
  // driver_heat_warn
  output->driver_heat_warn = input->driver_heat_warn;
  // driver_heat_error
  output->driver_heat_error = input->driver_heat_error;
  // motor_heat_warn
  output->motor_heat_warn = input->motor_heat_warn;
  // motor_heat_error
  output->motor_heat_error = input->motor_heat_error;
  // battery_low_warn
  output->battery_low_warn = input->battery_low_warn;
  // battery_low_error
  output->battery_low_error = input->battery_low_error;
  // battery_voltage_warn
  output->battery_voltage_warn = input->battery_voltage_warn;
  // battery_voltage_error
  output->battery_voltage_error = input->battery_voltage_error;
  // battery_heat_warn
  output->battery_heat_warn = input->battery_heat_warn;
  // battery_heat_error
  output->battery_heat_error = input->battery_heat_error;
  // cpu_heat_warn
  output->cpu_heat_warn = input->cpu_heat_warn;
  // cpu_freq_warn
  output->cpu_freq_warn = input->cpu_freq_warn;
  return true;
}

drdds__msg__FaultStatusValue *
drdds__msg__FaultStatusValue__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FaultStatusValue * msg = (drdds__msg__FaultStatusValue *)allocator.allocate(sizeof(drdds__msg__FaultStatusValue), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__FaultStatusValue));
  bool success = drdds__msg__FaultStatusValue__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__FaultStatusValue__destroy(drdds__msg__FaultStatusValue * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__FaultStatusValue__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__FaultStatusValue__Sequence__init(drdds__msg__FaultStatusValue__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FaultStatusValue * data = NULL;

  if (size) {
    data = (drdds__msg__FaultStatusValue *)allocator.zero_allocate(size, sizeof(drdds__msg__FaultStatusValue), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__FaultStatusValue__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__FaultStatusValue__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__FaultStatusValue__Sequence__fini(drdds__msg__FaultStatusValue__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__FaultStatusValue__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__FaultStatusValue__Sequence *
drdds__msg__FaultStatusValue__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FaultStatusValue__Sequence * array = (drdds__msg__FaultStatusValue__Sequence *)allocator.allocate(sizeof(drdds__msg__FaultStatusValue__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__FaultStatusValue__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__FaultStatusValue__Sequence__destroy(drdds__msg__FaultStatusValue__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__FaultStatusValue__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__FaultStatusValue__Sequence__are_equal(const drdds__msg__FaultStatusValue__Sequence * lhs, const drdds__msg__FaultStatusValue__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__FaultStatusValue__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__FaultStatusValue__Sequence__copy(
  const drdds__msg__FaultStatusValue__Sequence * input,
  drdds__msg__FaultStatusValue__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__FaultStatusValue);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__FaultStatusValue * data =
      (drdds__msg__FaultStatusValue *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__FaultStatusValue__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__FaultStatusValue__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__FaultStatusValue__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
