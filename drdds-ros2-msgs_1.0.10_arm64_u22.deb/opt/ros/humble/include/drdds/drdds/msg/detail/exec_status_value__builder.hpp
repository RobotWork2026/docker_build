// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/ExecStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/exec_status_value__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_ExecStatusValue_timestamp_error
{
public:
  explicit Init_ExecStatusValue_timestamp_error(::drdds::msg::ExecStatusValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::ExecStatusValue timestamp_error(::drdds::msg::ExecStatusValue::_timestamp_error_type arg)
  {
    msg_.timestamp_error = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::ExecStatusValue msg_;
};

class Init_ExecStatusValue_numeric_error
{
public:
  explicit Init_ExecStatusValue_numeric_error(::drdds::msg::ExecStatusValue & msg)
  : msg_(msg)
  {}
  Init_ExecStatusValue_timestamp_error numeric_error(::drdds::msg::ExecStatusValue::_numeric_error_type arg)
  {
    msg_.numeric_error = std::move(arg);
    return Init_ExecStatusValue_timestamp_error(msg_);
  }

private:
  ::drdds::msg::ExecStatusValue msg_;
};

class Init_ExecStatusValue_overtime
{
public:
  Init_ExecStatusValue_overtime()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ExecStatusValue_numeric_error overtime(::drdds::msg::ExecStatusValue::_overtime_type arg)
  {
    msg_.overtime = std::move(arg);
    return Init_ExecStatusValue_numeric_error(msg_);
  }

private:
  ::drdds::msg::ExecStatusValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::ExecStatusValue>()
{
  return drdds::msg::builder::Init_ExecStatusValue_overtime();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__BUILDER_HPP_
