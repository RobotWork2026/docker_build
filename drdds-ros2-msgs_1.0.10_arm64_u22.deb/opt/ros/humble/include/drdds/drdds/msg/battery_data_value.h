// generated from rosidl_generator_c/resource/idl.h.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__BATTERY_DATA_VALUE_H_
#define DRDDS__MSG__BATTERY_DATA_VALUE_H_

#include "drdds/msg/detail/battery_data_value__struct.h"
#include "drdds/msg/detail/battery_data_value__functions.h"
#include "drdds/msg/detail/battery_data_value__type_support.h"

#endif  // DRDDS__MSG__BATTERY_DATA_VALUE_H_
