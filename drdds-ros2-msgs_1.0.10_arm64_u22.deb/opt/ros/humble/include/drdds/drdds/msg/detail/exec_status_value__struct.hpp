// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/ExecStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__drdds__msg__ExecStatusValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__ExecStatusValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ExecStatusValue_
{
  using Type = ExecStatusValue_<ContainerAllocator>;

  explicit ExecStatusValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->overtime = 0;
      this->numeric_error = 0;
      this->timestamp_error = 0;
    }
  }

  explicit ExecStatusValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->overtime = 0;
      this->numeric_error = 0;
      this->timestamp_error = 0;
    }
  }

  // field types and members
  using _overtime_type =
    uint8_t;
  _overtime_type overtime;
  using _numeric_error_type =
    uint8_t;
  _numeric_error_type numeric_error;
  using _timestamp_error_type =
    uint8_t;
  _timestamp_error_type timestamp_error;

  // setters for named parameter idiom
  Type & set__overtime(
    const uint8_t & _arg)
  {
    this->overtime = _arg;
    return *this;
  }
  Type & set__numeric_error(
    const uint8_t & _arg)
  {
    this->numeric_error = _arg;
    return *this;
  }
  Type & set__timestamp_error(
    const uint8_t & _arg)
  {
    this->timestamp_error = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::ExecStatusValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::ExecStatusValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::ExecStatusValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::ExecStatusValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::ExecStatusValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::ExecStatusValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::ExecStatusValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::ExecStatusValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::ExecStatusValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::ExecStatusValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__ExecStatusValue
    std::shared_ptr<drdds::msg::ExecStatusValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__ExecStatusValue
    std::shared_ptr<drdds::msg::ExecStatusValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ExecStatusValue_ & other) const
  {
    if (this->overtime != other.overtime) {
      return false;
    }
    if (this->numeric_error != other.numeric_error) {
      return false;
    }
    if (this->timestamp_error != other.timestamp_error) {
      return false;
    }
    return true;
  }
  bool operator!=(const ExecStatusValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ExecStatusValue_

// alias to use template instance with default allocator
using ExecStatusValue =
  drdds::msg::ExecStatusValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__STRUCT_HPP_
