// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/FaultEventArray.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__STRUCT_H_
#define DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'active_faults'
#include "drdds/msg/detail/fault_event__struct.h"

/// Struct defined in msg/FaultEventArray in the package drdds.
/**
  * Snapshot of currently active fault events
 */
typedef struct drdds__msg__FaultEventArray
{
  /// Timestamp of this snapshot
  builtin_interfaces__msg__Time timestamp;
  /// List of currently active faults
  drdds__msg__FaultEvent__Sequence active_faults;
} drdds__msg__FaultEventArray;

// Struct for a sequence of drdds__msg__FaultEventArray.
typedef struct drdds__msg__FaultEventArray__Sequence
{
  drdds__msg__FaultEventArray * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__FaultEventArray__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__STRUCT_H_
