// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/FileSystemStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/file_system_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_FileSystemStatus_is_readonly
{
public:
  explicit Init_FileSystemStatus_is_readonly(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  ::drdds::msg::FileSystemStatus is_readonly(::drdds::msg::FileSystemStatus::_is_readonly_type arg)
  {
    msg_.is_readonly = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_free_inodes
{
public:
  explicit Init_FileSystemStatus_free_inodes(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_is_readonly free_inodes(::drdds::msg::FileSystemStatus::_free_inodes_type arg)
  {
    msg_.free_inodes = std::move(arg);
    return Init_FileSystemStatus_is_readonly(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_used_inodes
{
public:
  explicit Init_FileSystemStatus_used_inodes(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_free_inodes used_inodes(::drdds::msg::FileSystemStatus::_used_inodes_type arg)
  {
    msg_.used_inodes = std::move(arg);
    return Init_FileSystemStatus_free_inodes(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_available_bytes
{
public:
  explicit Init_FileSystemStatus_available_bytes(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_used_inodes available_bytes(::drdds::msg::FileSystemStatus::_available_bytes_type arg)
  {
    msg_.available_bytes = std::move(arg);
    return Init_FileSystemStatus_used_inodes(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_used_bytes
{
public:
  explicit Init_FileSystemStatus_used_bytes(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_available_bytes used_bytes(::drdds::msg::FileSystemStatus::_used_bytes_type arg)
  {
    msg_.used_bytes = std::move(arg);
    return Init_FileSystemStatus_available_bytes(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_total_bytes
{
public:
  explicit Init_FileSystemStatus_total_bytes(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_used_bytes total_bytes(::drdds::msg::FileSystemStatus::_total_bytes_type arg)
  {
    msg_.total_bytes = std::move(arg);
    return Init_FileSystemStatus_used_bytes(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_fs_type
{
public:
  explicit Init_FileSystemStatus_fs_type(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_total_bytes fs_type(::drdds::msg::FileSystemStatus::_fs_type_type arg)
  {
    msg_.fs_type = std::move(arg);
    return Init_FileSystemStatus_total_bytes(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_device_path
{
public:
  explicit Init_FileSystemStatus_device_path(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_fs_type device_path(::drdds::msg::FileSystemStatus::_device_path_type arg)
  {
    msg_.device_path = std::move(arg);
    return Init_FileSystemStatus_fs_type(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_mount_point
{
public:
  explicit Init_FileSystemStatus_mount_point(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_device_path mount_point(::drdds::msg::FileSystemStatus::_mount_point_type arg)
  {
    msg_.mount_point = std::move(arg);
    return Init_FileSystemStatus_device_path(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_soc_id
{
public:
  explicit Init_FileSystemStatus_soc_id(::drdds::msg::FileSystemStatus & msg)
  : msg_(msg)
  {}
  Init_FileSystemStatus_mount_point soc_id(::drdds::msg::FileSystemStatus::_soc_id_type arg)
  {
    msg_.soc_id = std::move(arg);
    return Init_FileSystemStatus_mount_point(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

class Init_FileSystemStatus_timestamp
{
public:
  Init_FileSystemStatus_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FileSystemStatus_soc_id timestamp(::drdds::msg::FileSystemStatus::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_FileSystemStatus_soc_id(msg_);
  }

private:
  ::drdds::msg::FileSystemStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::FileSystemStatus>()
{
  return drdds::msg::builder::Init_FileSystemStatus_timestamp();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__BUILDER_HPP_
