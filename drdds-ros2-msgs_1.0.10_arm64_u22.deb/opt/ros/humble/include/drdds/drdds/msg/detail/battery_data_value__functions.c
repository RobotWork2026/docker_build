// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/battery_data_value__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `battery_temperature`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
drdds__msg__BatteryDataValue__init(drdds__msg__BatteryDataValue * msg)
{
  if (!msg) {
    return false;
  }
  // voltage
  // current
  // remaining_capacity
  // nominal_capacity
  // cycles
  // production_date
  // balanced_low
  // balanced_high
  // protected_state
  // software_version
  // battery_level
  // mos_state
  // battery_quantity
  // battery_ntc
  // battery_temperature
  if (!rosidl_runtime_c__float__Sequence__init(&msg->battery_temperature, 0)) {
    drdds__msg__BatteryDataValue__fini(msg);
    return false;
  }
  // battery_serialnum
  return true;
}

void
drdds__msg__BatteryDataValue__fini(drdds__msg__BatteryDataValue * msg)
{
  if (!msg) {
    return;
  }
  // voltage
  // current
  // remaining_capacity
  // nominal_capacity
  // cycles
  // production_date
  // balanced_low
  // balanced_high
  // protected_state
  // software_version
  // battery_level
  // mos_state
  // battery_quantity
  // battery_ntc
  // battery_temperature
  rosidl_runtime_c__float__Sequence__fini(&msg->battery_temperature);
  // battery_serialnum
}

bool
drdds__msg__BatteryDataValue__are_equal(const drdds__msg__BatteryDataValue * lhs, const drdds__msg__BatteryDataValue * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // voltage
  if (lhs->voltage != rhs->voltage) {
    return false;
  }
  // current
  if (lhs->current != rhs->current) {
    return false;
  }
  // remaining_capacity
  if (lhs->remaining_capacity != rhs->remaining_capacity) {
    return false;
  }
  // nominal_capacity
  if (lhs->nominal_capacity != rhs->nominal_capacity) {
    return false;
  }
  // cycles
  if (lhs->cycles != rhs->cycles) {
    return false;
  }
  // production_date
  if (lhs->production_date != rhs->production_date) {
    return false;
  }
  // balanced_low
  if (lhs->balanced_low != rhs->balanced_low) {
    return false;
  }
  // balanced_high
  if (lhs->balanced_high != rhs->balanced_high) {
    return false;
  }
  // protected_state
  if (lhs->protected_state != rhs->protected_state) {
    return false;
  }
  // software_version
  if (lhs->software_version != rhs->software_version) {
    return false;
  }
  // battery_level
  if (lhs->battery_level != rhs->battery_level) {
    return false;
  }
  // mos_state
  if (lhs->mos_state != rhs->mos_state) {
    return false;
  }
  // battery_quantity
  if (lhs->battery_quantity != rhs->battery_quantity) {
    return false;
  }
  // battery_ntc
  if (lhs->battery_ntc != rhs->battery_ntc) {
    return false;
  }
  // battery_temperature
  if (!rosidl_runtime_c__float__Sequence__are_equal(
      &(lhs->battery_temperature), &(rhs->battery_temperature)))
  {
    return false;
  }
  // battery_serialnum
  for (size_t i = 0; i < 32; ++i) {
    if (lhs->battery_serialnum[i] != rhs->battery_serialnum[i]) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__BatteryDataValue__copy(
  const drdds__msg__BatteryDataValue * input,
  drdds__msg__BatteryDataValue * output)
{
  if (!input || !output) {
    return false;
  }
  // voltage
  output->voltage = input->voltage;
  // current
  output->current = input->current;
  // remaining_capacity
  output->remaining_capacity = input->remaining_capacity;
  // nominal_capacity
  output->nominal_capacity = input->nominal_capacity;
  // cycles
  output->cycles = input->cycles;
  // production_date
  output->production_date = input->production_date;
  // balanced_low
  output->balanced_low = input->balanced_low;
  // balanced_high
  output->balanced_high = input->balanced_high;
  // protected_state
  output->protected_state = input->protected_state;
  // software_version
  output->software_version = input->software_version;
  // battery_level
  output->battery_level = input->battery_level;
  // mos_state
  output->mos_state = input->mos_state;
  // battery_quantity
  output->battery_quantity = input->battery_quantity;
  // battery_ntc
  output->battery_ntc = input->battery_ntc;
  // battery_temperature
  if (!rosidl_runtime_c__float__Sequence__copy(
      &(input->battery_temperature), &(output->battery_temperature)))
  {
    return false;
  }
  // battery_serialnum
  for (size_t i = 0; i < 32; ++i) {
    output->battery_serialnum[i] = input->battery_serialnum[i];
  }
  return true;
}

drdds__msg__BatteryDataValue *
drdds__msg__BatteryDataValue__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__BatteryDataValue * msg = (drdds__msg__BatteryDataValue *)allocator.allocate(sizeof(drdds__msg__BatteryDataValue), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__BatteryDataValue));
  bool success = drdds__msg__BatteryDataValue__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__BatteryDataValue__destroy(drdds__msg__BatteryDataValue * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__BatteryDataValue__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__BatteryDataValue__Sequence__init(drdds__msg__BatteryDataValue__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__BatteryDataValue * data = NULL;

  if (size) {
    data = (drdds__msg__BatteryDataValue *)allocator.zero_allocate(size, sizeof(drdds__msg__BatteryDataValue), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__BatteryDataValue__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__BatteryDataValue__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__BatteryDataValue__Sequence__fini(drdds__msg__BatteryDataValue__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__BatteryDataValue__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__BatteryDataValue__Sequence *
drdds__msg__BatteryDataValue__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__BatteryDataValue__Sequence * array = (drdds__msg__BatteryDataValue__Sequence *)allocator.allocate(sizeof(drdds__msg__BatteryDataValue__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__BatteryDataValue__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__BatteryDataValue__Sequence__destroy(drdds__msg__BatteryDataValue__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__BatteryDataValue__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__BatteryDataValue__Sequence__are_equal(const drdds__msg__BatteryDataValue__Sequence * lhs, const drdds__msg__BatteryDataValue__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__BatteryDataValue__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__BatteryDataValue__Sequence__copy(
  const drdds__msg__BatteryDataValue__Sequence * input,
  drdds__msg__BatteryDataValue__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__BatteryDataValue);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__BatteryDataValue * data =
      (drdds__msg__BatteryDataValue *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__BatteryDataValue__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__BatteryDataValue__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__BatteryDataValue__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
