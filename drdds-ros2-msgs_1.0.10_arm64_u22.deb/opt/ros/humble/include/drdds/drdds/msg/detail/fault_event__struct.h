// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/FaultEvent.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_H_
#define DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'TYPE_START'.
/**
  * define event type Constant
 */
enum
{
  drdds__msg__FaultEvent__TYPE_START = 1
};

/// Constant 'TYPE_STOP'.
enum
{
  drdds__msg__FaultEvent__TYPE_STOP = 2
};

/// Constant 'TYPE_PULSE'.
/**
  * Not used
 */
enum
{
  drdds__msg__FaultEvent__TYPE_PULSE = 3
};

/// Constant 'SEVERITY_DEBUG'.
/**
  * define Severity level Constant
  * Not used
 */
enum
{
  drdds__msg__FaultEvent__SEVERITY_DEBUG = 1
};

/// Constant 'SEVERITY_INFO'.
/**
  * Not used
 */
enum
{
  drdds__msg__FaultEvent__SEVERITY_INFO = 2
};

/// Constant 'SEVERITY_WARN'.
enum
{
  drdds__msg__FaultEvent__SEVERITY_WARN = 3
};

/// Constant 'SEVERITY_ERROR'.
enum
{
  drdds__msg__FaultEvent__SEVERITY_ERROR = 4
};

/// Constant 'SEVERITY_FATAL'.
enum
{
  drdds__msg__FaultEvent__SEVERITY_FATAL = 5
};

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'name'
// Member 'resources'
// Member 'source'
// Member 'details'
#include "rosidl_runtime_c/string.h"
// Member 'severities'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/FaultEvent in the package drdds.
/**
  * Fault event message for system faults
  * Fault Code Categories (Revised)
  * 0x80xx: Joints (motors, drivers, encoders, IMU, etc.)
  * 0x81xx: Battery (cells, BMS, voltage, current, temperature, etc.)
  * 0x82xx: Mainboard (CPU, memory, storage, network, system time, etc.)
  * 0x83xx: Peripherals (LiDAR, cameras, buttons, RTK, handheld devices, etc.)
  * 0x84xx: Motion control (manual control & autonomous control)
  * 0x85xx: Charging (autonomous and manual charging scenarios)
  * 0x86xx: System monitoring (heartbeats, process liveness, module responsiveness, etc.)
 */
typedef struct drdds__msg__FaultEvent
{
  /// Aggregate logical uniqueness identifier = code + resources + source;
  /// Timestamp of fault occurrence
  builtin_interfaces__msg__Time timestamp;
  /// Fault name; unique across types, identical for same-type faults
  rosidl_runtime_c__String name;
  /// Fault code; unique across types, identical for same-type faults
  uint32_t code;
  /// Event type: start/stop (severity changes use START)
  uint8_t type;
  /// Severity levels: array for aggregated instances (warn/error/fatal)
  rosidl_runtime_c__uint8__Sequence severities;
  /// Resource array: Indexable Resources(start from 1); Entity Resources(Resource name)
  rosidl_runtime_c__String__Sequence resources;
  /// true, Multi-resource group tracking; false: single resource independent tracking;
  bool grouped;
  /// The name of the process that triggered this fault event, used to identify the reporting entity, only one element needs to be filled in;
  rosidl_runtime_c__String__Sequence source;
  /// Additional data in compact JSON format
  rosidl_runtime_c__String details;
} drdds__msg__FaultEvent;

// Struct for a sequence of drdds__msg__FaultEvent.
typedef struct drdds__msg__FaultEvent__Sequence
{
  drdds__msg__FaultEvent * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__FaultEvent__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_H_
