// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/JointData.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/joint_data__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
drdds__msg__JointData__init(drdds__msg__JointData * msg)
{
  if (!msg) {
    return false;
  }
  // name
  // data_id
  // status_word
  // position
  // torque
  // velocity
  // motion_temp
  // driver_temp
  return true;
}

void
drdds__msg__JointData__fini(drdds__msg__JointData * msg)
{
  if (!msg) {
    return;
  }
  // name
  // data_id
  // status_word
  // position
  // torque
  // velocity
  // motion_temp
  // driver_temp
}

bool
drdds__msg__JointData__are_equal(const drdds__msg__JointData * lhs, const drdds__msg__JointData * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // name
  for (size_t i = 0; i < 4; ++i) {
    if (lhs->name[i] != rhs->name[i]) {
      return false;
    }
  }
  // data_id
  if (lhs->data_id != rhs->data_id) {
    return false;
  }
  // status_word
  if (lhs->status_word != rhs->status_word) {
    return false;
  }
  // position
  if (lhs->position != rhs->position) {
    return false;
  }
  // torque
  if (lhs->torque != rhs->torque) {
    return false;
  }
  // velocity
  if (lhs->velocity != rhs->velocity) {
    return false;
  }
  // motion_temp
  if (lhs->motion_temp != rhs->motion_temp) {
    return false;
  }
  // driver_temp
  if (lhs->driver_temp != rhs->driver_temp) {
    return false;
  }
  return true;
}

bool
drdds__msg__JointData__copy(
  const drdds__msg__JointData * input,
  drdds__msg__JointData * output)
{
  if (!input || !output) {
    return false;
  }
  // name
  for (size_t i = 0; i < 4; ++i) {
    output->name[i] = input->name[i];
  }
  // data_id
  output->data_id = input->data_id;
  // status_word
  output->status_word = input->status_word;
  // position
  output->position = input->position;
  // torque
  output->torque = input->torque;
  // velocity
  output->velocity = input->velocity;
  // motion_temp
  output->motion_temp = input->motion_temp;
  // driver_temp
  output->driver_temp = input->driver_temp;
  return true;
}

drdds__msg__JointData *
drdds__msg__JointData__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__JointData * msg = (drdds__msg__JointData *)allocator.allocate(sizeof(drdds__msg__JointData), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__JointData));
  bool success = drdds__msg__JointData__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__JointData__destroy(drdds__msg__JointData * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__JointData__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__JointData__Sequence__init(drdds__msg__JointData__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__JointData * data = NULL;

  if (size) {
    data = (drdds__msg__JointData *)allocator.zero_allocate(size, sizeof(drdds__msg__JointData), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__JointData__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__JointData__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__JointData__Sequence__fini(drdds__msg__JointData__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__JointData__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__JointData__Sequence *
drdds__msg__JointData__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__JointData__Sequence * array = (drdds__msg__JointData__Sequence *)allocator.allocate(sizeof(drdds__msg__JointData__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__JointData__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__JointData__Sequence__destroy(drdds__msg__JointData__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__JointData__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__JointData__Sequence__are_equal(const drdds__msg__JointData__Sequence * lhs, const drdds__msg__JointData__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__JointData__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__JointData__Sequence__copy(
  const drdds__msg__JointData__Sequence * input,
  drdds__msg__JointData__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__JointData);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__JointData * data =
      (drdds__msg__JointData *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__JointData__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__JointData__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__JointData__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
