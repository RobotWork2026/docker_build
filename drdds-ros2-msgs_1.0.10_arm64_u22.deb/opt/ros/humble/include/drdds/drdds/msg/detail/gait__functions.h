// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from drdds:msg/Gait.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GAIT__FUNCTIONS_H_
#define DRDDS__MSG__DETAIL__GAIT__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "drdds/msg/rosidl_generator_c__visibility_control.h"

#include "drdds/msg/detail/gait__struct.h"

/// Initialize msg/Gait message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * drdds__msg__Gait
 * )) before or use
 * drdds__msg__Gait__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__Gait__init(drdds__msg__Gait * msg);

/// Finalize msg/Gait message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
void
drdds__msg__Gait__fini(drdds__msg__Gait * msg);

/// Create msg/Gait message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * drdds__msg__Gait__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
drdds__msg__Gait *
drdds__msg__Gait__create();

/// Destroy msg/Gait message.
/**
 * It calls
 * drdds__msg__Gait__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
void
drdds__msg__Gait__destroy(drdds__msg__Gait * msg);

/// Check for msg/Gait message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__Gait__are_equal(const drdds__msg__Gait * lhs, const drdds__msg__Gait * rhs);

/// Copy a msg/Gait message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__Gait__copy(
  const drdds__msg__Gait * input,
  drdds__msg__Gait * output);

/// Initialize array of msg/Gait messages.
/**
 * It allocates the memory for the number of elements and calls
 * drdds__msg__Gait__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__Gait__Sequence__init(drdds__msg__Gait__Sequence * array, size_t size);

/// Finalize array of msg/Gait messages.
/**
 * It calls
 * drdds__msg__Gait__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
void
drdds__msg__Gait__Sequence__fini(drdds__msg__Gait__Sequence * array);

/// Create array of msg/Gait messages.
/**
 * It allocates the memory for the array and calls
 * drdds__msg__Gait__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
drdds__msg__Gait__Sequence *
drdds__msg__Gait__Sequence__create(size_t size);

/// Destroy array of msg/Gait messages.
/**
 * It calls
 * drdds__msg__Gait__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
void
drdds__msg__Gait__Sequence__destroy(drdds__msg__Gait__Sequence * array);

/// Check for msg/Gait message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__Gait__Sequence__are_equal(const drdds__msg__Gait__Sequence * lhs, const drdds__msg__Gait__Sequence * rhs);

/// Copy an array of msg/Gait messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__Gait__Sequence__copy(
  const drdds__msg__Gait__Sequence * input,
  drdds__msg__Gait__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__GAIT__FUNCTIONS_H_
