// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/CpuData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__CPU_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/cpu_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__traits.hpp"
// Member 'data'
#include "drdds/msg/detail/cpu_data_value__traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const CpuData & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: data
  {
    out << "data: ";
    to_flow_style_yaml(msg.data, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CpuData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: data
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "data:\n";
    to_block_style_yaml(msg.data, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CpuData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::CpuData & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::CpuData & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::CpuData>()
{
  return "drdds::msg::CpuData";
}

template<>
inline const char * name<drdds::msg::CpuData>()
{
  return "drdds/msg/CpuData";
}

template<>
struct has_fixed_size<drdds::msg::CpuData>
  : std::integral_constant<bool, has_fixed_size<drdds::msg::CpuDataValue>::value && has_fixed_size<drdds::msg::MetaType>::value> {};

template<>
struct has_bounded_size<drdds::msg::CpuData>
  : std::integral_constant<bool, has_bounded_size<drdds::msg::CpuDataValue>::value && has_bounded_size<drdds::msg::MetaType>::value> {};

template<>
struct is_message<drdds::msg::CpuData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__CPU_DATA__TRAITS_HPP_
