// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/GridsID.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/grids_id__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `path`
#include "rosidl_runtime_c/string_functions.h"
// Member `grids`
#include "drdds/msg/detail/grid_id__functions.h"

bool
drdds__msg__GridsID__init(drdds__msg__GridsID * msg)
{
  if (!msg) {
    return false;
  }
  // path
  if (!rosidl_runtime_c__String__init(&msg->path)) {
    drdds__msg__GridsID__fini(msg);
    return false;
  }
  // grids
  if (!drdds__msg__GridID__Sequence__init(&msg->grids, 0)) {
    drdds__msg__GridsID__fini(msg);
    return false;
  }
  return true;
}

void
drdds__msg__GridsID__fini(drdds__msg__GridsID * msg)
{
  if (!msg) {
    return;
  }
  // path
  rosidl_runtime_c__String__fini(&msg->path);
  // grids
  drdds__msg__GridID__Sequence__fini(&msg->grids);
}

bool
drdds__msg__GridsID__are_equal(const drdds__msg__GridsID * lhs, const drdds__msg__GridsID * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // path
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->path), &(rhs->path)))
  {
    return false;
  }
  // grids
  if (!drdds__msg__GridID__Sequence__are_equal(
      &(lhs->grids), &(rhs->grids)))
  {
    return false;
  }
  return true;
}

bool
drdds__msg__GridsID__copy(
  const drdds__msg__GridsID * input,
  drdds__msg__GridsID * output)
{
  if (!input || !output) {
    return false;
  }
  // path
  if (!rosidl_runtime_c__String__copy(
      &(input->path), &(output->path)))
  {
    return false;
  }
  // grids
  if (!drdds__msg__GridID__Sequence__copy(
      &(input->grids), &(output->grids)))
  {
    return false;
  }
  return true;
}

drdds__msg__GridsID *
drdds__msg__GridsID__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__GridsID * msg = (drdds__msg__GridsID *)allocator.allocate(sizeof(drdds__msg__GridsID), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__GridsID));
  bool success = drdds__msg__GridsID__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__GridsID__destroy(drdds__msg__GridsID * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__GridsID__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__GridsID__Sequence__init(drdds__msg__GridsID__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__GridsID * data = NULL;

  if (size) {
    data = (drdds__msg__GridsID *)allocator.zero_allocate(size, sizeof(drdds__msg__GridsID), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__GridsID__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__GridsID__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__GridsID__Sequence__fini(drdds__msg__GridsID__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__GridsID__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__GridsID__Sequence *
drdds__msg__GridsID__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__GridsID__Sequence * array = (drdds__msg__GridsID__Sequence *)allocator.allocate(sizeof(drdds__msg__GridsID__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__GridsID__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__GridsID__Sequence__destroy(drdds__msg__GridsID__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__GridsID__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__GridsID__Sequence__are_equal(const drdds__msg__GridsID__Sequence * lhs, const drdds__msg__GridsID__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__GridsID__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__GridsID__Sequence__copy(
  const drdds__msg__GridsID__Sequence * input,
  drdds__msg__GridsID__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__GridsID);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__GridsID * data =
      (drdds__msg__GridsID *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__GridsID__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__GridsID__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__GridsID__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
