// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from drdds:msg/JointData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_DATA__TYPE_SUPPORT_H_
#define DRDDS__MSG__DETAIL__JOINT_DATA__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "drdds/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  drdds,
  msg,
  JointData
)();

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__JOINT_DATA__TYPE_SUPPORT_H_
