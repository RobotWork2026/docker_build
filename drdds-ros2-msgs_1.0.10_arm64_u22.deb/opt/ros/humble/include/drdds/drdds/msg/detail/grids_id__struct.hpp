// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/GridsID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRIDS_ID__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__GRIDS_ID__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'grids'
#include "drdds/msg/detail/grid_id__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__drdds__msg__GridsID __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__GridsID __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GridsID_
{
  using Type = GridsID_<ContainerAllocator>;

  explicit GridsID_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->path = "";
    }
  }

  explicit GridsID_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : path(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->path = "";
    }
  }

  // field types and members
  using _path_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _path_type path;
  using _grids_type =
    std::vector<drdds::msg::GridID_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<drdds::msg::GridID_<ContainerAllocator>>>;
  _grids_type grids;

  // setters for named parameter idiom
  Type & set__path(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->path = _arg;
    return *this;
  }
  Type & set__grids(
    const std::vector<drdds::msg::GridID_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<drdds::msg::GridID_<ContainerAllocator>>> & _arg)
  {
    this->grids = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::GridsID_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::GridsID_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::GridsID_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::GridsID_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::GridsID_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::GridsID_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::GridsID_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::GridsID_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::GridsID_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::GridsID_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__GridsID
    std::shared_ptr<drdds::msg::GridsID_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__GridsID
    std::shared_ptr<drdds::msg::GridsID_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GridsID_ & other) const
  {
    if (this->path != other.path) {
      return false;
    }
    if (this->grids != other.grids) {
      return false;
    }
    return true;
  }
  bool operator!=(const GridsID_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GridsID_

// alias to use template instance with default allocator
using GridsID =
  drdds::msg::GridsID_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__GRIDS_ID__STRUCT_HPP_
