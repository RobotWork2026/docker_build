// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/Gait.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/gait__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "drdds/msg/detail/meta_type__functions.h"
// Member `data`
#include "drdds/msg/detail/gait_value__functions.h"

bool
drdds__msg__Gait__init(drdds__msg__Gait * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!drdds__msg__MetaType__init(&msg->header)) {
    drdds__msg__Gait__fini(msg);
    return false;
  }
  // data
  if (!drdds__msg__GaitValue__init(&msg->data)) {
    drdds__msg__Gait__fini(msg);
    return false;
  }
  return true;
}

void
drdds__msg__Gait__fini(drdds__msg__Gait * msg)
{
  if (!msg) {
    return;
  }
  // header
  drdds__msg__MetaType__fini(&msg->header);
  // data
  drdds__msg__GaitValue__fini(&msg->data);
}

bool
drdds__msg__Gait__are_equal(const drdds__msg__Gait * lhs, const drdds__msg__Gait * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!drdds__msg__MetaType__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // data
  if (!drdds__msg__GaitValue__are_equal(
      &(lhs->data), &(rhs->data)))
  {
    return false;
  }
  return true;
}

bool
drdds__msg__Gait__copy(
  const drdds__msg__Gait * input,
  drdds__msg__Gait * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!drdds__msg__MetaType__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // data
  if (!drdds__msg__GaitValue__copy(
      &(input->data), &(output->data)))
  {
    return false;
  }
  return true;
}

drdds__msg__Gait *
drdds__msg__Gait__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__Gait * msg = (drdds__msg__Gait *)allocator.allocate(sizeof(drdds__msg__Gait), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__Gait));
  bool success = drdds__msg__Gait__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__Gait__destroy(drdds__msg__Gait * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__Gait__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__Gait__Sequence__init(drdds__msg__Gait__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__Gait * data = NULL;

  if (size) {
    data = (drdds__msg__Gait *)allocator.zero_allocate(size, sizeof(drdds__msg__Gait), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__Gait__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__Gait__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__Gait__Sequence__fini(drdds__msg__Gait__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__Gait__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__Gait__Sequence *
drdds__msg__Gait__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__Gait__Sequence * array = (drdds__msg__Gait__Sequence *)allocator.allocate(sizeof(drdds__msg__Gait__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__Gait__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__Gait__Sequence__destroy(drdds__msg__Gait__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__Gait__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__Gait__Sequence__are_equal(const drdds__msg__Gait__Sequence * lhs, const drdds__msg__Gait__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__Gait__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__Gait__Sequence__copy(
  const drdds__msg__Gait__Sequence * input,
  drdds__msg__Gait__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__Gait);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__Gait * data =
      (drdds__msg__Gait *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__Gait__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__Gait__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__Gait__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
