// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/GridID.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GRID_ID__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__GRID_ID__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__drdds__msg__GridID __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__GridID __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GridID_
{
  using Type = GridID_<ContainerAllocator>;

  explicit GridID_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->id = 0l;
      this->name = "";
    }
  }

  explicit GridID_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->id = 0l;
      this->name = "";
    }
  }

  // field types and members
  using _id_type =
    int32_t;
  _id_type id;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;

  // setters for named parameter idiom
  Type & set__id(
    const int32_t & _arg)
  {
    this->id = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::GridID_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::GridID_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::GridID_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::GridID_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::GridID_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::GridID_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::GridID_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::GridID_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::GridID_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::GridID_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__GridID
    std::shared_ptr<drdds::msg::GridID_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__GridID
    std::shared_ptr<drdds::msg::GridID_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GridID_ & other) const
  {
    if (this->id != other.id) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    return true;
  }
  bool operator!=(const GridID_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GridID_

// alias to use template instance with default allocator
using GridID =
  drdds::msg::GridID_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__GRID_ID__STRUCT_HPP_
