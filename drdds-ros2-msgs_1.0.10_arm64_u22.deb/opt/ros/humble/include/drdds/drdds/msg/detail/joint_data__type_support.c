// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/JointData.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/joint_data__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/joint_data__functions.h"
#include "drdds/msg/detail/joint_data__struct.h"


#ifdef __cplusplus
extern "C"
{
#endif

void drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__JointData__init(message_memory);
}

void drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_fini_function(void * message_memory)
{
  drdds__msg__JointData__fini(message_memory);
}

size_t drdds__msg__JointData__rosidl_typesupport_introspection_c__size_function__JointData__name(
  const void * untyped_member)
{
  (void)untyped_member;
  return 4;
}

const void * drdds__msg__JointData__rosidl_typesupport_introspection_c__get_const_function__JointData__name(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * drdds__msg__JointData__rosidl_typesupport_introspection_c__get_function__JointData__name(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void drdds__msg__JointData__rosidl_typesupport_introspection_c__fetch_function__JointData__name(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    drdds__msg__JointData__rosidl_typesupport_introspection_c__get_const_function__JointData__name(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void drdds__msg__JointData__rosidl_typesupport_introspection_c__assign_function__JointData__name(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    drdds__msg__JointData__rosidl_typesupport_introspection_c__get_function__JointData__name(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_message_member_array[8] = {
  {
    "name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    4,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointData, name),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__JointData__rosidl_typesupport_introspection_c__size_function__JointData__name,  // size() function pointer
    drdds__msg__JointData__rosidl_typesupport_introspection_c__get_const_function__JointData__name,  // get_const(index) function pointer
    drdds__msg__JointData__rosidl_typesupport_introspection_c__get_function__JointData__name,  // get(index) function pointer
    drdds__msg__JointData__rosidl_typesupport_introspection_c__fetch_function__JointData__name,  // fetch(index, &value) function pointer
    drdds__msg__JointData__rosidl_typesupport_introspection_c__assign_function__JointData__name,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointData, data_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "status_word",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointData, status_word),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "position",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointData, position),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "torque",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointData, torque),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointData, velocity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "motion_temp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointData, motion_temp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "driver_temp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointData, driver_temp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_message_members = {
  "drdds__msg",  // message namespace
  "JointData",  // message name
  8,  // number of fields
  sizeof(drdds__msg__JointData),
  drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_message_member_array,  // message members
  drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_init_function,  // function to initialize message memory (memory has to be allocated)
  drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_message_type_support_handle = {
  0,
  &drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, JointData)() {
  if (!drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_message_type_support_handle.typesupport_identifier) {
    drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &drdds__msg__JointData__rosidl_typesupport_introspection_c__JointData_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
