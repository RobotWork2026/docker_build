// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/CpuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__CPU_DATA_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'cpu_temperature'
// Member 'cpu_frequency'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/CpuDataValue in the package drdds.
typedef struct drdds__msg__CpuDataValue
{
  rosidl_runtime_c__uint32__Sequence cpu_temperature;
  rosidl_runtime_c__uint32__Sequence cpu_frequency;
} drdds__msg__CpuDataValue;

// Struct for a sequence of drdds__msg__CpuDataValue.
typedef struct drdds__msg__CpuDataValue__Sequence
{
  drdds__msg__CpuDataValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__CpuDataValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__CPU_DATA_VALUE__STRUCT_H_
