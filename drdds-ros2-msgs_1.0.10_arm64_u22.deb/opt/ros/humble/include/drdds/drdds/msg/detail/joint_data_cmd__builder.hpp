// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/JointDataCmd.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_DATA_CMD__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__JOINT_DATA_CMD__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/joint_data_cmd__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_JointDataCmd_kd
{
public:
  explicit Init_JointDataCmd_kd(::drdds::msg::JointDataCmd & msg)
  : msg_(msg)
  {}
  ::drdds::msg::JointDataCmd kd(::drdds::msg::JointDataCmd::_kd_type arg)
  {
    msg_.kd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::JointDataCmd msg_;
};

class Init_JointDataCmd_kp
{
public:
  explicit Init_JointDataCmd_kp(::drdds::msg::JointDataCmd & msg)
  : msg_(msg)
  {}
  Init_JointDataCmd_kd kp(::drdds::msg::JointDataCmd::_kp_type arg)
  {
    msg_.kp = std::move(arg);
    return Init_JointDataCmd_kd(msg_);
  }

private:
  ::drdds::msg::JointDataCmd msg_;
};

class Init_JointDataCmd_velocity
{
public:
  explicit Init_JointDataCmd_velocity(::drdds::msg::JointDataCmd & msg)
  : msg_(msg)
  {}
  Init_JointDataCmd_kp velocity(::drdds::msg::JointDataCmd::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_JointDataCmd_kp(msg_);
  }

private:
  ::drdds::msg::JointDataCmd msg_;
};

class Init_JointDataCmd_torque
{
public:
  explicit Init_JointDataCmd_torque(::drdds::msg::JointDataCmd & msg)
  : msg_(msg)
  {}
  Init_JointDataCmd_velocity torque(::drdds::msg::JointDataCmd::_torque_type arg)
  {
    msg_.torque = std::move(arg);
    return Init_JointDataCmd_velocity(msg_);
  }

private:
  ::drdds::msg::JointDataCmd msg_;
};

class Init_JointDataCmd_position
{
public:
  explicit Init_JointDataCmd_position(::drdds::msg::JointDataCmd & msg)
  : msg_(msg)
  {}
  Init_JointDataCmd_torque position(::drdds::msg::JointDataCmd::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_JointDataCmd_torque(msg_);
  }

private:
  ::drdds::msg::JointDataCmd msg_;
};

class Init_JointDataCmd_control_word
{
public:
  explicit Init_JointDataCmd_control_word(::drdds::msg::JointDataCmd & msg)
  : msg_(msg)
  {}
  Init_JointDataCmd_position control_word(::drdds::msg::JointDataCmd::_control_word_type arg)
  {
    msg_.control_word = std::move(arg);
    return Init_JointDataCmd_position(msg_);
  }

private:
  ::drdds::msg::JointDataCmd msg_;
};

class Init_JointDataCmd_data_id
{
public:
  explicit Init_JointDataCmd_data_id(::drdds::msg::JointDataCmd & msg)
  : msg_(msg)
  {}
  Init_JointDataCmd_control_word data_id(::drdds::msg::JointDataCmd::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_JointDataCmd_control_word(msg_);
  }

private:
  ::drdds::msg::JointDataCmd msg_;
};

class Init_JointDataCmd_name
{
public:
  Init_JointDataCmd_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_JointDataCmd_data_id name(::drdds::msg::JointDataCmd::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_JointDataCmd_data_id(msg_);
  }

private:
  ::drdds::msg::JointDataCmd msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::JointDataCmd>()
{
  return drdds::msg::builder::Init_JointDataCmd_name();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__JOINT_DATA_CMD__BUILDER_HPP_
