// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__AIRY_LIDAR_STATUS_HPP_
#define DRDDS__MSG__AIRY_LIDAR_STATUS_HPP_

#include "drdds/msg/detail/airy_lidar_status__struct.hpp"
#include "drdds/msg/detail/airy_lidar_status__builder.hpp"
#include "drdds/msg/detail/airy_lidar_status__traits.hpp"
#include "drdds/msg/detail/airy_lidar_status__type_support.hpp"

#endif  // DRDDS__MSG__AIRY_LIDAR_STATUS_HPP_
