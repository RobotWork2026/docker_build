// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/FileSystemStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_H_
#define DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'soc_id'
// Member 'mount_point'
// Member 'device_path'
// Member 'fs_type'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/FileSystemStatus in the package drdds.
/**
  * FileSystemStatus.msg
 */
typedef struct drdds__msg__FileSystemStatus
{
  builtin_interfaces__msg__Time timestamp;
  /// SoC identifier (e.g., "CPU_103", "CPU_104")
  rosidl_runtime_c__String soc_id;
  /// Mount point path (e.g., "/root-ro", "/boot")
  rosidl_runtime_c__String mount_point;
  /// e.g., "/dev/mmcblk0p12"
  rosidl_runtime_c__String device_path;
  /// "ext4", "f2fs", etc.
  rosidl_runtime_c__String fs_type;
  /// Space usage
  uint64_t total_bytes;
  uint64_t used_bytes;
  uint64_t available_bytes;
  /// Inode usage (prevents "No space left on device" despite free space)
  uint64_t used_inodes;
  uint64_t free_inodes;
  bool is_readonly;
} drdds__msg__FileSystemStatus;

// Struct for a sequence of drdds__msg__FileSystemStatus.
typedef struct drdds__msg__FileSystemStatus__Sequence
{
  drdds__msg__FileSystemStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__FileSystemStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_H_
