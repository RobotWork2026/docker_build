// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/BatteryData.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/battery_data__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/battery_data__functions.h"
#include "drdds/msg/detail/battery_data__struct.h"


// Include directives for member types
// Member `header`
#include "drdds/msg/meta_type.h"
// Member `header`
#include "drdds/msg/detail/meta_type__rosidl_typesupport_introspection_c.h"
// Member `data`
#include "drdds/msg/battery_data_value.h"
// Member `data`
#include "drdds/msg/detail/battery_data_value__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__BatteryData__init(message_memory);
}

void drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_fini_function(void * message_memory)
{
  drdds__msg__BatteryData__fini(message_memory);
}

size_t drdds__msg__BatteryData__rosidl_typesupport_introspection_c__size_function__BatteryData__data(
  const void * untyped_member)
{
  const drdds__msg__BatteryDataValue__Sequence * member =
    (const drdds__msg__BatteryDataValue__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__BatteryData__rosidl_typesupport_introspection_c__get_const_function__BatteryData__data(
  const void * untyped_member, size_t index)
{
  const drdds__msg__BatteryDataValue__Sequence * member =
    (const drdds__msg__BatteryDataValue__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__BatteryData__rosidl_typesupport_introspection_c__get_function__BatteryData__data(
  void * untyped_member, size_t index)
{
  drdds__msg__BatteryDataValue__Sequence * member =
    (drdds__msg__BatteryDataValue__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__BatteryData__rosidl_typesupport_introspection_c__fetch_function__BatteryData__data(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const drdds__msg__BatteryDataValue * item =
    ((const drdds__msg__BatteryDataValue *)
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__get_const_function__BatteryData__data(untyped_member, index));
  drdds__msg__BatteryDataValue * value =
    (drdds__msg__BatteryDataValue *)(untyped_value);
  *value = *item;
}

void drdds__msg__BatteryData__rosidl_typesupport_introspection_c__assign_function__BatteryData__data(
  void * untyped_member, size_t index, const void * untyped_value)
{
  drdds__msg__BatteryDataValue * item =
    ((drdds__msg__BatteryDataValue *)
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__get_function__BatteryData__data(untyped_member, index));
  const drdds__msg__BatteryDataValue * value =
    (const drdds__msg__BatteryDataValue *)(untyped_value);
  *item = *value;
}

bool drdds__msg__BatteryData__rosidl_typesupport_introspection_c__resize_function__BatteryData__data(
  void * untyped_member, size_t size)
{
  drdds__msg__BatteryDataValue__Sequence * member =
    (drdds__msg__BatteryDataValue__Sequence *)(untyped_member);
  drdds__msg__BatteryDataValue__Sequence__fini(member);
  return drdds__msg__BatteryDataValue__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_member_array[2] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryData, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "data",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryData, data),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__size_function__BatteryData__data,  // size() function pointer
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__get_const_function__BatteryData__data,  // get_const(index) function pointer
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__get_function__BatteryData__data,  // get(index) function pointer
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__fetch_function__BatteryData__data,  // fetch(index, &value) function pointer
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__assign_function__BatteryData__data,  // assign(index, value) function pointer
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__resize_function__BatteryData__data  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_members = {
  "drdds__msg",  // message namespace
  "BatteryData",  // message name
  2,  // number of fields
  sizeof(drdds__msg__BatteryData),
  drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_member_array,  // message members
  drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_init_function,  // function to initialize message memory (memory has to be allocated)
  drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_type_support_handle = {
  0,
  &drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, BatteryData)() {
  drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, MetaType)();
  drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, BatteryDataValue)();
  if (!drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_type_support_handle.typesupport_identifier) {
    drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &drdds__msg__BatteryData__rosidl_typesupport_introspection_c__BatteryData_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
