// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/GaitValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__GAIT_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__GAIT_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/GaitValue in the package drdds.
typedef struct drdds__msg__GaitValue
{
  uint32_t gait;
} drdds__msg__GaitValue;

// Struct for a sequence of drdds__msg__GaitValue.
typedef struct drdds__msg__GaitValue__Sequence
{
  drdds__msg__GaitValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__GaitValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__GAIT_VALUE__STRUCT_H_
