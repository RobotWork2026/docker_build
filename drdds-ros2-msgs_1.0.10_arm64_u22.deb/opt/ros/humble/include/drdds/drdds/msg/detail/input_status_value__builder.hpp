// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/InputStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/input_status_value__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_InputStatusValue_reflective_strip
{
public:
  explicit Init_InputStatusValue_reflective_strip(::drdds::msg::InputStatusValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::InputStatusValue reflective_strip(::drdds::msg::InputStatusValue::_reflective_strip_type arg)
  {
    msg_.reflective_strip = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::InputStatusValue msg_;
};

class Init_InputStatusValue_tag
{
public:
  explicit Init_InputStatusValue_tag(::drdds::msg::InputStatusValue & msg)
  : msg_(msg)
  {}
  Init_InputStatusValue_reflective_strip tag(::drdds::msg::InputStatusValue::_tag_type arg)
  {
    msg_.tag = std::move(arg);
    return Init_InputStatusValue_reflective_strip(msg_);
  }

private:
  ::drdds::msg::InputStatusValue msg_;
};

class Init_InputStatusValue_rtk
{
public:
  explicit Init_InputStatusValue_rtk(::drdds::msg::InputStatusValue & msg)
  : msg_(msg)
  {}
  Init_InputStatusValue_tag rtk(::drdds::msg::InputStatusValue::_rtk_type arg)
  {
    msg_.rtk = std::move(arg);
    return Init_InputStatusValue_tag(msg_);
  }

private:
  ::drdds::msg::InputStatusValue msg_;
};

class Init_InputStatusValue_leg_odom
{
public:
  explicit Init_InputStatusValue_leg_odom(::drdds::msg::InputStatusValue & msg)
  : msg_(msg)
  {}
  Init_InputStatusValue_rtk leg_odom(::drdds::msg::InputStatusValue::_leg_odom_type arg)
  {
    msg_.leg_odom = std::move(arg);
    return Init_InputStatusValue_rtk(msg_);
  }

private:
  ::drdds::msg::InputStatusValue msg_;
};

class Init_InputStatusValue_imu
{
public:
  explicit Init_InputStatusValue_imu(::drdds::msg::InputStatusValue & msg)
  : msg_(msg)
  {}
  Init_InputStatusValue_leg_odom imu(::drdds::msg::InputStatusValue::_imu_type arg)
  {
    msg_.imu = std::move(arg);
    return Init_InputStatusValue_leg_odom(msg_);
  }

private:
  ::drdds::msg::InputStatusValue msg_;
};

class Init_InputStatusValue_lidar
{
public:
  Init_InputStatusValue_lidar()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_InputStatusValue_imu lidar(::drdds::msg::InputStatusValue::_lidar_type arg)
  {
    msg_.lidar = std::move(arg);
    return Init_InputStatusValue_imu(msg_);
  }

private:
  ::drdds::msg::InputStatusValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::InputStatusValue>()
{
  return drdds::msg::builder::Init_InputStatusValue_lidar();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__BUILDER_HPP_
