// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/JointCmdValue.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/joint_cmd_value__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/joint_cmd_value__functions.h"
#include "drdds/msg/detail/joint_cmd_value__struct.h"


// Include directives for member types
// Member `name`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__JointCmdValue__init(message_memory);
}

void drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_fini_function(void * message_memory)
{
  drdds__msg__JointCmdValue__fini(message_memory);
}

size_t drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__size_function__JointCmdValue__name(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__get_const_function__JointCmdValue__name(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint8__Sequence * member =
    (const rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__get_function__JointCmdValue__name(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__fetch_function__JointCmdValue__name(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__get_const_function__JointCmdValue__name(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__assign_function__JointCmdValue__name(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__get_function__JointCmdValue__name(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

bool drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__resize_function__JointCmdValue__name(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint8__Sequence * member =
    (rosidl_runtime_c__uint8__Sequence *)(untyped_member);
  rosidl_runtime_c__uint8__Sequence__fini(member);
  return rosidl_runtime_c__uint8__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_message_member_array[8] = {
  {
    "name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointCmdValue, name),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__size_function__JointCmdValue__name,  // size() function pointer
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__get_const_function__JointCmdValue__name,  // get_const(index) function pointer
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__get_function__JointCmdValue__name,  // get(index) function pointer
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__fetch_function__JointCmdValue__name,  // fetch(index, &value) function pointer
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__assign_function__JointCmdValue__name,  // assign(index, value) function pointer
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__resize_function__JointCmdValue__name  // resize(index) function pointer
  },
  {
    "data_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointCmdValue, data_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "control_word",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointCmdValue, control_word),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "position",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointCmdValue, position),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "torque",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointCmdValue, torque),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointCmdValue, velocity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "kp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointCmdValue, kp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "kd",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__JointCmdValue, kd),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_message_members = {
  "drdds__msg",  // message namespace
  "JointCmdValue",  // message name
  8,  // number of fields
  sizeof(drdds__msg__JointCmdValue),
  drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_message_member_array,  // message members
  drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_init_function,  // function to initialize message memory (memory has to be allocated)
  drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_message_type_support_handle = {
  0,
  &drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, JointCmdValue)() {
  if (!drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_message_type_support_handle.typesupport_identifier) {
    drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &drdds__msg__JointCmdValue__rosidl_typesupport_introspection_c__JointCmdValue_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
