// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/battery_data_value__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/battery_data_value__functions.h"
#include "drdds/msg/detail/battery_data_value__struct.h"


// Include directives for member types
// Member `battery_temperature`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__BatteryDataValue__init(message_memory);
}

void drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_fini_function(void * message_memory)
{
  drdds__msg__BatteryDataValue__fini(message_memory);
}

size_t drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__size_function__BatteryDataValue__battery_temperature(
  const void * untyped_member)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_const_function__BatteryDataValue__battery_temperature(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__float__Sequence * member =
    (const rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_function__BatteryDataValue__battery_temperature(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__fetch_function__BatteryDataValue__battery_temperature(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const float * item =
    ((const float *)
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_const_function__BatteryDataValue__battery_temperature(untyped_member, index));
  float * value =
    (float *)(untyped_value);
  *value = *item;
}

void drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__assign_function__BatteryDataValue__battery_temperature(
  void * untyped_member, size_t index, const void * untyped_value)
{
  float * item =
    ((float *)
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_function__BatteryDataValue__battery_temperature(untyped_member, index));
  const float * value =
    (const float *)(untyped_value);
  *item = *value;
}

bool drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__resize_function__BatteryDataValue__battery_temperature(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__float__Sequence * member =
    (rosidl_runtime_c__float__Sequence *)(untyped_member);
  rosidl_runtime_c__float__Sequence__fini(member);
  return rosidl_runtime_c__float__Sequence__init(member, size);
}

size_t drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__size_function__BatteryDataValue__battery_serialnum(
  const void * untyped_member)
{
  (void)untyped_member;
  return 32;
}

const void * drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_const_function__BatteryDataValue__battery_serialnum(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_function__BatteryDataValue__battery_serialnum(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__fetch_function__BatteryDataValue__battery_serialnum(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_const_function__BatteryDataValue__battery_serialnum(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__assign_function__BatteryDataValue__battery_serialnum(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_function__BatteryDataValue__battery_serialnum(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_message_member_array[16] = {
  {
    "voltage",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, voltage),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "current",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, current),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "remaining_capacity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, remaining_capacity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "nominal_capacity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, nominal_capacity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "cycles",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, cycles),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "production_date",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, production_date),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "balanced_low",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, balanced_low),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "balanced_high",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, balanced_high),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "protected_state",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, protected_state),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "software_version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, software_version),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_level",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, battery_level),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "mos_state",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, mos_state),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_quantity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, battery_quantity),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_ntc",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, battery_ntc),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "battery_temperature",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_FLOAT,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, battery_temperature),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__size_function__BatteryDataValue__battery_temperature,  // size() function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_const_function__BatteryDataValue__battery_temperature,  // get_const(index) function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_function__BatteryDataValue__battery_temperature,  // get(index) function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__fetch_function__BatteryDataValue__battery_temperature,  // fetch(index, &value) function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__assign_function__BatteryDataValue__battery_temperature,  // assign(index, value) function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__resize_function__BatteryDataValue__battery_temperature  // resize(index) function pointer
  },
  {
    "battery_serialnum",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    32,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__BatteryDataValue, battery_serialnum),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__size_function__BatteryDataValue__battery_serialnum,  // size() function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_const_function__BatteryDataValue__battery_serialnum,  // get_const(index) function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__get_function__BatteryDataValue__battery_serialnum,  // get(index) function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__fetch_function__BatteryDataValue__battery_serialnum,  // fetch(index, &value) function pointer
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__assign_function__BatteryDataValue__battery_serialnum,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_message_members = {
  "drdds__msg",  // message namespace
  "BatteryDataValue",  // message name
  16,  // number of fields
  sizeof(drdds__msg__BatteryDataValue),
  drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_message_member_array,  // message members
  drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_init_function,  // function to initialize message memory (memory has to be allocated)
  drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_message_type_support_handle = {
  0,
  &drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, BatteryDataValue)() {
  if (!drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_message_type_support_handle.typesupport_identifier) {
    drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &drdds__msg__BatteryDataValue__rosidl_typesupport_introspection_c__BatteryDataValue_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
