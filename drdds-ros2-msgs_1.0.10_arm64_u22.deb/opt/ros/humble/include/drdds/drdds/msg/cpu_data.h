// generated from rosidl_generator_c/resource/idl.h.em
// with input from drdds:msg/CpuData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__CPU_DATA_H_
#define DRDDS__MSG__CPU_DATA_H_

#include "drdds/msg/detail/cpu_data__struct.h"
#include "drdds/msg/detail/cpu_data__functions.h"
#include "drdds/msg/detail/cpu_data__type_support.h"

#endif  // DRDDS__MSG__CPU_DATA_H_
