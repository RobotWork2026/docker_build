// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/CPUStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_STATUS__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__CPU_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/cpu_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_CPUStatus_gov_policy
{
public:
  explicit Init_CPUStatus_gov_policy(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  ::drdds::msg::CPUStatus gov_policy(::drdds::msg::CPUStatus::_gov_policy_type arg)
  {
    msg_.gov_policy = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_hw_min_freq_khz
{
public:
  explicit Init_CPUStatus_hw_min_freq_khz(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  Init_CPUStatus_gov_policy hw_min_freq_khz(::drdds::msg::CPUStatus::_hw_min_freq_khz_type arg)
  {
    msg_.hw_min_freq_khz = std::move(arg);
    return Init_CPUStatus_gov_policy(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_hw_max_freq_khz
{
public:
  explicit Init_CPUStatus_hw_max_freq_khz(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  Init_CPUStatus_hw_min_freq_khz hw_max_freq_khz(::drdds::msg::CPUStatus::_hw_max_freq_khz_type arg)
  {
    msg_.hw_max_freq_khz = std::move(arg);
    return Init_CPUStatus_hw_min_freq_khz(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_cur_freq_khz
{
public:
  explicit Init_CPUStatus_cur_freq_khz(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  Init_CPUStatus_hw_max_freq_khz cur_freq_khz(::drdds::msg::CPUStatus::_cur_freq_khz_type arg)
  {
    msg_.cur_freq_khz = std::move(arg);
    return Init_CPUStatus_hw_max_freq_khz(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_util
{
public:
  explicit Init_CPUStatus_util(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  Init_CPUStatus_cur_freq_khz util(::drdds::msg::CPUStatus::_util_type arg)
  {
    msg_.util = std::move(arg);
    return Init_CPUStatus_cur_freq_khz(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_avg_util
{
public:
  explicit Init_CPUStatus_avg_util(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  Init_CPUStatus_util avg_util(::drdds::msg::CPUStatus::_avg_util_type arg)
  {
    msg_.avg_util = std::move(arg);
    return Init_CPUStatus_util(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_temps
{
public:
  explicit Init_CPUStatus_temps(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  Init_CPUStatus_avg_util temps(::drdds::msg::CPUStatus::_temps_type arg)
  {
    msg_.temps = std::move(arg);
    return Init_CPUStatus_avg_util(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_package_temp
{
public:
  explicit Init_CPUStatus_package_temp(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  Init_CPUStatus_temps package_temp(::drdds::msg::CPUStatus::_package_temp_type arg)
  {
    msg_.package_temp = std::move(arg);
    return Init_CPUStatus_temps(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_soc_id
{
public:
  explicit Init_CPUStatus_soc_id(::drdds::msg::CPUStatus & msg)
  : msg_(msg)
  {}
  Init_CPUStatus_package_temp soc_id(::drdds::msg::CPUStatus::_soc_id_type arg)
  {
    msg_.soc_id = std::move(arg);
    return Init_CPUStatus_package_temp(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

class Init_CPUStatus_timestamp
{
public:
  Init_CPUStatus_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CPUStatus_soc_id timestamp(::drdds::msg::CPUStatus::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_CPUStatus_soc_id(msg_);
  }

private:
  ::drdds::msg::CPUStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::CPUStatus>()
{
  return drdds::msg::builder::Init_CPUStatus_timestamp();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__CPU_STATUS__BUILDER_HPP_
