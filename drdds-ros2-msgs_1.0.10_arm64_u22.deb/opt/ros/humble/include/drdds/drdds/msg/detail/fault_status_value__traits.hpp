// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/FaultStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/fault_status_value__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const FaultStatusValue & msg,
  std::ostream & out)
{
  out << "{";
  // member: imu_error
  {
    out << "imu_error: ";
    rosidl_generator_traits::value_to_yaml(msg.imu_error, out);
    out << ", ";
  }

  // member: wifi_error
  {
    out << "wifi_error: ";
    rosidl_generator_traits::value_to_yaml(msg.wifi_error, out);
    out << ", ";
  }

  // member: driver_heat_warn
  {
    out << "driver_heat_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.driver_heat_warn, out);
    out << ", ";
  }

  // member: driver_heat_error
  {
    out << "driver_heat_error: ";
    rosidl_generator_traits::value_to_yaml(msg.driver_heat_error, out);
    out << ", ";
  }

  // member: motor_heat_warn
  {
    out << "motor_heat_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.motor_heat_warn, out);
    out << ", ";
  }

  // member: motor_heat_error
  {
    out << "motor_heat_error: ";
    rosidl_generator_traits::value_to_yaml(msg.motor_heat_error, out);
    out << ", ";
  }

  // member: battery_low_warn
  {
    out << "battery_low_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_low_warn, out);
    out << ", ";
  }

  // member: battery_low_error
  {
    out << "battery_low_error: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_low_error, out);
    out << ", ";
  }

  // member: battery_voltage_warn
  {
    out << "battery_voltage_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_voltage_warn, out);
    out << ", ";
  }

  // member: battery_voltage_error
  {
    out << "battery_voltage_error: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_voltage_error, out);
    out << ", ";
  }

  // member: battery_heat_warn
  {
    out << "battery_heat_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_heat_warn, out);
    out << ", ";
  }

  // member: battery_heat_error
  {
    out << "battery_heat_error: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_heat_error, out);
    out << ", ";
  }

  // member: cpu_heat_warn
  {
    out << "cpu_heat_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.cpu_heat_warn, out);
    out << ", ";
  }

  // member: cpu_freq_warn
  {
    out << "cpu_freq_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.cpu_freq_warn, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const FaultStatusValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: imu_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "imu_error: ";
    rosidl_generator_traits::value_to_yaml(msg.imu_error, out);
    out << "\n";
  }

  // member: wifi_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wifi_error: ";
    rosidl_generator_traits::value_to_yaml(msg.wifi_error, out);
    out << "\n";
  }

  // member: driver_heat_warn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "driver_heat_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.driver_heat_warn, out);
    out << "\n";
  }

  // member: driver_heat_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "driver_heat_error: ";
    rosidl_generator_traits::value_to_yaml(msg.driver_heat_error, out);
    out << "\n";
  }

  // member: motor_heat_warn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motor_heat_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.motor_heat_warn, out);
    out << "\n";
  }

  // member: motor_heat_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motor_heat_error: ";
    rosidl_generator_traits::value_to_yaml(msg.motor_heat_error, out);
    out << "\n";
  }

  // member: battery_low_warn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_low_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_low_warn, out);
    out << "\n";
  }

  // member: battery_low_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_low_error: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_low_error, out);
    out << "\n";
  }

  // member: battery_voltage_warn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_voltage_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_voltage_warn, out);
    out << "\n";
  }

  // member: battery_voltage_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_voltage_error: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_voltage_error, out);
    out << "\n";
  }

  // member: battery_heat_warn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_heat_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_heat_warn, out);
    out << "\n";
  }

  // member: battery_heat_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_heat_error: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_heat_error, out);
    out << "\n";
  }

  // member: cpu_heat_warn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cpu_heat_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.cpu_heat_warn, out);
    out << "\n";
  }

  // member: cpu_freq_warn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cpu_freq_warn: ";
    rosidl_generator_traits::value_to_yaml(msg.cpu_freq_warn, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const FaultStatusValue & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::FaultStatusValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::FaultStatusValue & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::FaultStatusValue>()
{
  return "drdds::msg::FaultStatusValue";
}

template<>
inline const char * name<drdds::msg::FaultStatusValue>()
{
  return "drdds/msg/FaultStatusValue";
}

template<>
struct has_fixed_size<drdds::msg::FaultStatusValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::FaultStatusValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::FaultStatusValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__FAULT_STATUS_VALUE__TRAITS_HPP_
