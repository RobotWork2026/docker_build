// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/FileSystemStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__drdds__msg__FileSystemStatus __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__FileSystemStatus __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct FileSystemStatus_
{
  using Type = FileSystemStatus_<ContainerAllocator>;

  explicit FileSystemStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->soc_id = "";
      this->mount_point = "";
      this->device_path = "";
      this->fs_type = "";
      this->total_bytes = 0ull;
      this->used_bytes = 0ull;
      this->available_bytes = 0ull;
      this->used_inodes = 0ull;
      this->free_inodes = 0ull;
      this->is_readonly = false;
    }
  }

  explicit FileSystemStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init),
    soc_id(_alloc),
    mount_point(_alloc),
    device_path(_alloc),
    fs_type(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->soc_id = "";
      this->mount_point = "";
      this->device_path = "";
      this->fs_type = "";
      this->total_bytes = 0ull;
      this->used_bytes = 0ull;
      this->available_bytes = 0ull;
      this->used_inodes = 0ull;
      this->free_inodes = 0ull;
      this->is_readonly = false;
    }
  }

  // field types and members
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;
  using _soc_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _soc_id_type soc_id;
  using _mount_point_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _mount_point_type mount_point;
  using _device_path_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _device_path_type device_path;
  using _fs_type_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _fs_type_type fs_type;
  using _total_bytes_type =
    uint64_t;
  _total_bytes_type total_bytes;
  using _used_bytes_type =
    uint64_t;
  _used_bytes_type used_bytes;
  using _available_bytes_type =
    uint64_t;
  _available_bytes_type available_bytes;
  using _used_inodes_type =
    uint64_t;
  _used_inodes_type used_inodes;
  using _free_inodes_type =
    uint64_t;
  _free_inodes_type free_inodes;
  using _is_readonly_type =
    bool;
  _is_readonly_type is_readonly;

  // setters for named parameter idiom
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__soc_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->soc_id = _arg;
    return *this;
  }
  Type & set__mount_point(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->mount_point = _arg;
    return *this;
  }
  Type & set__device_path(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->device_path = _arg;
    return *this;
  }
  Type & set__fs_type(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->fs_type = _arg;
    return *this;
  }
  Type & set__total_bytes(
    const uint64_t & _arg)
  {
    this->total_bytes = _arg;
    return *this;
  }
  Type & set__used_bytes(
    const uint64_t & _arg)
  {
    this->used_bytes = _arg;
    return *this;
  }
  Type & set__available_bytes(
    const uint64_t & _arg)
  {
    this->available_bytes = _arg;
    return *this;
  }
  Type & set__used_inodes(
    const uint64_t & _arg)
  {
    this->used_inodes = _arg;
    return *this;
  }
  Type & set__free_inodes(
    const uint64_t & _arg)
  {
    this->free_inodes = _arg;
    return *this;
  }
  Type & set__is_readonly(
    const bool & _arg)
  {
    this->is_readonly = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::FileSystemStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::FileSystemStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::FileSystemStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::FileSystemStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::FileSystemStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::FileSystemStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::FileSystemStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::FileSystemStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::FileSystemStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::FileSystemStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__FileSystemStatus
    std::shared_ptr<drdds::msg::FileSystemStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__FileSystemStatus
    std::shared_ptr<drdds::msg::FileSystemStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FileSystemStatus_ & other) const
  {
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->soc_id != other.soc_id) {
      return false;
    }
    if (this->mount_point != other.mount_point) {
      return false;
    }
    if (this->device_path != other.device_path) {
      return false;
    }
    if (this->fs_type != other.fs_type) {
      return false;
    }
    if (this->total_bytes != other.total_bytes) {
      return false;
    }
    if (this->used_bytes != other.used_bytes) {
      return false;
    }
    if (this->available_bytes != other.available_bytes) {
      return false;
    }
    if (this->used_inodes != other.used_inodes) {
      return false;
    }
    if (this->free_inodes != other.free_inodes) {
      return false;
    }
    if (this->is_readonly != other.is_readonly) {
      return false;
    }
    return true;
  }
  bool operator!=(const FileSystemStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FileSystemStatus_

// alias to use template instance with default allocator
using FileSystemStatus =
  drdds::msg::FileSystemStatus_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__STRUCT_HPP_
