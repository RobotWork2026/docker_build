// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from drdds:msg/CPUStatus.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "drdds/msg/detail/cpu_status__rosidl_typesupport_introspection_c.h"
#include "drdds/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "drdds/msg/detail/cpu_status__functions.h"
#include "drdds/msg/detail/cpu_status__struct.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/time.h"
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__rosidl_typesupport_introspection_c.h"
// Member `soc_id`
// Member `gov_policy`
#include "rosidl_runtime_c/string_functions.h"
// Member `temps`
// Member `util`
// Member `cur_freq_khz`
// Member `hw_max_freq_khz`
// Member `hw_min_freq_khz`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  drdds__msg__CPUStatus__init(message_memory);
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_fini_function(void * message_memory)
{
  drdds__msg__CPUStatus__fini(message_memory);
}

size_t drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__temps(
  const void * untyped_member)
{
  const rosidl_runtime_c__int32__Sequence * member =
    (const rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__temps(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__int32__Sequence * member =
    (const rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__temps(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__int32__Sequence * member =
    (rosidl_runtime_c__int32__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__temps(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const int32_t * item =
    ((const int32_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__temps(untyped_member, index));
  int32_t * value =
    (int32_t *)(untyped_value);
  *value = *item;
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__temps(
  void * untyped_member, size_t index, const void * untyped_value)
{
  int32_t * item =
    ((int32_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__temps(untyped_member, index));
  const int32_t * value =
    (const int32_t *)(untyped_value);
  *item = *value;
}

bool drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__temps(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__int32__Sequence * member =
    (rosidl_runtime_c__int32__Sequence *)(untyped_member);
  rosidl_runtime_c__int32__Sequence__fini(member);
  return rosidl_runtime_c__int32__Sequence__init(member, size);
}

size_t drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__util(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__util(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint16__Sequence * member =
    (const rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__util(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__util(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint16_t * item =
    ((const uint16_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__util(untyped_member, index));
  uint16_t * value =
    (uint16_t *)(untyped_value);
  *value = *item;
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__util(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint16_t * item =
    ((uint16_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__util(untyped_member, index));
  const uint16_t * value =
    (const uint16_t *)(untyped_value);
  *item = *value;
}

bool drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__util(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint16__Sequence * member =
    (rosidl_runtime_c__uint16__Sequence *)(untyped_member);
  rosidl_runtime_c__uint16__Sequence__fini(member);
  return rosidl_runtime_c__uint16__Sequence__init(member, size);
}

size_t drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__cur_freq_khz(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__cur_freq_khz(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__cur_freq_khz(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__cur_freq_khz(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint32_t * item =
    ((const uint32_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__cur_freq_khz(untyped_member, index));
  uint32_t * value =
    (uint32_t *)(untyped_value);
  *value = *item;
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__cur_freq_khz(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint32_t * item =
    ((uint32_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__cur_freq_khz(untyped_member, index));
  const uint32_t * value =
    (const uint32_t *)(untyped_value);
  *item = *value;
}

bool drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__cur_freq_khz(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  rosidl_runtime_c__uint32__Sequence__fini(member);
  return rosidl_runtime_c__uint32__Sequence__init(member, size);
}

size_t drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__hw_max_freq_khz(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__hw_max_freq_khz(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__hw_max_freq_khz(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__hw_max_freq_khz(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint32_t * item =
    ((const uint32_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__hw_max_freq_khz(untyped_member, index));
  uint32_t * value =
    (uint32_t *)(untyped_value);
  *value = *item;
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__hw_max_freq_khz(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint32_t * item =
    ((uint32_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__hw_max_freq_khz(untyped_member, index));
  const uint32_t * value =
    (const uint32_t *)(untyped_value);
  *item = *value;
}

bool drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__hw_max_freq_khz(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  rosidl_runtime_c__uint32__Sequence__fini(member);
  return rosidl_runtime_c__uint32__Sequence__init(member, size);
}

size_t drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__hw_min_freq_khz(
  const void * untyped_member)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__hw_min_freq_khz(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__uint32__Sequence * member =
    (const rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__hw_min_freq_khz(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__hw_min_freq_khz(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint32_t * item =
    ((const uint32_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__hw_min_freq_khz(untyped_member, index));
  uint32_t * value =
    (uint32_t *)(untyped_value);
  *value = *item;
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__hw_min_freq_khz(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint32_t * item =
    ((uint32_t *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__hw_min_freq_khz(untyped_member, index));
  const uint32_t * value =
    (const uint32_t *)(untyped_value);
  *item = *value;
}

bool drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__hw_min_freq_khz(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__uint32__Sequence * member =
    (rosidl_runtime_c__uint32__Sequence *)(untyped_member);
  rosidl_runtime_c__uint32__Sequence__fini(member);
  return rosidl_runtime_c__uint32__Sequence__init(member, size);
}

size_t drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__gov_policy(
  const void * untyped_member)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return member->size;
}

const void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__gov_policy(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void * drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__gov_policy(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__gov_policy(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const rosidl_runtime_c__String * item =
    ((const rosidl_runtime_c__String *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__gov_policy(untyped_member, index));
  rosidl_runtime_c__String * value =
    (rosidl_runtime_c__String *)(untyped_value);
  *value = *item;
}

void drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__gov_policy(
  void * untyped_member, size_t index, const void * untyped_value)
{
  rosidl_runtime_c__String * item =
    ((rosidl_runtime_c__String *)
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__gov_policy(untyped_member, index));
  const rosidl_runtime_c__String * value =
    (const rosidl_runtime_c__String *)(untyped_value);
  *item = *value;
}

bool drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__gov_policy(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  rosidl_runtime_c__String__Sequence__fini(member);
  return rosidl_runtime_c__String__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_member_array[10] = {
  {
    "timestamp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, timestamp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "soc_id",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, soc_id),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "package_temp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, package_temp),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "temps",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, temps),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__temps,  // size() function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__temps,  // get_const(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__temps,  // get(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__temps,  // fetch(index, &value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__temps,  // assign(index, value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__temps  // resize(index) function pointer
  },
  {
    "avg_util",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, avg_util),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "util",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT16,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, util),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__util,  // size() function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__util,  // get_const(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__util,  // get(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__util,  // fetch(index, &value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__util,  // assign(index, value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__util  // resize(index) function pointer
  },
  {
    "cur_freq_khz",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, cur_freq_khz),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__cur_freq_khz,  // size() function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__cur_freq_khz,  // get_const(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__cur_freq_khz,  // get(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__cur_freq_khz,  // fetch(index, &value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__cur_freq_khz,  // assign(index, value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__cur_freq_khz  // resize(index) function pointer
  },
  {
    "hw_max_freq_khz",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, hw_max_freq_khz),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__hw_max_freq_khz,  // size() function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__hw_max_freq_khz,  // get_const(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__hw_max_freq_khz,  // get(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__hw_max_freq_khz,  // fetch(index, &value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__hw_max_freq_khz,  // assign(index, value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__hw_max_freq_khz  // resize(index) function pointer
  },
  {
    "hw_min_freq_khz",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, hw_min_freq_khz),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__hw_min_freq_khz,  // size() function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__hw_min_freq_khz,  // get_const(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__hw_min_freq_khz,  // get(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__hw_min_freq_khz,  // fetch(index, &value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__hw_min_freq_khz,  // assign(index, value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__hw_min_freq_khz  // resize(index) function pointer
  },
  {
    "gov_policy",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(drdds__msg__CPUStatus, gov_policy),  // bytes offset in struct
    NULL,  // default value
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__size_function__CPUStatus__gov_policy,  // size() function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_const_function__CPUStatus__gov_policy,  // get_const(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__get_function__CPUStatus__gov_policy,  // get(index) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__fetch_function__CPUStatus__gov_policy,  // fetch(index, &value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__assign_function__CPUStatus__gov_policy,  // assign(index, value) function pointer
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__resize_function__CPUStatus__gov_policy  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_members = {
  "drdds__msg",  // message namespace
  "CPUStatus",  // message name
  10,  // number of fields
  sizeof(drdds__msg__CPUStatus),
  drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_member_array,  // message members
  drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_init_function,  // function to initialize message memory (memory has to be allocated)
  drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_type_support_handle = {
  0,
  &drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_drdds
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, drdds, msg, CPUStatus)() {
  drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, builtin_interfaces, msg, Time)();
  if (!drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_type_support_handle.typesupport_identifier) {
    drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &drdds__msg__CPUStatus__rosidl_typesupport_introspection_c__CPUStatus_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
