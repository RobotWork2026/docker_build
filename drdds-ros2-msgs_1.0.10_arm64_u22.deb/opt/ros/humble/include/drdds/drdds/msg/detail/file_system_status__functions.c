// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/FileSystemStatus.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/file_system_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__functions.h"
// Member `soc_id`
// Member `mount_point`
// Member `device_path`
// Member `fs_type`
#include "rosidl_runtime_c/string_functions.h"

bool
drdds__msg__FileSystemStatus__init(drdds__msg__FileSystemStatus * msg)
{
  if (!msg) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__init(&msg->timestamp)) {
    drdds__msg__FileSystemStatus__fini(msg);
    return false;
  }
  // soc_id
  if (!rosidl_runtime_c__String__init(&msg->soc_id)) {
    drdds__msg__FileSystemStatus__fini(msg);
    return false;
  }
  // mount_point
  if (!rosidl_runtime_c__String__init(&msg->mount_point)) {
    drdds__msg__FileSystemStatus__fini(msg);
    return false;
  }
  // device_path
  if (!rosidl_runtime_c__String__init(&msg->device_path)) {
    drdds__msg__FileSystemStatus__fini(msg);
    return false;
  }
  // fs_type
  if (!rosidl_runtime_c__String__init(&msg->fs_type)) {
    drdds__msg__FileSystemStatus__fini(msg);
    return false;
  }
  // total_bytes
  // used_bytes
  // available_bytes
  // used_inodes
  // free_inodes
  // is_readonly
  return true;
}

void
drdds__msg__FileSystemStatus__fini(drdds__msg__FileSystemStatus * msg)
{
  if (!msg) {
    return;
  }
  // timestamp
  builtin_interfaces__msg__Time__fini(&msg->timestamp);
  // soc_id
  rosidl_runtime_c__String__fini(&msg->soc_id);
  // mount_point
  rosidl_runtime_c__String__fini(&msg->mount_point);
  // device_path
  rosidl_runtime_c__String__fini(&msg->device_path);
  // fs_type
  rosidl_runtime_c__String__fini(&msg->fs_type);
  // total_bytes
  // used_bytes
  // available_bytes
  // used_inodes
  // free_inodes
  // is_readonly
}

bool
drdds__msg__FileSystemStatus__are_equal(const drdds__msg__FileSystemStatus * lhs, const drdds__msg__FileSystemStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->timestamp), &(rhs->timestamp)))
  {
    return false;
  }
  // soc_id
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->soc_id), &(rhs->soc_id)))
  {
    return false;
  }
  // mount_point
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->mount_point), &(rhs->mount_point)))
  {
    return false;
  }
  // device_path
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->device_path), &(rhs->device_path)))
  {
    return false;
  }
  // fs_type
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->fs_type), &(rhs->fs_type)))
  {
    return false;
  }
  // total_bytes
  if (lhs->total_bytes != rhs->total_bytes) {
    return false;
  }
  // used_bytes
  if (lhs->used_bytes != rhs->used_bytes) {
    return false;
  }
  // available_bytes
  if (lhs->available_bytes != rhs->available_bytes) {
    return false;
  }
  // used_inodes
  if (lhs->used_inodes != rhs->used_inodes) {
    return false;
  }
  // free_inodes
  if (lhs->free_inodes != rhs->free_inodes) {
    return false;
  }
  // is_readonly
  if (lhs->is_readonly != rhs->is_readonly) {
    return false;
  }
  return true;
}

bool
drdds__msg__FileSystemStatus__copy(
  const drdds__msg__FileSystemStatus * input,
  drdds__msg__FileSystemStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->timestamp), &(output->timestamp)))
  {
    return false;
  }
  // soc_id
  if (!rosidl_runtime_c__String__copy(
      &(input->soc_id), &(output->soc_id)))
  {
    return false;
  }
  // mount_point
  if (!rosidl_runtime_c__String__copy(
      &(input->mount_point), &(output->mount_point)))
  {
    return false;
  }
  // device_path
  if (!rosidl_runtime_c__String__copy(
      &(input->device_path), &(output->device_path)))
  {
    return false;
  }
  // fs_type
  if (!rosidl_runtime_c__String__copy(
      &(input->fs_type), &(output->fs_type)))
  {
    return false;
  }
  // total_bytes
  output->total_bytes = input->total_bytes;
  // used_bytes
  output->used_bytes = input->used_bytes;
  // available_bytes
  output->available_bytes = input->available_bytes;
  // used_inodes
  output->used_inodes = input->used_inodes;
  // free_inodes
  output->free_inodes = input->free_inodes;
  // is_readonly
  output->is_readonly = input->is_readonly;
  return true;
}

drdds__msg__FileSystemStatus *
drdds__msg__FileSystemStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FileSystemStatus * msg = (drdds__msg__FileSystemStatus *)allocator.allocate(sizeof(drdds__msg__FileSystemStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__FileSystemStatus));
  bool success = drdds__msg__FileSystemStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__FileSystemStatus__destroy(drdds__msg__FileSystemStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__FileSystemStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__FileSystemStatus__Sequence__init(drdds__msg__FileSystemStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FileSystemStatus * data = NULL;

  if (size) {
    data = (drdds__msg__FileSystemStatus *)allocator.zero_allocate(size, sizeof(drdds__msg__FileSystemStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__FileSystemStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__FileSystemStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__FileSystemStatus__Sequence__fini(drdds__msg__FileSystemStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__FileSystemStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__FileSystemStatus__Sequence *
drdds__msg__FileSystemStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FileSystemStatus__Sequence * array = (drdds__msg__FileSystemStatus__Sequence *)allocator.allocate(sizeof(drdds__msg__FileSystemStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__FileSystemStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__FileSystemStatus__Sequence__destroy(drdds__msg__FileSystemStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__FileSystemStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__FileSystemStatus__Sequence__are_equal(const drdds__msg__FileSystemStatus__Sequence * lhs, const drdds__msg__FileSystemStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__FileSystemStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__FileSystemStatus__Sequence__copy(
  const drdds__msg__FileSystemStatus__Sequence * input,
  drdds__msg__FileSystemStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__FileSystemStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__FileSystemStatus * data =
      (drdds__msg__FileSystemStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__FileSystemStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__FileSystemStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__FileSystemStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
