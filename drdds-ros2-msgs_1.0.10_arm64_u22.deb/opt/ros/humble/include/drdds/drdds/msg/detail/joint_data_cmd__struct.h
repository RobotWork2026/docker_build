// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/JointDataCmd.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_DATA_CMD__STRUCT_H_
#define DRDDS__MSG__DETAIL__JOINT_DATA_CMD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/JointDataCmd in the package drdds.
typedef struct drdds__msg__JointDataCmd
{
  uint8_t name[4];
  uint16_t data_id;
  uint16_t control_word;
  float position;
  float torque;
  float velocity;
  float kp;
  float kd;
} drdds__msg__JointDataCmd;

// Struct for a sequence of drdds__msg__JointDataCmd.
typedef struct drdds__msg__JointDataCmd__Sequence
{
  drdds__msg__JointDataCmd * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__JointDataCmd__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__JOINT_DATA_CMD__STRUCT_H_
