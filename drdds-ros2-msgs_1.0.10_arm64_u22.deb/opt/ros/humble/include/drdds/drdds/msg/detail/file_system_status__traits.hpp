// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/FileSystemStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/file_system_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const FileSystemStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: soc_id
  {
    out << "soc_id: ";
    rosidl_generator_traits::value_to_yaml(msg.soc_id, out);
    out << ", ";
  }

  // member: mount_point
  {
    out << "mount_point: ";
    rosidl_generator_traits::value_to_yaml(msg.mount_point, out);
    out << ", ";
  }

  // member: device_path
  {
    out << "device_path: ";
    rosidl_generator_traits::value_to_yaml(msg.device_path, out);
    out << ", ";
  }

  // member: fs_type
  {
    out << "fs_type: ";
    rosidl_generator_traits::value_to_yaml(msg.fs_type, out);
    out << ", ";
  }

  // member: total_bytes
  {
    out << "total_bytes: ";
    rosidl_generator_traits::value_to_yaml(msg.total_bytes, out);
    out << ", ";
  }

  // member: used_bytes
  {
    out << "used_bytes: ";
    rosidl_generator_traits::value_to_yaml(msg.used_bytes, out);
    out << ", ";
  }

  // member: available_bytes
  {
    out << "available_bytes: ";
    rosidl_generator_traits::value_to_yaml(msg.available_bytes, out);
    out << ", ";
  }

  // member: used_inodes
  {
    out << "used_inodes: ";
    rosidl_generator_traits::value_to_yaml(msg.used_inodes, out);
    out << ", ";
  }

  // member: free_inodes
  {
    out << "free_inodes: ";
    rosidl_generator_traits::value_to_yaml(msg.free_inodes, out);
    out << ", ";
  }

  // member: is_readonly
  {
    out << "is_readonly: ";
    rosidl_generator_traits::value_to_yaml(msg.is_readonly, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const FileSystemStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }

  // member: soc_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "soc_id: ";
    rosidl_generator_traits::value_to_yaml(msg.soc_id, out);
    out << "\n";
  }

  // member: mount_point
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mount_point: ";
    rosidl_generator_traits::value_to_yaml(msg.mount_point, out);
    out << "\n";
  }

  // member: device_path
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "device_path: ";
    rosidl_generator_traits::value_to_yaml(msg.device_path, out);
    out << "\n";
  }

  // member: fs_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fs_type: ";
    rosidl_generator_traits::value_to_yaml(msg.fs_type, out);
    out << "\n";
  }

  // member: total_bytes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "total_bytes: ";
    rosidl_generator_traits::value_to_yaml(msg.total_bytes, out);
    out << "\n";
  }

  // member: used_bytes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "used_bytes: ";
    rosidl_generator_traits::value_to_yaml(msg.used_bytes, out);
    out << "\n";
  }

  // member: available_bytes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "available_bytes: ";
    rosidl_generator_traits::value_to_yaml(msg.available_bytes, out);
    out << "\n";
  }

  // member: used_inodes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "used_inodes: ";
    rosidl_generator_traits::value_to_yaml(msg.used_inodes, out);
    out << "\n";
  }

  // member: free_inodes
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "free_inodes: ";
    rosidl_generator_traits::value_to_yaml(msg.free_inodes, out);
    out << "\n";
  }

  // member: is_readonly
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_readonly: ";
    rosidl_generator_traits::value_to_yaml(msg.is_readonly, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const FileSystemStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::FileSystemStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::FileSystemStatus & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::FileSystemStatus>()
{
  return "drdds::msg::FileSystemStatus";
}

template<>
inline const char * name<drdds::msg::FileSystemStatus>()
{
  return "drdds/msg/FileSystemStatus";
}

template<>
struct has_fixed_size<drdds::msg::FileSystemStatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::FileSystemStatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::FileSystemStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__FILE_SYSTEM_STATUS__TRAITS_HPP_
