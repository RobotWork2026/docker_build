// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/battery_data_value__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const BatteryDataValue & msg,
  std::ostream & out)
{
  out << "{";
  // member: voltage
  {
    out << "voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.voltage, out);
    out << ", ";
  }

  // member: current
  {
    out << "current: ";
    rosidl_generator_traits::value_to_yaml(msg.current, out);
    out << ", ";
  }

  // member: remaining_capacity
  {
    out << "remaining_capacity: ";
    rosidl_generator_traits::value_to_yaml(msg.remaining_capacity, out);
    out << ", ";
  }

  // member: nominal_capacity
  {
    out << "nominal_capacity: ";
    rosidl_generator_traits::value_to_yaml(msg.nominal_capacity, out);
    out << ", ";
  }

  // member: cycles
  {
    out << "cycles: ";
    rosidl_generator_traits::value_to_yaml(msg.cycles, out);
    out << ", ";
  }

  // member: production_date
  {
    out << "production_date: ";
    rosidl_generator_traits::value_to_yaml(msg.production_date, out);
    out << ", ";
  }

  // member: balanced_low
  {
    out << "balanced_low: ";
    rosidl_generator_traits::value_to_yaml(msg.balanced_low, out);
    out << ", ";
  }

  // member: balanced_high
  {
    out << "balanced_high: ";
    rosidl_generator_traits::value_to_yaml(msg.balanced_high, out);
    out << ", ";
  }

  // member: protected_state
  {
    out << "protected_state: ";
    rosidl_generator_traits::value_to_yaml(msg.protected_state, out);
    out << ", ";
  }

  // member: software_version
  {
    out << "software_version: ";
    rosidl_generator_traits::value_to_yaml(msg.software_version, out);
    out << ", ";
  }

  // member: battery_level
  {
    out << "battery_level: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_level, out);
    out << ", ";
  }

  // member: mos_state
  {
    out << "mos_state: ";
    rosidl_generator_traits::value_to_yaml(msg.mos_state, out);
    out << ", ";
  }

  // member: battery_quantity
  {
    out << "battery_quantity: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_quantity, out);
    out << ", ";
  }

  // member: battery_ntc
  {
    out << "battery_ntc: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_ntc, out);
    out << ", ";
  }

  // member: battery_temperature
  {
    if (msg.battery_temperature.size() == 0) {
      out << "battery_temperature: []";
    } else {
      out << "battery_temperature: [";
      size_t pending_items = msg.battery_temperature.size();
      for (auto item : msg.battery_temperature) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: battery_serialnum
  {
    if (msg.battery_serialnum.size() == 0) {
      out << "battery_serialnum: []";
    } else {
      out << "battery_serialnum: [";
      size_t pending_items = msg.battery_serialnum.size();
      for (auto item : msg.battery_serialnum) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BatteryDataValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: voltage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.voltage, out);
    out << "\n";
  }

  // member: current
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "current: ";
    rosidl_generator_traits::value_to_yaml(msg.current, out);
    out << "\n";
  }

  // member: remaining_capacity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "remaining_capacity: ";
    rosidl_generator_traits::value_to_yaml(msg.remaining_capacity, out);
    out << "\n";
  }

  // member: nominal_capacity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "nominal_capacity: ";
    rosidl_generator_traits::value_to_yaml(msg.nominal_capacity, out);
    out << "\n";
  }

  // member: cycles
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cycles: ";
    rosidl_generator_traits::value_to_yaml(msg.cycles, out);
    out << "\n";
  }

  // member: production_date
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "production_date: ";
    rosidl_generator_traits::value_to_yaml(msg.production_date, out);
    out << "\n";
  }

  // member: balanced_low
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "balanced_low: ";
    rosidl_generator_traits::value_to_yaml(msg.balanced_low, out);
    out << "\n";
  }

  // member: balanced_high
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "balanced_high: ";
    rosidl_generator_traits::value_to_yaml(msg.balanced_high, out);
    out << "\n";
  }

  // member: protected_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "protected_state: ";
    rosidl_generator_traits::value_to_yaml(msg.protected_state, out);
    out << "\n";
  }

  // member: software_version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "software_version: ";
    rosidl_generator_traits::value_to_yaml(msg.software_version, out);
    out << "\n";
  }

  // member: battery_level
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_level: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_level, out);
    out << "\n";
  }

  // member: mos_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mos_state: ";
    rosidl_generator_traits::value_to_yaml(msg.mos_state, out);
    out << "\n";
  }

  // member: battery_quantity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_quantity: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_quantity, out);
    out << "\n";
  }

  // member: battery_ntc
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_ntc: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_ntc, out);
    out << "\n";
  }

  // member: battery_temperature
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.battery_temperature.size() == 0) {
      out << "battery_temperature: []\n";
    } else {
      out << "battery_temperature:\n";
      for (auto item : msg.battery_temperature) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: battery_serialnum
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.battery_serialnum.size() == 0) {
      out << "battery_serialnum: []\n";
    } else {
      out << "battery_serialnum:\n";
      for (auto item : msg.battery_serialnum) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BatteryDataValue & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::BatteryDataValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::BatteryDataValue & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::BatteryDataValue>()
{
  return "drdds::msg::BatteryDataValue";
}

template<>
inline const char * name<drdds::msg::BatteryDataValue>()
{
  return "drdds/msg/BatteryDataValue";
}

template<>
struct has_fixed_size<drdds::msg::BatteryDataValue>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::BatteryDataValue>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::BatteryDataValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__TRAITS_HPP_
