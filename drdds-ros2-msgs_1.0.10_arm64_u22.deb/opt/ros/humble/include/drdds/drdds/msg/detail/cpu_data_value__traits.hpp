// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/CpuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__CPU_DATA_VALUE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/cpu_data_value__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const CpuDataValue & msg,
  std::ostream & out)
{
  out << "{";
  // member: cpu_temperature
  {
    if (msg.cpu_temperature.size() == 0) {
      out << "cpu_temperature: []";
    } else {
      out << "cpu_temperature: [";
      size_t pending_items = msg.cpu_temperature.size();
      for (auto item : msg.cpu_temperature) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: cpu_frequency
  {
    if (msg.cpu_frequency.size() == 0) {
      out << "cpu_frequency: []";
    } else {
      out << "cpu_frequency: [";
      size_t pending_items = msg.cpu_frequency.size();
      for (auto item : msg.cpu_frequency) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CpuDataValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: cpu_temperature
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.cpu_temperature.size() == 0) {
      out << "cpu_temperature: []\n";
    } else {
      out << "cpu_temperature:\n";
      for (auto item : msg.cpu_temperature) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: cpu_frequency
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.cpu_frequency.size() == 0) {
      out << "cpu_frequency: []\n";
    } else {
      out << "cpu_frequency:\n";
      for (auto item : msg.cpu_frequency) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CpuDataValue & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::CpuDataValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::CpuDataValue & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::CpuDataValue>()
{
  return "drdds::msg::CpuDataValue";
}

template<>
inline const char * name<drdds::msg::CpuDataValue>()
{
  return "drdds/msg/CpuDataValue";
}

template<>
struct has_fixed_size<drdds::msg::CpuDataValue>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::CpuDataValue>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::CpuDataValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__CPU_DATA_VALUE__TRAITS_HPP_
