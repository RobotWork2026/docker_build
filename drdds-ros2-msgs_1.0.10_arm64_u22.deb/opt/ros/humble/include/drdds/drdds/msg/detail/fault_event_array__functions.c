// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/FaultEventArray.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/fault_event_array__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `timestamp`
#include "builtin_interfaces/msg/detail/time__functions.h"
// Member `active_faults`
#include "drdds/msg/detail/fault_event__functions.h"

bool
drdds__msg__FaultEventArray__init(drdds__msg__FaultEventArray * msg)
{
  if (!msg) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__init(&msg->timestamp)) {
    drdds__msg__FaultEventArray__fini(msg);
    return false;
  }
  // active_faults
  if (!drdds__msg__FaultEvent__Sequence__init(&msg->active_faults, 0)) {
    drdds__msg__FaultEventArray__fini(msg);
    return false;
  }
  return true;
}

void
drdds__msg__FaultEventArray__fini(drdds__msg__FaultEventArray * msg)
{
  if (!msg) {
    return;
  }
  // timestamp
  builtin_interfaces__msg__Time__fini(&msg->timestamp);
  // active_faults
  drdds__msg__FaultEvent__Sequence__fini(&msg->active_faults);
}

bool
drdds__msg__FaultEventArray__are_equal(const drdds__msg__FaultEventArray * lhs, const drdds__msg__FaultEventArray * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->timestamp), &(rhs->timestamp)))
  {
    return false;
  }
  // active_faults
  if (!drdds__msg__FaultEvent__Sequence__are_equal(
      &(lhs->active_faults), &(rhs->active_faults)))
  {
    return false;
  }
  return true;
}

bool
drdds__msg__FaultEventArray__copy(
  const drdds__msg__FaultEventArray * input,
  drdds__msg__FaultEventArray * output)
{
  if (!input || !output) {
    return false;
  }
  // timestamp
  if (!builtin_interfaces__msg__Time__copy(
      &(input->timestamp), &(output->timestamp)))
  {
    return false;
  }
  // active_faults
  if (!drdds__msg__FaultEvent__Sequence__copy(
      &(input->active_faults), &(output->active_faults)))
  {
    return false;
  }
  return true;
}

drdds__msg__FaultEventArray *
drdds__msg__FaultEventArray__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FaultEventArray * msg = (drdds__msg__FaultEventArray *)allocator.allocate(sizeof(drdds__msg__FaultEventArray), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__FaultEventArray));
  bool success = drdds__msg__FaultEventArray__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__FaultEventArray__destroy(drdds__msg__FaultEventArray * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__FaultEventArray__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__FaultEventArray__Sequence__init(drdds__msg__FaultEventArray__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FaultEventArray * data = NULL;

  if (size) {
    data = (drdds__msg__FaultEventArray *)allocator.zero_allocate(size, sizeof(drdds__msg__FaultEventArray), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__FaultEventArray__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__FaultEventArray__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__FaultEventArray__Sequence__fini(drdds__msg__FaultEventArray__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__FaultEventArray__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__FaultEventArray__Sequence *
drdds__msg__FaultEventArray__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__FaultEventArray__Sequence * array = (drdds__msg__FaultEventArray__Sequence *)allocator.allocate(sizeof(drdds__msg__FaultEventArray__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__FaultEventArray__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__FaultEventArray__Sequence__destroy(drdds__msg__FaultEventArray__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__FaultEventArray__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__FaultEventArray__Sequence__are_equal(const drdds__msg__FaultEventArray__Sequence * lhs, const drdds__msg__FaultEventArray__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__FaultEventArray__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__FaultEventArray__Sequence__copy(
  const drdds__msg__FaultEventArray__Sequence * input,
  drdds__msg__FaultEventArray__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__FaultEventArray);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__FaultEventArray * data =
      (drdds__msg__FaultEventArray *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__FaultEventArray__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__FaultEventArray__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__FaultEventArray__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
