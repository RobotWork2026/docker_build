// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/JointCmdValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/joint_cmd_value__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_JointCmdValue_kd
{
public:
  explicit Init_JointCmdValue_kd(::drdds::msg::JointCmdValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::JointCmdValue kd(::drdds::msg::JointCmdValue::_kd_type arg)
  {
    msg_.kd = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::JointCmdValue msg_;
};

class Init_JointCmdValue_kp
{
public:
  explicit Init_JointCmdValue_kp(::drdds::msg::JointCmdValue & msg)
  : msg_(msg)
  {}
  Init_JointCmdValue_kd kp(::drdds::msg::JointCmdValue::_kp_type arg)
  {
    msg_.kp = std::move(arg);
    return Init_JointCmdValue_kd(msg_);
  }

private:
  ::drdds::msg::JointCmdValue msg_;
};

class Init_JointCmdValue_velocity
{
public:
  explicit Init_JointCmdValue_velocity(::drdds::msg::JointCmdValue & msg)
  : msg_(msg)
  {}
  Init_JointCmdValue_kp velocity(::drdds::msg::JointCmdValue::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_JointCmdValue_kp(msg_);
  }

private:
  ::drdds::msg::JointCmdValue msg_;
};

class Init_JointCmdValue_torque
{
public:
  explicit Init_JointCmdValue_torque(::drdds::msg::JointCmdValue & msg)
  : msg_(msg)
  {}
  Init_JointCmdValue_velocity torque(::drdds::msg::JointCmdValue::_torque_type arg)
  {
    msg_.torque = std::move(arg);
    return Init_JointCmdValue_velocity(msg_);
  }

private:
  ::drdds::msg::JointCmdValue msg_;
};

class Init_JointCmdValue_position
{
public:
  explicit Init_JointCmdValue_position(::drdds::msg::JointCmdValue & msg)
  : msg_(msg)
  {}
  Init_JointCmdValue_torque position(::drdds::msg::JointCmdValue::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_JointCmdValue_torque(msg_);
  }

private:
  ::drdds::msg::JointCmdValue msg_;
};

class Init_JointCmdValue_control_word
{
public:
  explicit Init_JointCmdValue_control_word(::drdds::msg::JointCmdValue & msg)
  : msg_(msg)
  {}
  Init_JointCmdValue_position control_word(::drdds::msg::JointCmdValue::_control_word_type arg)
  {
    msg_.control_word = std::move(arg);
    return Init_JointCmdValue_position(msg_);
  }

private:
  ::drdds::msg::JointCmdValue msg_;
};

class Init_JointCmdValue_data_id
{
public:
  explicit Init_JointCmdValue_data_id(::drdds::msg::JointCmdValue & msg)
  : msg_(msg)
  {}
  Init_JointCmdValue_control_word data_id(::drdds::msg::JointCmdValue::_data_id_type arg)
  {
    msg_.data_id = std::move(arg);
    return Init_JointCmdValue_control_word(msg_);
  }

private:
  ::drdds::msg::JointCmdValue msg_;
};

class Init_JointCmdValue_name
{
public:
  Init_JointCmdValue_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_JointCmdValue_data_id name(::drdds::msg::JointCmdValue::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_JointCmdValue_data_id(msg_);
  }

private:
  ::drdds::msg::JointCmdValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::JointCmdValue>()
{
  return drdds::msg::builder::Init_JointCmdValue_name();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__BUILDER_HPP_
