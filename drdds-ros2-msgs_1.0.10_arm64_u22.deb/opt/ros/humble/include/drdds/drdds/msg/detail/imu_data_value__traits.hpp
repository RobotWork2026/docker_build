// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/ImuDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__IMU_DATA_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__IMU_DATA_VALUE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/imu_data_value__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const ImuDataValue & msg,
  std::ostream & out)
{
  out << "{";
  // member: roll
  {
    out << "roll: ";
    rosidl_generator_traits::value_to_yaml(msg.roll, out);
    out << ", ";
  }

  // member: pitch
  {
    out << "pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.pitch, out);
    out << ", ";
  }

  // member: yaw
  {
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
    out << ", ";
  }

  // member: omega_x
  {
    out << "omega_x: ";
    rosidl_generator_traits::value_to_yaml(msg.omega_x, out);
    out << ", ";
  }

  // member: omega_y
  {
    out << "omega_y: ";
    rosidl_generator_traits::value_to_yaml(msg.omega_y, out);
    out << ", ";
  }

  // member: omega_z
  {
    out << "omega_z: ";
    rosidl_generator_traits::value_to_yaml(msg.omega_z, out);
    out << ", ";
  }

  // member: acc_x
  {
    out << "acc_x: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_x, out);
    out << ", ";
  }

  // member: acc_y
  {
    out << "acc_y: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_y, out);
    out << ", ";
  }

  // member: acc_z
  {
    out << "acc_z: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_z, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ImuDataValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: roll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "roll: ";
    rosidl_generator_traits::value_to_yaml(msg.roll, out);
    out << "\n";
  }

  // member: pitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pitch: ";
    rosidl_generator_traits::value_to_yaml(msg.pitch, out);
    out << "\n";
  }

  // member: yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
    out << "\n";
  }

  // member: omega_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "omega_x: ";
    rosidl_generator_traits::value_to_yaml(msg.omega_x, out);
    out << "\n";
  }

  // member: omega_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "omega_y: ";
    rosidl_generator_traits::value_to_yaml(msg.omega_y, out);
    out << "\n";
  }

  // member: omega_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "omega_z: ";
    rosidl_generator_traits::value_to_yaml(msg.omega_z, out);
    out << "\n";
  }

  // member: acc_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc_x: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_x, out);
    out << "\n";
  }

  // member: acc_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc_y: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_y, out);
    out << "\n";
  }

  // member: acc_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "acc_z: ";
    rosidl_generator_traits::value_to_yaml(msg.acc_z, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ImuDataValue & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::ImuDataValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::ImuDataValue & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::ImuDataValue>()
{
  return "drdds::msg::ImuDataValue";
}

template<>
inline const char * name<drdds::msg::ImuDataValue>()
{
  return "drdds/msg/ImuDataValue";
}

template<>
struct has_fixed_size<drdds::msg::ImuDataValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::ImuDataValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::ImuDataValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__IMU_DATA_VALUE__TRAITS_HPP_
