// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from drdds:msg/ExecStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__FUNCTIONS_H_
#define DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "drdds/msg/rosidl_generator_c__visibility_control.h"

#include "drdds/msg/detail/exec_status_value__struct.h"

/// Initialize msg/ExecStatusValue message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * drdds__msg__ExecStatusValue
 * )) before or use
 * drdds__msg__ExecStatusValue__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__ExecStatusValue__init(drdds__msg__ExecStatusValue * msg);

/// Finalize msg/ExecStatusValue message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
void
drdds__msg__ExecStatusValue__fini(drdds__msg__ExecStatusValue * msg);

/// Create msg/ExecStatusValue message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * drdds__msg__ExecStatusValue__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
drdds__msg__ExecStatusValue *
drdds__msg__ExecStatusValue__create();

/// Destroy msg/ExecStatusValue message.
/**
 * It calls
 * drdds__msg__ExecStatusValue__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
void
drdds__msg__ExecStatusValue__destroy(drdds__msg__ExecStatusValue * msg);

/// Check for msg/ExecStatusValue message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__ExecStatusValue__are_equal(const drdds__msg__ExecStatusValue * lhs, const drdds__msg__ExecStatusValue * rhs);

/// Copy a msg/ExecStatusValue message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__ExecStatusValue__copy(
  const drdds__msg__ExecStatusValue * input,
  drdds__msg__ExecStatusValue * output);

/// Initialize array of msg/ExecStatusValue messages.
/**
 * It allocates the memory for the number of elements and calls
 * drdds__msg__ExecStatusValue__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__ExecStatusValue__Sequence__init(drdds__msg__ExecStatusValue__Sequence * array, size_t size);

/// Finalize array of msg/ExecStatusValue messages.
/**
 * It calls
 * drdds__msg__ExecStatusValue__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
void
drdds__msg__ExecStatusValue__Sequence__fini(drdds__msg__ExecStatusValue__Sequence * array);

/// Create array of msg/ExecStatusValue messages.
/**
 * It allocates the memory for the array and calls
 * drdds__msg__ExecStatusValue__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
drdds__msg__ExecStatusValue__Sequence *
drdds__msg__ExecStatusValue__Sequence__create(size_t size);

/// Destroy array of msg/ExecStatusValue messages.
/**
 * It calls
 * drdds__msg__ExecStatusValue__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
void
drdds__msg__ExecStatusValue__Sequence__destroy(drdds__msg__ExecStatusValue__Sequence * array);

/// Check for msg/ExecStatusValue message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__ExecStatusValue__Sequence__are_equal(const drdds__msg__ExecStatusValue__Sequence * lhs, const drdds__msg__ExecStatusValue__Sequence * rhs);

/// Copy an array of msg/ExecStatusValue messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_drdds
bool
drdds__msg__ExecStatusValue__Sequence__copy(
  const drdds__msg__ExecStatusValue__Sequence * input,
  drdds__msg__ExecStatusValue__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__FUNCTIONS_H_
