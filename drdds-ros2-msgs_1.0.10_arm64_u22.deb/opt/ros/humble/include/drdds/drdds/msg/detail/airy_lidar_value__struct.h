﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/AiryLidarValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/AiryLidarValue in the package drdds.
typedef struct drdds__msg__AiryLidarValue
{
  /// 是否运行
  bool is_runing;
  /// 错误码
  int32_t error_code;
  /// 点云数量
  int32_t cld_size;
  /// 温度
  float temp;
  /// 电压
  float voltage;
} drdds__msg__AiryLidarValue;

// Struct for a sequence of drdds__msg__AiryLidarValue.
typedef struct drdds__msg__AiryLidarValue__Sequence
{
  drdds__msg__AiryLidarValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__AiryLidarValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__STRUCT_H_
