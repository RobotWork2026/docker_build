// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/ImuDataValue.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/imu_data_value__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


bool
drdds__msg__ImuDataValue__init(drdds__msg__ImuDataValue * msg)
{
  if (!msg) {
    return false;
  }
  // roll
  // pitch
  // yaw
  // omega_x
  // omega_y
  // omega_z
  // acc_x
  // acc_y
  // acc_z
  return true;
}

void
drdds__msg__ImuDataValue__fini(drdds__msg__ImuDataValue * msg)
{
  if (!msg) {
    return;
  }
  // roll
  // pitch
  // yaw
  // omega_x
  // omega_y
  // omega_z
  // acc_x
  // acc_y
  // acc_z
}

bool
drdds__msg__ImuDataValue__are_equal(const drdds__msg__ImuDataValue * lhs, const drdds__msg__ImuDataValue * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // roll
  if (lhs->roll != rhs->roll) {
    return false;
  }
  // pitch
  if (lhs->pitch != rhs->pitch) {
    return false;
  }
  // yaw
  if (lhs->yaw != rhs->yaw) {
    return false;
  }
  // omega_x
  if (lhs->omega_x != rhs->omega_x) {
    return false;
  }
  // omega_y
  if (lhs->omega_y != rhs->omega_y) {
    return false;
  }
  // omega_z
  if (lhs->omega_z != rhs->omega_z) {
    return false;
  }
  // acc_x
  if (lhs->acc_x != rhs->acc_x) {
    return false;
  }
  // acc_y
  if (lhs->acc_y != rhs->acc_y) {
    return false;
  }
  // acc_z
  if (lhs->acc_z != rhs->acc_z) {
    return false;
  }
  return true;
}

bool
drdds__msg__ImuDataValue__copy(
  const drdds__msg__ImuDataValue * input,
  drdds__msg__ImuDataValue * output)
{
  if (!input || !output) {
    return false;
  }
  // roll
  output->roll = input->roll;
  // pitch
  output->pitch = input->pitch;
  // yaw
  output->yaw = input->yaw;
  // omega_x
  output->omega_x = input->omega_x;
  // omega_y
  output->omega_y = input->omega_y;
  // omega_z
  output->omega_z = input->omega_z;
  // acc_x
  output->acc_x = input->acc_x;
  // acc_y
  output->acc_y = input->acc_y;
  // acc_z
  output->acc_z = input->acc_z;
  return true;
}

drdds__msg__ImuDataValue *
drdds__msg__ImuDataValue__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__ImuDataValue * msg = (drdds__msg__ImuDataValue *)allocator.allocate(sizeof(drdds__msg__ImuDataValue), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__ImuDataValue));
  bool success = drdds__msg__ImuDataValue__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__ImuDataValue__destroy(drdds__msg__ImuDataValue * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__ImuDataValue__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__ImuDataValue__Sequence__init(drdds__msg__ImuDataValue__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__ImuDataValue * data = NULL;

  if (size) {
    data = (drdds__msg__ImuDataValue *)allocator.zero_allocate(size, sizeof(drdds__msg__ImuDataValue), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__ImuDataValue__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__ImuDataValue__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__ImuDataValue__Sequence__fini(drdds__msg__ImuDataValue__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__ImuDataValue__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__ImuDataValue__Sequence *
drdds__msg__ImuDataValue__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__ImuDataValue__Sequence * array = (drdds__msg__ImuDataValue__Sequence *)allocator.allocate(sizeof(drdds__msg__ImuDataValue__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__ImuDataValue__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__ImuDataValue__Sequence__destroy(drdds__msg__ImuDataValue__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__ImuDataValue__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__ImuDataValue__Sequence__are_equal(const drdds__msg__ImuDataValue__Sequence * lhs, const drdds__msg__ImuDataValue__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__ImuDataValue__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__ImuDataValue__Sequence__copy(
  const drdds__msg__ImuDataValue__Sequence * input,
  drdds__msg__ImuDataValue__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__ImuDataValue);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__ImuDataValue * data =
      (drdds__msg__ImuDataValue *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__ImuDataValue__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__ImuDataValue__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__ImuDataValue__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
