// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/CpuData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_DATA__STRUCT_H_
#define DRDDS__MSG__DETAIL__CPU_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "drdds/msg/detail/meta_type__struct.h"
// Member 'data'
#include "drdds/msg/detail/cpu_data_value__struct.h"

/// Struct defined in msg/CpuData in the package drdds.
typedef struct drdds__msg__CpuData
{
  drdds__msg__MetaType header;
  drdds__msg__CpuDataValue data;
} drdds__msg__CpuData;

// Struct for a sequence of drdds__msg__CpuData.
typedef struct drdds__msg__CpuData__Sequence
{
  drdds__msg__CpuData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__CpuData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__CPU_DATA__STRUCT_H_
