// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__BATTERY_DATA_HPP_
#define DRDDS__MSG__BATTERY_DATA_HPP_

#include "drdds/msg/detail/battery_data__struct.hpp"
#include "drdds/msg/detail/battery_data__builder.hpp"
#include "drdds/msg/detail/battery_data__traits.hpp"
#include "drdds/msg/detail/battery_data__type_support.hpp"

#endif  // DRDDS__MSG__BATTERY_DATA_HPP_
