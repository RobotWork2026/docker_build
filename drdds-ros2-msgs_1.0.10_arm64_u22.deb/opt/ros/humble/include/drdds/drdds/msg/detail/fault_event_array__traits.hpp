// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/FaultEventArray.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/fault_event_array__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"
// Member 'active_faults'
#include "drdds/msg/detail/fault_event__traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const FaultEventArray & msg,
  std::ostream & out)
{
  out << "{";
  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: active_faults
  {
    if (msg.active_faults.size() == 0) {
      out << "active_faults: []";
    } else {
      out << "active_faults: [";
      size_t pending_items = msg.active_faults.size();
      for (auto item : msg.active_faults) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const FaultEventArray & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }

  // member: active_faults
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.active_faults.size() == 0) {
      out << "active_faults: []\n";
    } else {
      out << "active_faults:\n";
      for (auto item : msg.active_faults) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const FaultEventArray & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::FaultEventArray & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::FaultEventArray & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::FaultEventArray>()
{
  return "drdds::msg::FaultEventArray";
}

template<>
inline const char * name<drdds::msg::FaultEventArray>()
{
  return "drdds/msg/FaultEventArray";
}

template<>
struct has_fixed_size<drdds::msg::FaultEventArray>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::FaultEventArray>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::FaultEventArray>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT_ARRAY__TRAITS_HPP_
