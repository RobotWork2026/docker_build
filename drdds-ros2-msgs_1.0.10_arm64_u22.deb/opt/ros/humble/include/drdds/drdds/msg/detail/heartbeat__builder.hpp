// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/Heartbeat.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__HEARTBEAT__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__HEARTBEAT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/heartbeat__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_Heartbeat_details
{
public:
  explicit Init_Heartbeat_details(::drdds::msg::Heartbeat & msg)
  : msg_(msg)
  {}
  ::drdds::msg::Heartbeat details(::drdds::msg::Heartbeat::_details_type arg)
  {
    msg_.details = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::Heartbeat msg_;
};

class Init_Heartbeat_status
{
public:
  explicit Init_Heartbeat_status(::drdds::msg::Heartbeat & msg)
  : msg_(msg)
  {}
  Init_Heartbeat_details status(::drdds::msg::Heartbeat::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_Heartbeat_details(msg_);
  }

private:
  ::drdds::msg::Heartbeat msg_;
};

class Init_Heartbeat_source
{
public:
  explicit Init_Heartbeat_source(::drdds::msg::Heartbeat & msg)
  : msg_(msg)
  {}
  Init_Heartbeat_status source(::drdds::msg::Heartbeat::_source_type arg)
  {
    msg_.source = std::move(arg);
    return Init_Heartbeat_status(msg_);
  }

private:
  ::drdds::msg::Heartbeat msg_;
};

class Init_Heartbeat_timestamp
{
public:
  Init_Heartbeat_timestamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Heartbeat_source timestamp(::drdds::msg::Heartbeat::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return Init_Heartbeat_source(msg_);
  }

private:
  ::drdds::msg::Heartbeat msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::Heartbeat>()
{
  return drdds::msg::builder::Init_Heartbeat_timestamp();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__HEARTBEAT__BUILDER_HPP_
