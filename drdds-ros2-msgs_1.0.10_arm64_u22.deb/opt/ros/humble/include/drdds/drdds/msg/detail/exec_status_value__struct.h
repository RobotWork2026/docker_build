// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/ExecStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/ExecStatusValue in the package drdds.
typedef struct drdds__msg__ExecStatusValue
{
  uint8_t overtime;
  uint8_t numeric_error;
  uint8_t timestamp_error;
} drdds__msg__ExecStatusValue;

// Struct for a sequence of drdds__msg__ExecStatusValue.
typedef struct drdds__msg__ExecStatusValue__Sequence
{
  drdds__msg__ExecStatusValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__ExecStatusValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__STRUCT_H_
