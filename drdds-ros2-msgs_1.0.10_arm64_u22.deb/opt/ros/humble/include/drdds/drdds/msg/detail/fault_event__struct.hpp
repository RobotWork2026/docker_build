// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/FaultEvent.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__drdds__msg__FaultEvent __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__FaultEvent __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct FaultEvent_
{
  using Type = FaultEvent_<ContainerAllocator>;

  explicit FaultEvent_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->code = 0ul;
      this->type = 0;
      this->grouped = false;
      this->details = "";
    }
  }

  explicit FaultEvent_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : timestamp(_alloc, _init),
    name(_alloc),
    details(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->code = 0ul;
      this->type = 0;
      this->grouped = false;
      this->details = "";
    }
  }

  // field types and members
  using _timestamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _timestamp_type timestamp;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _code_type =
    uint32_t;
  _code_type code;
  using _type_type =
    uint8_t;
  _type_type type;
  using _severities_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _severities_type severities;
  using _resources_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _resources_type resources;
  using _grouped_type =
    bool;
  _grouped_type grouped;
  using _source_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _source_type source;
  using _details_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _details_type details;

  // setters for named parameter idiom
  Type & set__timestamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->timestamp = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__code(
    const uint32_t & _arg)
  {
    this->code = _arg;
    return *this;
  }
  Type & set__type(
    const uint8_t & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__severities(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->severities = _arg;
    return *this;
  }
  Type & set__resources(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->resources = _arg;
    return *this;
  }
  Type & set__grouped(
    const bool & _arg)
  {
    this->grouped = _arg;
    return *this;
  }
  Type & set__source(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->source = _arg;
    return *this;
  }
  Type & set__details(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->details = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t TYPE_START =
    1u;
  static constexpr uint8_t TYPE_STOP =
    2u;
  static constexpr uint8_t TYPE_PULSE =
    3u;
  static constexpr uint8_t SEVERITY_DEBUG =
    1u;
  static constexpr uint8_t SEVERITY_INFO =
    2u;
  static constexpr uint8_t SEVERITY_WARN =
    3u;
  static constexpr uint8_t SEVERITY_ERROR =
    4u;
  static constexpr uint8_t SEVERITY_FATAL =
    5u;

  // pointer types
  using RawPtr =
    drdds::msg::FaultEvent_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::FaultEvent_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::FaultEvent_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::FaultEvent_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::FaultEvent_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::FaultEvent_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::FaultEvent_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::FaultEvent_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::FaultEvent_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::FaultEvent_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__FaultEvent
    std::shared_ptr<drdds::msg::FaultEvent_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__FaultEvent
    std::shared_ptr<drdds::msg::FaultEvent_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FaultEvent_ & other) const
  {
    if (this->timestamp != other.timestamp) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->code != other.code) {
      return false;
    }
    if (this->type != other.type) {
      return false;
    }
    if (this->severities != other.severities) {
      return false;
    }
    if (this->resources != other.resources) {
      return false;
    }
    if (this->grouped != other.grouped) {
      return false;
    }
    if (this->source != other.source) {
      return false;
    }
    if (this->details != other.details) {
      return false;
    }
    return true;
  }
  bool operator!=(const FaultEvent_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FaultEvent_

// alias to use template instance with default allocator
using FaultEvent =
  drdds::msg::FaultEvent_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FaultEvent_<ContainerAllocator>::TYPE_START;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FaultEvent_<ContainerAllocator>::TYPE_STOP;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FaultEvent_<ContainerAllocator>::TYPE_PULSE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FaultEvent_<ContainerAllocator>::SEVERITY_DEBUG;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FaultEvent_<ContainerAllocator>::SEVERITY_INFO;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FaultEvent_<ContainerAllocator>::SEVERITY_WARN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FaultEvent_<ContainerAllocator>::SEVERITY_ERROR;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t FaultEvent_<ContainerAllocator>::SEVERITY_FATAL;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FAULT_EVENT__STRUCT_HPP_
