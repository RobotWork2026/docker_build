// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/Heartbeat.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__HEARTBEAT__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__HEARTBEAT__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/heartbeat__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const Heartbeat & msg,
  std::ostream & out)
{
  out << "{";
  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: source
  {
    out << "source: ";
    rosidl_generator_traits::value_to_yaml(msg.source, out);
    out << ", ";
  }

  // member: status
  {
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << ", ";
  }

  // member: details
  {
    out << "details: ";
    rosidl_generator_traits::value_to_yaml(msg.details, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Heartbeat & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }

  // member: source
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "source: ";
    rosidl_generator_traits::value_to_yaml(msg.source, out);
    out << "\n";
  }

  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << "\n";
  }

  // member: details
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "details: ";
    rosidl_generator_traits::value_to_yaml(msg.details, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Heartbeat & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::Heartbeat & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::Heartbeat & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::Heartbeat>()
{
  return "drdds::msg::Heartbeat";
}

template<>
inline const char * name<drdds::msg::Heartbeat>()
{
  return "drdds/msg/Heartbeat";
}

template<>
struct has_fixed_size<drdds::msg::Heartbeat>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::Heartbeat>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::Heartbeat>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__HEARTBEAT__TRAITS_HPP_
