// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/InputStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/input_status_value__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const InputStatusValue & msg,
  std::ostream & out)
{
  out << "{";
  // member: lidar
  {
    out << "lidar: ";
    rosidl_generator_traits::value_to_yaml(msg.lidar, out);
    out << ", ";
  }

  // member: imu
  {
    out << "imu: ";
    rosidl_generator_traits::value_to_yaml(msg.imu, out);
    out << ", ";
  }

  // member: leg_odom
  {
    out << "leg_odom: ";
    rosidl_generator_traits::value_to_yaml(msg.leg_odom, out);
    out << ", ";
  }

  // member: rtk
  {
    out << "rtk: ";
    rosidl_generator_traits::value_to_yaml(msg.rtk, out);
    out << ", ";
  }

  // member: tag
  {
    out << "tag: ";
    rosidl_generator_traits::value_to_yaml(msg.tag, out);
    out << ", ";
  }

  // member: reflective_strip
  {
    out << "reflective_strip: ";
    rosidl_generator_traits::value_to_yaml(msg.reflective_strip, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const InputStatusValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: lidar
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "lidar: ";
    rosidl_generator_traits::value_to_yaml(msg.lidar, out);
    out << "\n";
  }

  // member: imu
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "imu: ";
    rosidl_generator_traits::value_to_yaml(msg.imu, out);
    out << "\n";
  }

  // member: leg_odom
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "leg_odom: ";
    rosidl_generator_traits::value_to_yaml(msg.leg_odom, out);
    out << "\n";
  }

  // member: rtk
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rtk: ";
    rosidl_generator_traits::value_to_yaml(msg.rtk, out);
    out << "\n";
  }

  // member: tag
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "tag: ";
    rosidl_generator_traits::value_to_yaml(msg.tag, out);
    out << "\n";
  }

  // member: reflective_strip
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "reflective_strip: ";
    rosidl_generator_traits::value_to_yaml(msg.reflective_strip, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const InputStatusValue & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::InputStatusValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::InputStatusValue & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::InputStatusValue>()
{
  return "drdds::msg::InputStatusValue";
}

template<>
inline const char * name<drdds::msg::InputStatusValue>()
{
  return "drdds/msg/InputStatusValue";
}

template<>
struct has_fixed_size<drdds::msg::InputStatusValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::InputStatusValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::InputStatusValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__INPUT_STATUS_VALUE__TRAITS_HPP_
