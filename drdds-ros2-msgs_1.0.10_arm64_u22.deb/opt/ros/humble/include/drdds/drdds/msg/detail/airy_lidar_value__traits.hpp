// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/AiryLidarValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/airy_lidar_value__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const AiryLidarValue & msg,
  std::ostream & out)
{
  out << "{";
  // member: is_runing
  {
    out << "is_runing: ";
    rosidl_generator_traits::value_to_yaml(msg.is_runing, out);
    out << ", ";
  }

  // member: error_code
  {
    out << "error_code: ";
    rosidl_generator_traits::value_to_yaml(msg.error_code, out);
    out << ", ";
  }

  // member: cld_size
  {
    out << "cld_size: ";
    rosidl_generator_traits::value_to_yaml(msg.cld_size, out);
    out << ", ";
  }

  // member: temp
  {
    out << "temp: ";
    rosidl_generator_traits::value_to_yaml(msg.temp, out);
    out << ", ";
  }

  // member: voltage
  {
    out << "voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.voltage, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const AiryLidarValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: is_runing
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_runing: ";
    rosidl_generator_traits::value_to_yaml(msg.is_runing, out);
    out << "\n";
  }

  // member: error_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error_code: ";
    rosidl_generator_traits::value_to_yaml(msg.error_code, out);
    out << "\n";
  }

  // member: cld_size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "cld_size: ";
    rosidl_generator_traits::value_to_yaml(msg.cld_size, out);
    out << "\n";
  }

  // member: temp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "temp: ";
    rosidl_generator_traits::value_to_yaml(msg.temp, out);
    out << "\n";
  }

  // member: voltage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.voltage, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const AiryLidarValue & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::AiryLidarValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::AiryLidarValue & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::AiryLidarValue>()
{
  return "drdds::msg::AiryLidarValue";
}

template<>
inline const char * name<drdds::msg::AiryLidarValue>()
{
  return "drdds/msg/AiryLidarValue";
}

template<>
struct has_fixed_size<drdds::msg::AiryLidarValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::AiryLidarValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::AiryLidarValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__TRAITS_HPP_
