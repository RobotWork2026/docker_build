// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/Exception.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXCEPTION__STRUCT_H_
#define DRDDS__MSG__DETAIL__EXCEPTION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'source'
// Member 'description'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/Exception in the package drdds.
typedef struct drdds__msg__Exception
{
  builtin_interfaces__msg__Time stamp;
  rosidl_runtime_c__String source;
  rosidl_runtime_c__String description;
  bool is_abnormal;
} drdds__msg__Exception;

// Struct for a sequence of drdds__msg__Exception.
typedef struct drdds__msg__Exception__Sequence
{
  drdds__msg__Exception * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__Exception__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__EXCEPTION__STRUCT_H_
