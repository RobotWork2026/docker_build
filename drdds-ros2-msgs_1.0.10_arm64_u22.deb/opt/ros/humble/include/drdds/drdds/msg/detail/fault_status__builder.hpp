// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/FaultStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__FAULT_STATUS__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__FAULT_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/fault_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_FaultStatus_data
{
public:
  explicit Init_FaultStatus_data(::drdds::msg::FaultStatus & msg)
  : msg_(msg)
  {}
  ::drdds::msg::FaultStatus data(::drdds::msg::FaultStatus::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::FaultStatus msg_;
};

class Init_FaultStatus_header
{
public:
  Init_FaultStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FaultStatus_data header(::drdds::msg::FaultStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_FaultStatus_data(msg_);
  }

private:
  ::drdds::msg::FaultStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::FaultStatus>()
{
  return drdds::msg::builder::Init_FaultStatus_header();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__FAULT_STATUS__BUILDER_HPP_
