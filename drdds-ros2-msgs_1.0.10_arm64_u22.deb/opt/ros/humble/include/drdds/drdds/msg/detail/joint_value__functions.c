// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from drdds:msg/JointValue.idl
// generated code does not contain a copyright notice
#include "drdds/msg/detail/joint_value__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `name`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
drdds__msg__JointValue__init(drdds__msg__JointValue * msg)
{
  if (!msg) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->name, 0)) {
    drdds__msg__JointValue__fini(msg);
    return false;
  }
  // data_id
  // status_word
  // position
  // torque
  // velocity
  // motion_temp
  // driver_temp
  return true;
}

void
drdds__msg__JointValue__fini(drdds__msg__JointValue * msg)
{
  if (!msg) {
    return;
  }
  // name
  rosidl_runtime_c__uint8__Sequence__fini(&msg->name);
  // data_id
  // status_word
  // position
  // torque
  // velocity
  // motion_temp
  // driver_temp
}

bool
drdds__msg__JointValue__are_equal(const drdds__msg__JointValue * lhs, const drdds__msg__JointValue * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // data_id
  if (lhs->data_id != rhs->data_id) {
    return false;
  }
  // status_word
  if (lhs->status_word != rhs->status_word) {
    return false;
  }
  // position
  if (lhs->position != rhs->position) {
    return false;
  }
  // torque
  if (lhs->torque != rhs->torque) {
    return false;
  }
  // velocity
  if (lhs->velocity != rhs->velocity) {
    return false;
  }
  // motion_temp
  if (lhs->motion_temp != rhs->motion_temp) {
    return false;
  }
  // driver_temp
  if (lhs->driver_temp != rhs->driver_temp) {
    return false;
  }
  return true;
}

bool
drdds__msg__JointValue__copy(
  const drdds__msg__JointValue * input,
  drdds__msg__JointValue * output)
{
  if (!input || !output) {
    return false;
  }
  // name
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // data_id
  output->data_id = input->data_id;
  // status_word
  output->status_word = input->status_word;
  // position
  output->position = input->position;
  // torque
  output->torque = input->torque;
  // velocity
  output->velocity = input->velocity;
  // motion_temp
  output->motion_temp = input->motion_temp;
  // driver_temp
  output->driver_temp = input->driver_temp;
  return true;
}

drdds__msg__JointValue *
drdds__msg__JointValue__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__JointValue * msg = (drdds__msg__JointValue *)allocator.allocate(sizeof(drdds__msg__JointValue), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(drdds__msg__JointValue));
  bool success = drdds__msg__JointValue__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
drdds__msg__JointValue__destroy(drdds__msg__JointValue * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    drdds__msg__JointValue__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
drdds__msg__JointValue__Sequence__init(drdds__msg__JointValue__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__JointValue * data = NULL;

  if (size) {
    data = (drdds__msg__JointValue *)allocator.zero_allocate(size, sizeof(drdds__msg__JointValue), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = drdds__msg__JointValue__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        drdds__msg__JointValue__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
drdds__msg__JointValue__Sequence__fini(drdds__msg__JointValue__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      drdds__msg__JointValue__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

drdds__msg__JointValue__Sequence *
drdds__msg__JointValue__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  drdds__msg__JointValue__Sequence * array = (drdds__msg__JointValue__Sequence *)allocator.allocate(sizeof(drdds__msg__JointValue__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = drdds__msg__JointValue__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
drdds__msg__JointValue__Sequence__destroy(drdds__msg__JointValue__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    drdds__msg__JointValue__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
drdds__msg__JointValue__Sequence__are_equal(const drdds__msg__JointValue__Sequence * lhs, const drdds__msg__JointValue__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!drdds__msg__JointValue__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
drdds__msg__JointValue__Sequence__copy(
  const drdds__msg__JointValue__Sequence * input,
  drdds__msg__JointValue__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(drdds__msg__JointValue);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    drdds__msg__JointValue * data =
      (drdds__msg__JointValue *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!drdds__msg__JointValue__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          drdds__msg__JointValue__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!drdds__msg__JointValue__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
