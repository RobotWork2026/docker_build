// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/ExecStatusValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/exec_status_value__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const ExecStatusValue & msg,
  std::ostream & out)
{
  out << "{";
  // member: overtime
  {
    out << "overtime: ";
    rosidl_generator_traits::value_to_yaml(msg.overtime, out);
    out << ", ";
  }

  // member: numeric_error
  {
    out << "numeric_error: ";
    rosidl_generator_traits::value_to_yaml(msg.numeric_error, out);
    out << ", ";
  }

  // member: timestamp_error
  {
    out << "timestamp_error: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_error, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ExecStatusValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: overtime
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "overtime: ";
    rosidl_generator_traits::value_to_yaml(msg.overtime, out);
    out << "\n";
  }

  // member: numeric_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "numeric_error: ";
    rosidl_generator_traits::value_to_yaml(msg.numeric_error, out);
    out << "\n";
  }

  // member: timestamp_error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp_error: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp_error, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ExecStatusValue & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::ExecStatusValue & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::ExecStatusValue & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::ExecStatusValue>()
{
  return "drdds::msg::ExecStatusValue";
}

template<>
inline const char * name<drdds::msg::ExecStatusValue>()
{
  return "drdds/msg/ExecStatusValue";
}

template<>
struct has_fixed_size<drdds::msg::ExecStatusValue>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<drdds::msg::ExecStatusValue>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<drdds::msg::ExecStatusValue>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__EXEC_STATUS_VALUE__TRAITS_HPP_
