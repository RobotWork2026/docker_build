﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from drdds:msg/BatteryDataValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_H_
#define DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'battery_temperature'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/BatteryDataValue in the package drdds.
typedef struct drdds__msg__BatteryDataValue
{
  /// 总电压, 单位10mV
  uint16_t voltage;
  /// 总电流, 单位10mA
  int16_t current;
  /// 剩余容量, 单位10mAH
  uint16_t remaining_capacity;
  /// 标称容量, 单位10mAH
  uint16_t nominal_capacity;
  /// 循环次数
  uint16_t cycles;
  /// 生产日期
  uint16_t production_date;
  /// 均衡低
  uint16_t balanced_low;
  /// 均衡高
  uint16_t balanced_high;
  /// 保护状态
  uint16_t protected_state;
  /// 软件版本
  uint8_t software_version;
  /// 剩余容量百分比
  uint8_t battery_level;
  /// Mos状态
  uint8_t mos_state;
  /// 电池串数
  uint8_t battery_quantity;
  /// NTC个数
  uint8_t battery_ntc;
  /// 电池温度序列
  rosidl_runtime_c__float__Sequence battery_temperature;
  /// 电池序列号
  uint8_t battery_serialnum[32];
} drdds__msg__BatteryDataValue;

// Struct for a sequence of drdds__msg__BatteryDataValue.
typedef struct drdds__msg__BatteryDataValue__Sequence
{
  drdds__msg__BatteryDataValue * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} drdds__msg__BatteryDataValue__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DRDDS__MSG__DETAIL__BATTERY_DATA_VALUE__STRUCT_H_
