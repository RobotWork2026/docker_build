// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from drdds:msg/CPUStatus.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__CPU_STATUS__TRAITS_HPP_
#define DRDDS__MSG__DETAIL__CPU_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "drdds/msg/detail/cpu_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace drdds
{

namespace msg
{

inline void to_flow_style_yaml(
  const CPUStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: timestamp
  {
    out << "timestamp: ";
    to_flow_style_yaml(msg.timestamp, out);
    out << ", ";
  }

  // member: soc_id
  {
    out << "soc_id: ";
    rosidl_generator_traits::value_to_yaml(msg.soc_id, out);
    out << ", ";
  }

  // member: package_temp
  {
    out << "package_temp: ";
    rosidl_generator_traits::value_to_yaml(msg.package_temp, out);
    out << ", ";
  }

  // member: temps
  {
    if (msg.temps.size() == 0) {
      out << "temps: []";
    } else {
      out << "temps: [";
      size_t pending_items = msg.temps.size();
      for (auto item : msg.temps) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: avg_util
  {
    out << "avg_util: ";
    rosidl_generator_traits::value_to_yaml(msg.avg_util, out);
    out << ", ";
  }

  // member: util
  {
    if (msg.util.size() == 0) {
      out << "util: []";
    } else {
      out << "util: [";
      size_t pending_items = msg.util.size();
      for (auto item : msg.util) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: cur_freq_khz
  {
    if (msg.cur_freq_khz.size() == 0) {
      out << "cur_freq_khz: []";
    } else {
      out << "cur_freq_khz: [";
      size_t pending_items = msg.cur_freq_khz.size();
      for (auto item : msg.cur_freq_khz) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: hw_max_freq_khz
  {
    if (msg.hw_max_freq_khz.size() == 0) {
      out << "hw_max_freq_khz: []";
    } else {
      out << "hw_max_freq_khz: [";
      size_t pending_items = msg.hw_max_freq_khz.size();
      for (auto item : msg.hw_max_freq_khz) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: hw_min_freq_khz
  {
    if (msg.hw_min_freq_khz.size() == 0) {
      out << "hw_min_freq_khz: []";
    } else {
      out << "hw_min_freq_khz: [";
      size_t pending_items = msg.hw_min_freq_khz.size();
      for (auto item : msg.hw_min_freq_khz) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: gov_policy
  {
    if (msg.gov_policy.size() == 0) {
      out << "gov_policy: []";
    } else {
      out << "gov_policy: [";
      size_t pending_items = msg.gov_policy.size();
      for (auto item : msg.gov_policy) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CPUStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp:\n";
    to_block_style_yaml(msg.timestamp, out, indentation + 2);
  }

  // member: soc_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "soc_id: ";
    rosidl_generator_traits::value_to_yaml(msg.soc_id, out);
    out << "\n";
  }

  // member: package_temp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "package_temp: ";
    rosidl_generator_traits::value_to_yaml(msg.package_temp, out);
    out << "\n";
  }

  // member: temps
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.temps.size() == 0) {
      out << "temps: []\n";
    } else {
      out << "temps:\n";
      for (auto item : msg.temps) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: avg_util
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "avg_util: ";
    rosidl_generator_traits::value_to_yaml(msg.avg_util, out);
    out << "\n";
  }

  // member: util
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.util.size() == 0) {
      out << "util: []\n";
    } else {
      out << "util:\n";
      for (auto item : msg.util) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: cur_freq_khz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.cur_freq_khz.size() == 0) {
      out << "cur_freq_khz: []\n";
    } else {
      out << "cur_freq_khz:\n";
      for (auto item : msg.cur_freq_khz) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: hw_max_freq_khz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.hw_max_freq_khz.size() == 0) {
      out << "hw_max_freq_khz: []\n";
    } else {
      out << "hw_max_freq_khz:\n";
      for (auto item : msg.hw_max_freq_khz) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: hw_min_freq_khz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.hw_min_freq_khz.size() == 0) {
      out << "hw_min_freq_khz: []\n";
    } else {
      out << "hw_min_freq_khz:\n";
      for (auto item : msg.hw_min_freq_khz) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: gov_policy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.gov_policy.size() == 0) {
      out << "gov_policy: []\n";
    } else {
      out << "gov_policy:\n";
      for (auto item : msg.gov_policy) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CPUStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace drdds

namespace rosidl_generator_traits
{

[[deprecated("use drdds::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const drdds::msg::CPUStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  drdds::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use drdds::msg::to_yaml() instead")]]
inline std::string to_yaml(const drdds::msg::CPUStatus & msg)
{
  return drdds::msg::to_yaml(msg);
}

template<>
inline const char * data_type<drdds::msg::CPUStatus>()
{
  return "drdds::msg::CPUStatus";
}

template<>
inline const char * name<drdds::msg::CPUStatus>()
{
  return "drdds/msg/CPUStatus";
}

template<>
struct has_fixed_size<drdds::msg::CPUStatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<drdds::msg::CPUStatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<drdds::msg::CPUStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DRDDS__MSG__DETAIL__CPU_STATUS__TRAITS_HPP_
