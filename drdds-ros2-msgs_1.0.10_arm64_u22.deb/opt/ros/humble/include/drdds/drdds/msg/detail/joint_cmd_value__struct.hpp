// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/JointCmdValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__drdds__msg__JointCmdValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__JointCmdValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct JointCmdValue_
{
  using Type = JointCmdValue_<ContainerAllocator>;

  explicit JointCmdValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = 0;
      this->control_word = 0;
      this->position = 0.0f;
      this->torque = 0.0f;
      this->velocity = 0.0f;
      this->kp = 0.0f;
      this->kd = 0.0f;
    }
  }

  explicit JointCmdValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->data_id = 0;
      this->control_word = 0;
      this->position = 0.0f;
      this->torque = 0.0f;
      this->velocity = 0.0f;
      this->kp = 0.0f;
      this->kd = 0.0f;
    }
  }

  // field types and members
  using _name_type =
    std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>>;
  _name_type name;
  using _data_id_type =
    uint16_t;
  _data_id_type data_id;
  using _control_word_type =
    uint16_t;
  _control_word_type control_word;
  using _position_type =
    float;
  _position_type position;
  using _torque_type =
    float;
  _torque_type torque;
  using _velocity_type =
    float;
  _velocity_type velocity;
  using _kp_type =
    float;
  _kp_type kp;
  using _kd_type =
    float;
  _kd_type kd;

  // setters for named parameter idiom
  Type & set__name(
    const std::vector<uint8_t, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<uint8_t>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__data_id(
    const uint16_t & _arg)
  {
    this->data_id = _arg;
    return *this;
  }
  Type & set__control_word(
    const uint16_t & _arg)
  {
    this->control_word = _arg;
    return *this;
  }
  Type & set__position(
    const float & _arg)
  {
    this->position = _arg;
    return *this;
  }
  Type & set__torque(
    const float & _arg)
  {
    this->torque = _arg;
    return *this;
  }
  Type & set__velocity(
    const float & _arg)
  {
    this->velocity = _arg;
    return *this;
  }
  Type & set__kp(
    const float & _arg)
  {
    this->kp = _arg;
    return *this;
  }
  Type & set__kd(
    const float & _arg)
  {
    this->kd = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::JointCmdValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::JointCmdValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::JointCmdValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::JointCmdValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::JointCmdValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::JointCmdValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::JointCmdValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::JointCmdValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::JointCmdValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::JointCmdValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__JointCmdValue
    std::shared_ptr<drdds::msg::JointCmdValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__JointCmdValue
    std::shared_ptr<drdds::msg::JointCmdValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const JointCmdValue_ & other) const
  {
    if (this->name != other.name) {
      return false;
    }
    if (this->data_id != other.data_id) {
      return false;
    }
    if (this->control_word != other.control_word) {
      return false;
    }
    if (this->position != other.position) {
      return false;
    }
    if (this->torque != other.torque) {
      return false;
    }
    if (this->velocity != other.velocity) {
      return false;
    }
    if (this->kp != other.kp) {
      return false;
    }
    if (this->kd != other.kd) {
      return false;
    }
    return true;
  }
  bool operator!=(const JointCmdValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct JointCmdValue_

// alias to use template instance with default allocator
using JointCmdValue =
  drdds::msg::JointCmdValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__JOINT_CMD_VALUE__STRUCT_HPP_
