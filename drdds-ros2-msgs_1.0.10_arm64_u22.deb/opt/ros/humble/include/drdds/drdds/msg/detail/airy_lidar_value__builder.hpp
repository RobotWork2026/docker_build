// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/AiryLidarValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/airy_lidar_value__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_AiryLidarValue_voltage
{
public:
  explicit Init_AiryLidarValue_voltage(::drdds::msg::AiryLidarValue & msg)
  : msg_(msg)
  {}
  ::drdds::msg::AiryLidarValue voltage(::drdds::msg::AiryLidarValue::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::AiryLidarValue msg_;
};

class Init_AiryLidarValue_temp
{
public:
  explicit Init_AiryLidarValue_temp(::drdds::msg::AiryLidarValue & msg)
  : msg_(msg)
  {}
  Init_AiryLidarValue_voltage temp(::drdds::msg::AiryLidarValue::_temp_type arg)
  {
    msg_.temp = std::move(arg);
    return Init_AiryLidarValue_voltage(msg_);
  }

private:
  ::drdds::msg::AiryLidarValue msg_;
};

class Init_AiryLidarValue_cld_size
{
public:
  explicit Init_AiryLidarValue_cld_size(::drdds::msg::AiryLidarValue & msg)
  : msg_(msg)
  {}
  Init_AiryLidarValue_temp cld_size(::drdds::msg::AiryLidarValue::_cld_size_type arg)
  {
    msg_.cld_size = std::move(arg);
    return Init_AiryLidarValue_temp(msg_);
  }

private:
  ::drdds::msg::AiryLidarValue msg_;
};

class Init_AiryLidarValue_error_code
{
public:
  explicit Init_AiryLidarValue_error_code(::drdds::msg::AiryLidarValue & msg)
  : msg_(msg)
  {}
  Init_AiryLidarValue_cld_size error_code(::drdds::msg::AiryLidarValue::_error_code_type arg)
  {
    msg_.error_code = std::move(arg);
    return Init_AiryLidarValue_cld_size(msg_);
  }

private:
  ::drdds::msg::AiryLidarValue msg_;
};

class Init_AiryLidarValue_is_runing
{
public:
  Init_AiryLidarValue_is_runing()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AiryLidarValue_error_code is_runing(::drdds::msg::AiryLidarValue::_is_runing_type arg)
  {
    msg_.is_runing = std::move(arg);
    return Init_AiryLidarValue_error_code(msg_);
  }

private:
  ::drdds::msg::AiryLidarValue msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::AiryLidarValue>()
{
  return drdds::msg::builder::Init_AiryLidarValue_is_runing();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__BUILDER_HPP_
