// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from drdds:msg/ImuData.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__IMU_DATA__BUILDER_HPP_
#define DRDDS__MSG__DETAIL__IMU_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "drdds/msg/detail/imu_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace drdds
{

namespace msg
{

namespace builder
{

class Init_ImuData_data
{
public:
  explicit Init_ImuData_data(::drdds::msg::ImuData & msg)
  : msg_(msg)
  {}
  ::drdds::msg::ImuData data(::drdds::msg::ImuData::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::drdds::msg::ImuData msg_;
};

class Init_ImuData_header
{
public:
  Init_ImuData_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ImuData_data header(::drdds::msg::ImuData::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_ImuData_data(msg_);
  }

private:
  ::drdds::msg::ImuData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::drdds::msg::ImuData>()
{
  return drdds::msg::builder::Init_ImuData_header();
}

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__IMU_DATA__BUILDER_HPP_
