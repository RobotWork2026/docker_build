// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from drdds:msg/AiryLidarValue.idl
// generated code does not contain a copyright notice

#ifndef DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__STRUCT_HPP_
#define DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__drdds__msg__AiryLidarValue __attribute__((deprecated))
#else
# define DEPRECATED__drdds__msg__AiryLidarValue __declspec(deprecated)
#endif

namespace drdds
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct AiryLidarValue_
{
  using Type = AiryLidarValue_<ContainerAllocator>;

  explicit AiryLidarValue_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->is_runing = false;
      this->error_code = 0l;
      this->cld_size = 0l;
      this->temp = 0.0f;
      this->voltage = 0.0f;
    }
  }

  explicit AiryLidarValue_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->is_runing = false;
      this->error_code = 0l;
      this->cld_size = 0l;
      this->temp = 0.0f;
      this->voltage = 0.0f;
    }
  }

  // field types and members
  using _is_runing_type =
    bool;
  _is_runing_type is_runing;
  using _error_code_type =
    int32_t;
  _error_code_type error_code;
  using _cld_size_type =
    int32_t;
  _cld_size_type cld_size;
  using _temp_type =
    float;
  _temp_type temp;
  using _voltage_type =
    float;
  _voltage_type voltage;

  // setters for named parameter idiom
  Type & set__is_runing(
    const bool & _arg)
  {
    this->is_runing = _arg;
    return *this;
  }
  Type & set__error_code(
    const int32_t & _arg)
  {
    this->error_code = _arg;
    return *this;
  }
  Type & set__cld_size(
    const int32_t & _arg)
  {
    this->cld_size = _arg;
    return *this;
  }
  Type & set__temp(
    const float & _arg)
  {
    this->temp = _arg;
    return *this;
  }
  Type & set__voltage(
    const float & _arg)
  {
    this->voltage = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    drdds::msg::AiryLidarValue_<ContainerAllocator> *;
  using ConstRawPtr =
    const drdds::msg::AiryLidarValue_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<drdds::msg::AiryLidarValue_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<drdds::msg::AiryLidarValue_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      drdds::msg::AiryLidarValue_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::AiryLidarValue_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      drdds::msg::AiryLidarValue_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<drdds::msg::AiryLidarValue_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<drdds::msg::AiryLidarValue_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<drdds::msg::AiryLidarValue_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__drdds__msg__AiryLidarValue
    std::shared_ptr<drdds::msg::AiryLidarValue_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__drdds__msg__AiryLidarValue
    std::shared_ptr<drdds::msg::AiryLidarValue_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const AiryLidarValue_ & other) const
  {
    if (this->is_runing != other.is_runing) {
      return false;
    }
    if (this->error_code != other.error_code) {
      return false;
    }
    if (this->cld_size != other.cld_size) {
      return false;
    }
    if (this->temp != other.temp) {
      return false;
    }
    if (this->voltage != other.voltage) {
      return false;
    }
    return true;
  }
  bool operator!=(const AiryLidarValue_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct AiryLidarValue_

// alias to use template instance with default allocator
using AiryLidarValue =
  drdds::msg::AiryLidarValue_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace drdds

#endif  // DRDDS__MSG__DETAIL__AIRY_LIDAR_VALUE__STRUCT_HPP_
